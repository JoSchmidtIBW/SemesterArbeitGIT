/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package john22012018;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Date;
import java.util.TimerTask;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Arrays;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;

import java.awt.Desktop;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;



class Gui {

    public Gui() throws IOException {

        JFrame hauptOberflaecheFrame = new JFrame("Coilrechner ");
        JPanel hauptOberflaechePanel = new JPanel();

        CardLayout cardLayout = new CardLayout();

        JPanel anzeigePanel = new JPanel();
        anzeigePanel.setLayout(cardLayout);
        anzeigePanel.add(new CoilRechner(), "Coilrechner");
        anzeigePanel.add(new Schweissen(anzeigePanel, cardLayout), "Schweissen");
        anzeigePanel.add(new Ziehen(anzeigePanel, cardLayout), "Ziehen");
        anzeigePanel.add(new Saegen(anzeigePanel, cardLayout), "Sägen");
        anzeigePanel.add(new Richten(anzeigePanel, cardLayout), "Richten");
        anzeigePanel.add(new Gluehen(anzeigePanel, cardLayout), "Glühen");
        anzeigePanel.add(new Anleitung(anzeigePanel, cardLayout), "Anleitung");

        anzeigePanel.add(new SchweissenMaschine(anzeigePanel, cardLayout, "RS25"), "RS25");
        anzeigePanel.add(new SchweissenMaschine(anzeigePanel, cardLayout, "RS30"), "RS30");
        anzeigePanel.add(new SchweissenMaschine(anzeigePanel, cardLayout, "RS50"), "RS50");
        anzeigePanel.add(new SchweissenMaschine(anzeigePanel, cardLayout, "RS60"), "RS60");
        anzeigePanel.add(new SchweissenMaschine(anzeigePanel, cardLayout, "RS65"), "RS65");

        anzeigePanel.add(new ZiehenMaschine(anzeigePanel, cardLayout, "INDER", "ziehende Rohrlaenge:"), "INDER");
        anzeigePanel.add(new ZiehenMaschine(anzeigePanel, cardLayout, "ASMAG", "600kN ziehende Rohrlänge"), "ASMAG");
        
        anzeigePanel.add(new Rezept(anzeigePanel, cardLayout, "Rattunde- Rezept", "ziehende Rohrlaenge:"), "Rezept");
        //anzeigePanel.add(new SaegenMaschine(anzeigePanel, cardLayout, "Rattunde", "Sägende Rohrlänge"), "Rattunde");
        anzeigePanel.add(new SaegenMaschine(anzeigePanel, cardLayout, "Rattunde1", "Sägende Rohrlänge"), "Rattunde1");
        anzeigePanel.add(new SaegenMaschine(anzeigePanel, cardLayout, "Rattunde2", "Sägende Rohrlänge"), "Rattunde2");
        anzeigePanel.add(new SaegenMaschine(anzeigePanel, cardLayout, "Rattunde3", "Sägende Rohrlänge"), "Rattunde3");
        anzeigePanel.add(new SaegenMaschine(anzeigePanel, cardLayout, "Rattunde4", "Sägende Rohrlänge"), "Rattunde4");

        anzeigePanel.add(new SchweissenMaschine(anzeigePanel, cardLayout, "SEMA"), "SEMA");
        anzeigePanel.add(new SchweissenMaschine(anzeigePanel, cardLayout, "Kiserling"), "Kieserling");
        anzeigePanel.add(new GluehenMaschine(anzeigePanel, cardLayout, "Glühofen 1", "Glühende Rohrlänge"), "Glühofen 1");
        anzeigePanel.add(new GluehenMaschine(anzeigePanel, cardLayout, "Glühofen 2", "Glühende Rohrlänge"), "Glühofen 2");

        anzeigePanel.add(new StempelRechner(anzeigePanel, cardLayout, "Stempelrechner"), "Stempelrechner");
        
        //anzeigePanel.add(new Anleitung(anzeigePanel, cardLayout, "Anleitung");
        //anzeigePanel.add(new Anleitung("Anleitung"));

        hauptOberflaechePanel.setLayout(new BoxLayout(hauptOberflaechePanel, BoxLayout.PAGE_AXIS));
        hauptOberflaechePanel.add(new MenuLeiste(anzeigePanel, cardLayout));
        hauptOberflaechePanel.add(anzeigePanel);
        hauptOberflaechePanel.add(new TaskLeiste(anzeigePanel, cardLayout));

        hauptOberflaecheFrame.getContentPane().add(hauptOberflaechePanel);
        //hauptOberflaecheFrame.setSize(1024, 768);  
        hauptOberflaecheFrame.setSize(1800, 768);
        hauptOberflaecheFrame.setUndecorated(true);
        hauptOberflaecheFrame.setVisible(true);
    }
}



class MenuLeiste extends JPanel implements ActionListener {

    final private CardLayout cardManager;
    final private JPanel cardPanel;

    JButton coilRechnerButton = new JButton("Coilrechner");
    JButton schweissenButton = new JButton("Schweissen");
    JButton ziehenButton = new JButton("Ziehen");
    JButton saegenButton = new JButton("Sägen");
    JButton richtenButton = new JButton("Richten");
    JButton gluehenButton = new JButton("Glühen");
    JButton stempelRechnerButton = new JButton("Stempelrechner");
    JButton anleitungButton = new JButton("Anleitung");

    String stringSchriftArtCALIBRI = "Calibri";
    String maschinenNamen = "Berechner";

    public MenuLeiste(JPanel cardPanel, CardLayout cardManager) throws IOException {
        this.cardManager = cardManager;
        this.cardPanel = cardPanel;
        initButtonPanel();
    }

    public void initButtonPanel() throws IOException {

        setLayout(new FlowLayout(0, 15, 10));

        JLabel titel = new JLabel("<html><u>" + maschinenNamen + "<html>");
        fontSetzenButton(titel, stringSchriftArtCALIBRI, true, 20);
        add(titel);

        coilRechnerButton.addActionListener(this);
        fontSetzenButton(coilRechnerButton, stringSchriftArtCALIBRI, true, 16);
        coilRechnerButton.setPreferredSize(new Dimension(130, 30));
        add(coilRechnerButton);

        schweissenButton.addActionListener(this);
        fontSetzenButton(schweissenButton, stringSchriftArtCALIBRI, true, 16);
        schweissenButton.setPreferredSize(new Dimension(130, 30));
        add(schweissenButton);

        ziehenButton.addActionListener(this);
        fontSetzenButton(ziehenButton, stringSchriftArtCALIBRI, true, 16);
        ziehenButton.setPreferredSize(new Dimension(130, 30));
        add(ziehenButton);

        saegenButton.addActionListener(this);
        fontSetzenButton(saegenButton, stringSchriftArtCALIBRI, true, 16);
        saegenButton.setPreferredSize(new Dimension(130, 30));
        add(saegenButton);

        richtenButton.addActionListener(this);
        fontSetzenButton(richtenButton, stringSchriftArtCALIBRI, true, 16);
        richtenButton.setPreferredSize(new Dimension(130, 30));
        add(richtenButton);

        gluehenButton.addActionListener(this);
        fontSetzenButton(gluehenButton, stringSchriftArtCALIBRI, true, 16);
        gluehenButton.setPreferredSize(new Dimension(130, 30));
        add(gluehenButton);

        stempelRechnerButton.addActionListener(this);
        fontSetzenButton(stempelRechnerButton, stringSchriftArtCALIBRI, true, 16);
        stempelRechnerButton.setPreferredSize(new Dimension(130, 30));
        add(stempelRechnerButton);
        
        anleitungButton.addActionListener(this);
        fontSetzenButton(anleitungButton, stringSchriftArtCALIBRI, true, 16);
        anleitungButton.setPreferredSize(new Dimension(130, 30));
        add(anleitungButton);        

        setBorder(BorderFactory.createEtchedBorder());

    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == this.coilRechnerButton) {
            cardManager.show(cardPanel, "Coilrechner");
        }
        if (ae.getSource() == this.schweissenButton) {
            cardManager.show(cardPanel, "Schweissen");
        }
        if (ae.getSource() == this.ziehenButton) {
            cardManager.show(cardPanel, "Ziehen");
        }
        if (ae.getSource() == this.saegenButton) {
            cardManager.show(cardPanel, "Sägen");
        }
        if (ae.getSource() == this.richtenButton) {
            cardManager.show(cardPanel, "Richten");
        }
        if (ae.getSource() == this.gluehenButton) {
            cardManager.show(cardPanel, "Glühen");
        }
        if (ae.getSource() == this.stempelRechnerButton) {
            cardManager.show(cardPanel, "Stempelrechner");
        }
        if (ae.getSource() == this.anleitungButton) {
            cardManager.show(cardPanel, "Anleitung");
        }
    }

    private void fontSetzenButton(JComponent component, String stringSchriftArt, boolean schriftDicke, int schriftGroesse) {
        if (schriftDicke) {
            component.setFont(new Font(stringSchriftArt, Font.BOLD, schriftGroesse));
        }
    }
}
//------------------------------------------------------------------------------

class TaskLeiste extends JPanel implements ActionListener {

    final private CardLayout cardManager;
    final private JPanel cardPanel;
    String uhrzeitText = "";
    String datumText = "";

    String stringSchriftArtCALIBRI = "Calibri";

    public TaskLeiste(JPanel cardPanel, CardLayout cardManager) throws IOException {
        this.cardManager = cardManager;
        this.cardPanel = cardPanel;
        initTaskPanel();
    }

    public void initTaskPanel() throws IOException {

        setBorder(BorderFactory.createEtchedBorder());
        //setLayout(new FlowLayout(0, 10, 30));//(0, 10, 30)
        setLayout(new FlowLayout(FlowLayout.RIGHT, 10, 10));

        final java.util.Timer clockTimer = new java.util.Timer(true);
        final java.text.SimpleDateFormat zeitFormat = new java.text.SimpleDateFormat("HH:mm:ss");
        final java.text.SimpleDateFormat datumFormat = new java.text.SimpleDateFormat("dd.MM.yyyy");
        final JLabel labelUhrzeit = new JLabel();
        final JLabel labelDatum = new JLabel();
        clockTimer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
//                String uhrzeitText = zeitFormat.format(new Date());
//                String datumText = datumFormat.format(new Date());
                uhrzeitText = zeitFormat.format(new Date());
                datumText = datumFormat.format(new Date());
                labelUhrzeit.setText(uhrzeitText);
                labelDatum.setText(datumText);
            }
        }, 0, 1000);

        labelDatum.setBorder(BorderFactory.createEtchedBorder());
        labelDatum.setHorizontalAlignment(JLabel.CENTER);
        labelDatum.setVerticalAlignment(JLabel.CENTER);//.CENTER
        labelDatum.setPreferredSize(new Dimension(100, 30));
        labelDatum.setFont(new Font("Arial", Font.ITALIC, 16));

        labelUhrzeit.setBorder(BorderFactory.createEtchedBorder());
        labelUhrzeit.setHorizontalAlignment(JLabel.CENTER);
        labelUhrzeit.setVerticalAlignment(JLabel.CENTER);
        labelUhrzeit.setPreferredSize(new Dimension(100, 30));
        labelUhrzeit.setFont(new Font("Arial", Font.ITALIC, 16));

        add(labelDatum);
        add(labelUhrzeit);

        //JLabel labelLogo = new JLabel(new ImageIcon("D:/bnbnbnb2.PNG"));
        JLabel labelLogo = new JLabel(new ImageIcon("C://Users/Schmidtjo/MubeaLogoBild.PNG"));// hier muss der Pfad vom Mubea- Logo eingefügt werden
        labelLogo.setPreferredSize(new Dimension(150, 50));
        add(labelLogo);

    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
//------------------------------------------------------------------------------

class StempelRechner extends JPanel {

    final private CardLayout cardManager;
    final private JPanel cardPanel;
    String panelName;

    JLabel labelPanelName;

    JLabel labelArbeitsZeitStart;
    JLabel labelArbeitsZeitEnde;
    JLabel labelBerechneZeitZwischenStartUndEnde;
    JLabel labelBerechneZeitMinusAbzugStartEnde;   
    JLabel labelBerechneGearbeiteteArbeitsZeit;
    JLabel labelBerechneNochZuArbeitendeZeit;

    JLabel labelArbeitsZeitEndeOhnePause;
    JLabel labelArbeitsZeitEndeMitPause;

    JLabel labelNochZuArbeitendeZeitOhnePause;
    JLabel labelNochZuArbeitendeZeitMitPause;

    JLabel labelKleinePauseGesamt;

    JTextField textFieldArbeitsZeitStart;
    JTextField textFieldArbeitsZeitEnde;

    JTextField textFieldKleinePauseGesamt;
    JTextField textFieldAnzahlMinuten2Pausen;

    JButton buttonArbeitsZeitStart;
    JButton buttonArbeitsZeitEnde;
    JButton buttonBerechneZeitZwischenStartUndEnde;
    JButton buttonBerechneZeitMinusAbzugStartEnde;
    JButton buttonBerechneGearbeiteteArbeitsZeit;
    JButton buttonBerechneNochZuArbeitendeZeit;

    JButton buttonKleinePauseGesamt;

    JLabel labelGetArbeitsZeitStart;
    JLabel labelGetArbeitsZeitEnde;
    JLabel labelGetBerechneZeitZwischenStartUndEnde;
    JLabel labelGetBerechneZeitMinusAbzugStartEnde;
    JLabel labelGetBerechneZeitVergleichArbeitsZeit;
    JLabel labelGetNochZuArbeitendeZeitOhnePause;
    JLabel labelGetNochZuArbeitendeZeitMitPause;
    
    JLabel labelGetGearbeiteteArbeitszeit;
    JLabel labelGetNochZuArbeitendeZeit;

    JLabel labelGetArbeitsZeitEndeOhnePause;
    JLabel labelGetArbeitsZeitEndeMitPause;

    JLabel labelGetKleinePauseGesamt;

    static String stringArbeitsZeitStart = "";
    String stringArbeitsZeitEnde = "";
    String stringBerechneZeitZwischenStartUndEnde = "";
    String stringBerechneZeitMinusAbzugStartEnde = "";
    String stringBerechneZeitVergleichArbeitsZeit = "";

    String stringKleinePauseGesamt = "";

    String stringKleinePauseGesamtMinuten = "";
    String stringKleinePauseGesamtStunden = "";

    String stringArbeitsZeitEndeOhnePause = "";
    String stringArbeitsZeitEndeMitPause = "";

    String stringGrossePauseStart = "";
    String stringGrossePauseEnde = "";

    String petName = "";

    String stringArbeitsZeitStunden;
    String stringArbeitsZeitMinuten;

    String stringNochZuArbeitendeZeitOhnePauseStunden = "";
    String stringNochZuArbeitendeZeitOhnePauseMinuten = "";

    String stringNochZuArbeitendeZeitMitPauseStunden = "";
    String stringNochZuArbeitendeZeitMitPauseMinuten = "";
    
    String stringGearbeiteteArbeitszeit = "";
    String stringNochZuArbeitendeZeit = "";

    String[] stringArrayArbeitsZeiten = {"8.48", "8.24", "8.00"};
    JLabel labelListArbeitsZeiten = new JLabel("Anwesenheitszeit einstellen:");
    String stringAnwesenheitszeit = "";
    JLabel labelGetListArbeitsZeiten = new JLabel(stringAnwesenheitszeit);

    String splitMinuteStart = "";

    String stundeStart = "";
    String minuteStart = "";

    String stundeEnde = "";
    String minuteEnde = "";
    
    String stringEingabeMinuten = "";
    String stringEingabeStunden = "";
    String stringAusgabeMinuten = "";
    String stringAusgabeStunden = "";

    String stringZeitBerechnetZwischenStartUndEndeStunden = "";
    String stringZeitBerechnetZwischenStartUndEndeMinuten = "";
    String stringZeitBerechnetMinusAbzugStartEndeStunden = "";
    String stringZeitBerechnetMinusAbzugStartEndeMinuten = "";
    String stringZeitBerechnetVergleichArbeitsZeitStunden = "";
    String stringZeitBerechnetVergleichArbeitsZeitMinuten = "";
    String stringZeitBerechnetArbeitsZeitEndeOhnePauseStunden = "";
    String stringZeitBerechnetArbeitsZeitEndeOhnePauseMinuten = "";
    String stringZeitBerechnetArbeitsZeitEndeMitPauseStunden = "";
    String stringZeitBerechnetArbeitsZeitEndeMitPauseMinuten = "";
    String stringNochZuArbeitendeZeitOhnePause = "";
    String stringNochZuArbeitendeZeitMitPause = "";

    String stringAbzugZeit = "";

    String stringMomentanMinuten = "";
    String stringMomentanStunden = "";

    String minute = "";
    String stunde = "";

    String eingabe = "";

    String[] getrenntUhrzeitStart = new String[0];
    String stringArbeitsZeit = "";

    String stringSchriftArtARIAL = "Arial";
    String stringSchriftArtCALIBRI = "Calibri";

    String MittagStartEingabe = "";
    String MittagEndeEingabe = "";           
    
    
    boolean falscheMinutenEingabe = false;
    boolean falscheStundenEingabe = false;
    boolean falscheZeitEingabe = false;
    boolean booleanGreen = false;
    boolean booleanRed = false;
    boolean booleanOrange = false;
    boolean booleanUeberZeit = false;
    boolean split = false;
    boolean booleanArbeitsZeitEreicht = false;
    int zaehler = 0;

    boolean booleanNacht = false;

    public StempelRechner(JPanel cardPanel, CardLayout cardManager, String panelName) throws IOException {
        this.cardManager = cardManager;
        this.cardPanel = cardPanel;
        this.panelName = panelName;
        initStempelRechner();
    }

    public void initStempelRechner() throws IOException {
        final java.text.SimpleDateFormat zeitFormat = new java.text.SimpleDateFormat("HH:mm");
        String uhrzeitText = zeitFormat.format(new Date());
        splittStringXX(uhrzeitText, split);
        setStringMomentanMinuten(minute);
        setStringMomentanStunden(stunde);

        labelPanelName = new JLabel(panelName);
        fontSetzenAktuell(labelPanelName, stringSchriftArtARIAL, true, 16, true);

        labelArbeitsZeitStart = new JLabel("Start");
        fontSetzenAktuell(labelArbeitsZeitStart, stringSchriftArtARIAL, true, 12, false);
        textFieldArbeitsZeitStart = new JTextField(stringArbeitsZeitStart);
        fontSetzenAktuell(textFieldArbeitsZeitStart, stringSchriftArtARIAL, true, 12, true);
        buttonArbeitsZeitStart = new JButton("OK");
        fontSetzenAktuell(buttonArbeitsZeitStart, stringSchriftArtARIAL, true, 12, false);
        labelGetArbeitsZeitStart = new JLabel("Uhr");
        fontSetzenAktuell(labelGetArbeitsZeitStart, stringSchriftArtARIAL, true, 12, false);

        labelArbeitsZeitEndeOhnePause = new JLabel("Arbeitszeitende ohne Pause");
        fontSetzenAktuell(labelArbeitsZeitEndeOhnePause, stringSchriftArtARIAL, true, 12, false);
        labelGetArbeitsZeitEndeOhnePause = new JLabel("Uhrzeit");
        fontSetzenAktuell(labelGetArbeitsZeitEndeOhnePause, stringSchriftArtARIAL, true, 12, false);

        labelArbeitsZeitEndeMitPause = new JLabel("Arbeitszeitende mit Pause");
        fontSetzenAktuell(labelArbeitsZeitEndeMitPause, stringSchriftArtARIAL, true, 12, false);
        labelGetArbeitsZeitEndeMitPause = new JLabel("Uhrzeit");
        fontSetzenAktuell(labelGetArbeitsZeitEndeMitPause, stringSchriftArtARIAL, true, 12, false);

        labelNochZuArbeitendeZeitMitPause = new JLabel("Noch zu arbeitende Zeit mit Pause");
        fontSetzenAktuell(labelNochZuArbeitendeZeitMitPause, stringSchriftArtARIAL, true, 12, false);
        labelGetNochZuArbeitendeZeitMitPause = new JLabel("Zeit");
        fontSetzenAktuell(labelGetNochZuArbeitendeZeitMitPause, stringSchriftArtARIAL, true, 12, false);

        labelNochZuArbeitendeZeitOhnePause = new JLabel("Noch zu arbeitende Zeit ohne Pause");
        fontSetzenAktuell(labelNochZuArbeitendeZeitOhnePause, stringSchriftArtARIAL, true, 12, false);
        labelGetNochZuArbeitendeZeitOhnePause = new JLabel("Uhrzeit");
        fontSetzenAktuell(labelGetNochZuArbeitendeZeitOhnePause, stringSchriftArtARIAL, true, 12, false);

        labelArbeitsZeitEnde = new JLabel("Ende");
        fontSetzenAktuell(labelArbeitsZeitEnde, stringSchriftArtARIAL, true, 12, false);
        textFieldArbeitsZeitEnde = new JTextField(stringArbeitsZeitEnde);
        fontSetzenAktuell(textFieldArbeitsZeitEnde, stringSchriftArtARIAL, true, 12, true);
        buttonArbeitsZeitEnde = new JButton("OK");
        fontSetzenAktuell(buttonArbeitsZeitEnde, stringSchriftArtARIAL, true, 12, false);
        labelGetArbeitsZeitEnde = new JLabel("Uhr");
        fontSetzenAktuell(labelGetArbeitsZeitEnde, stringSchriftArtARIAL, true, 12, false);

        labelKleinePauseGesamt = new JLabel("Kleine Pause Gesamte Zeitspanne");
        fontSetzenAktuell(labelKleinePauseGesamt, stringSchriftArtARIAL, true, 12, false);
        textFieldKleinePauseGesamt = new JTextField(stringKleinePauseGesamt);
        fontSetzenAktuell(textFieldKleinePauseGesamt, stringSchriftArtARIAL, true, 12, true);
        buttonKleinePauseGesamt = new JButton("OK");
        fontSetzenAktuell(buttonKleinePauseGesamt, stringSchriftArtARIAL, true, 12, false);
        labelGetKleinePauseGesamt = new JLabel("Zeitspanne");
        fontSetzenAktuell(labelGetKleinePauseGesamt, stringSchriftArtARIAL, true, 12, false);

        labelBerechneZeitZwischenStartUndEnde = new JLabel("Berechne erste Zeit zwischen Start und Ende:");
        fontSetzenAktuell(labelBerechneZeitZwischenStartUndEnde, stringSchriftArtARIAL, true, 12, false);
        buttonBerechneZeitZwischenStartUndEnde = new JButton("OK");
        fontSetzenAktuell(buttonBerechneZeitZwischenStartUndEnde, stringSchriftArtARIAL, true, 12, false);
        labelGetBerechneZeitZwischenStartUndEnde = new JLabel("");
        fontSetzenAktuell(labelGetBerechneZeitZwischenStartUndEnde, stringSchriftArtARIAL, true, 12, false);

        labelBerechneZeitMinusAbzugStartEnde = new JLabel("Berechne Zeit minus Abzug Start und Ende:");
        fontSetzenAktuell(labelBerechneZeitMinusAbzugStartEnde, stringSchriftArtARIAL, true, 12, false);
        buttonBerechneZeitMinusAbzugStartEnde = new JButton("OK");
        fontSetzenAktuell(buttonBerechneZeitMinusAbzugStartEnde, stringSchriftArtARIAL, true, 12, false);
        labelGetBerechneZeitMinusAbzugStartEnde = new JLabel("");
        fontSetzenAktuell(labelGetBerechneZeitMinusAbzugStartEnde, stringSchriftArtARIAL, true, 12, false);

        labelBerechneGearbeiteteArbeitsZeit = new JLabel("Berechne gearbeitete ArbeitsZeit:");
        fontSetzenAktuell(labelBerechneGearbeiteteArbeitsZeit, stringSchriftArtARIAL, true, 12, false);
        buttonBerechneGearbeiteteArbeitsZeit = new JButton("OK");        
        fontSetzenAktuell(buttonBerechneGearbeiteteArbeitsZeit, stringSchriftArtARIAL, true, 12, false);        
        labelGetGearbeiteteArbeitszeit = new JLabel("");
        fontSetzenAktuell(labelGetGearbeiteteArbeitszeit, stringSchriftArtARIAL, true, 12, false);
        
        labelBerechneNochZuArbeitendeZeit = new JLabel("Berechne noch zu arbeitende ArbeitsZeit:");
        fontSetzenAktuell(labelBerechneNochZuArbeitendeZeit, stringSchriftArtARIAL, true, 12, false);
        buttonBerechneNochZuArbeitendeZeit = new JButton("OK");        
        fontSetzenAktuell(buttonBerechneNochZuArbeitendeZeit, stringSchriftArtARIAL, true, 12, false);        
        labelGetNochZuArbeitendeZeit = new JLabel("");
        fontSetzenAktuell(labelGetNochZuArbeitendeZeit, stringSchriftArtARIAL, true, 12, false);        
        
        
        
        
        
        
        
        
        
        labelGetBerechneZeitVergleichArbeitsZeit = new JLabel("");
        fontSetzenAktuell(labelGetBerechneZeitVergleichArbeitsZeit, stringSchriftArtARIAL, true, 12, false);

        setLayout(new GridBagLayout());
        final GridBagConstraints c = new GridBagConstraints();

        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 10);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 2;
        add(labelPanelName, c);

//------------------------------------------------------------------------------
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 11;
        c.gridy = 7;
        add(labelListArbeitsZeiten, c);

        JComboBox listArbeitsZeiten = new JComboBox(stringArrayArbeitsZeiten);
        listArbeitsZeiten.setSelectedIndex(2);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 12;
        c.gridy = 7;
        add(listArbeitsZeiten, c);

        listArbeitsZeiten.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JComboBox cb = (JComboBox) e.getSource();
                String petName = (String) cb.getSelectedItem();

                setArbeitsZeit(petName);
                split = false;
                splittStringXX(petName, split);
                setArbeitsZeitMinuten(minute);
                setArbeitsZeitStunden(stunde);
                //ausgeben(petName);

                stringAnwesenheitszeit = getArbeitsZeitStunden() + " h " + getArbeitsZeitMinuten() + " min";
                labelGetListArbeitsZeiten.setForeground(Color.black);
                labelGetListArbeitsZeiten.setText(stringAnwesenheitszeit);

                if (minuteStart.length() == 0) {
                    labelGetListArbeitsZeiten.setForeground(Color.red);
                    labelGetListArbeitsZeiten.setText("Keine Startzeit angewählt");
                } else {
                    labelGetListArbeitsZeiten.setForeground(Color.black);
                    berechneArbeitsZeitEndeOhnePause();

                    Zeit24Rechner(getStringBerechnetArbeitsZeitEndeOhnePauseStunden(), getStringBerechnetArbeitsZeitEndeOhnePauseMinuten());

                    setStringBerechnetArbeitsZeitEndeOhnePauseStunden(stundeEnde);
                    setStringBerechnetArbeitsZeitEndeOhnePauseMinuten(minuteEnde);

                    FrageBooleanNacht();
                    //System.out.println(getBooleanNacht() + " -->   getBooleanNacht()");
                    labelGetArbeitsZeitEndeOhnePause.setText("" + getStringBerechnetArbeitsZeitEndeOhnePauseStunden() + " : " + getStringBerechnetArbeitsZeitEndeOhnePauseMinuten() + " Uhrzeit");
                }
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 13;
        c.gridy = 7;
        add(labelGetListArbeitsZeiten, c);

//------------------------------------------------------------------------------  
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 9;
        add(labelArbeitsZeitStart, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 9;
        add(textFieldArbeitsZeitStart, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 9;
        add(buttonArbeitsZeitStart, c);

        buttonArbeitsZeitStart.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {

                stringArbeitsZeitStart = textFieldArbeitsZeitStart.getText();
                falscheZeitEingabe = false;

                if ((stringArbeitsZeitStart.matches("[0-9]" + "[0-9]" + "[0-9]" + "[0-9]"))
                        || (stringArbeitsZeitStart.matches("[0-9]" + "[0-9]" + "[;,.:/ -]" + "[0-9]" + "[0-9]"))
                        || (stringArbeitsZeitStart.matches("[0-9]" + "[;,.:/ -]" + "[0-9]" + "[0-9]"))
                        || (stringArbeitsZeitStart.matches("[0-9]" + "[0-9]" + "[0-9]"))
                        || (stringArbeitsZeitStart.matches("[0-9]" + "[0-9]"))
                        || (stringArbeitsZeitStart.matches("[0-9]"))
                        && (falscheZeitEingabe != true)) {

                    labelGetArbeitsZeitStart.setForeground(Color.black);
                    splittStringXX(stringArbeitsZeitStart, split);

                    eingabePrueferXX(minute, stunde, falscheZeitEingabe);

                    setMinutenStart(minute);
                    setStundenStart(stunde);

                    if (falscheMinutenEingabe == true) {
                        System.err.println("Fehlerhafte Minuten-Eingabe!!!");
                        labelGetArbeitsZeitStart.setForeground(Color.red);
                        labelGetArbeitsZeitStart.setText(getMinutenStart() + " min Minuten?! Fehlerhafte Minuten!!!");
                    } else if (falscheStundenEingabe == true) {
                        System.err.println("Fehlerhafte Stunden-Eingabe!!!");
                        labelGetArbeitsZeitStart.setForeground(Color.red);
                        labelGetArbeitsZeitStart.setText(getStundenStart() + " h  Stunden?! Fehlerhafte Stunden!!!");
                    } else if (falscheMinutenEingabe == false && falscheStundenEingabe == false) {
                        labelGetArbeitsZeitStart.setText("" + getStundenStart() + " : " + getMinutenStart() + " Uhr");
                    }
                } else if (stringArbeitsZeitStart.length() == 0) {
                    final java.text.SimpleDateFormat zeitFormat = new java.text.SimpleDateFormat("HH:mm");
                    String uhrzeitText = zeitFormat.format(new Date());
                    splittStringXX(uhrzeitText, split);
                    setMinutenStart(minute);
                    setStundenStart(stunde);
                    labelGetArbeitsZeitStart.setForeground(Color.black);
                    labelGetArbeitsZeitStart.setText("" + getStundenStart() + " : " + getMinutenStart() + " Uhr (momentane Zeit)");
                } else {
                    System.err.println("Fehlerhafte Eingabe!!!");
                    labelGetArbeitsZeitStart.setForeground(Color.red);
                    labelGetArbeitsZeitStart.setText("Fehlerhafte Eingabe!!!");
                }

                if (stringAnwesenheitszeit.length() == 0) {
                    labelGetListArbeitsZeiten.setForeground(Color.red);
                    labelGetListArbeitsZeiten.setText("Keine Präsenzzeit angewählt");
                } else {
                    labelGetListArbeitsZeiten.setForeground(Color.black);
                    berechneArbeitsZeitEndeOhnePause();

                    Zeit24Rechner(getStringBerechnetArbeitsZeitEndeOhnePauseStunden(), getStringBerechnetArbeitsZeitEndeOhnePauseMinuten());

                    setStringBerechnetArbeitsZeitEndeOhnePauseStunden(stundeEnde);
                    //setStringBerechnetArbeitsZeitEndeOhnePauseMinuten(minuteEnde);
                    
                int i = Integer.parseInt(minuteEnde);
                if(i > 10 || i == 10){                   
                    setStringBerechnetArbeitsZeitEndeOhnePauseMinuten(minuteEnde);
                    //System.out.println("Hallo Neu Jahr: " + minuteEnde);
                }else{
                    setStringBerechnetArbeitsZeitEndeOhnePauseMinuten("0" + minuteEnde);
                    //System.out.println("Hallo Neu Jahr: mit zero " + minuteEnde);
                }                    

                    FrageBooleanNacht();
                    //System.out.println(getBooleanNacht() + " -->   getBooleanNacht()");
                    labelGetArbeitsZeitEndeOhnePause.setText("" + getStringBerechnetArbeitsZeitEndeOhnePauseStunden() + " : " + getStringBerechnetArbeitsZeitEndeOhnePauseMinuten() + " Uhrzeit");
                }
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 9;
        add(labelGetArbeitsZeitStart, c);

        textFieldArbeitsZeitStart.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buttonArbeitsZeitStart.doClick();
            }
        });

        buttonArbeitsZeitStart.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buttonArbeitsZeitStart.doClick();
            }
        });
//------------------------------------------------------------------------------
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 12;
        c.gridy = 8;
        add(labelArbeitsZeitEndeOhnePause, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 13;
        c.gridy = 8;
        add(labelGetArbeitsZeitEndeOhnePause, c);
//------------------------------------------------------------------------------        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 12;
        add(labelArbeitsZeitEnde, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 12;
        add(textFieldArbeitsZeitEnde, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 12;
        add(buttonArbeitsZeitEnde, c);

        buttonArbeitsZeitEnde.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                stringArbeitsZeitEnde = textFieldArbeitsZeitEnde.getText();
                falscheZeitEingabe = false;
                booleanArbeitsZeitEreicht = false;
                if (minuteStart.length()==0) {
                    labelGetArbeitsZeitEnde.setForeground(Color.red);
                    labelGetArbeitsZeitEnde.setText("Erst ArbeitstartZeit eingeben!!!");
                } else if (stringAnwesenheitszeit.length() == 0) {
                    labelGetListArbeitsZeiten.setForeground(Color.red);
                    labelGetArbeitsZeitEnde.setText("Erst Anwesenheitszeit eingeben!!!");

                } else {
                    if ((stringArbeitsZeitEnde.matches("[0-9]" + "[0-9]" + "[0-9]" + "[0-9]"))
                            || (stringArbeitsZeitEnde.matches("[0-9]" + "[0-9]" + "[;,.:/ -]" + "[0-9]" + "[0-9]"))
                            || (stringArbeitsZeitEnde.matches("[0-9]" + "[;,.:/ -]" + "[0-9]" + "[0-9]"))
                            || (stringArbeitsZeitEnde.matches("[0-9]" + "[0-9]" + "[0-9]"))
                            || (stringArbeitsZeitEnde.matches("[0-9]" + "[0-9]"))
                            || (stringArbeitsZeitEnde.matches("[0-9]"))
                            && (falscheZeitEingabe != true)) {

                        labelGetArbeitsZeitEnde.setForeground(Color.black);
                        splittStringXX(stringArbeitsZeitEnde, split);
                        setMinutenEnde(minute);
                        setStundenEnde(stunde);
                        eingabePrueferXX(getMinutenEnde(), getStundenEnde(), falscheZeitEingabe);
                        if (falscheMinutenEingabe == true) {
                            System.err.println("Fehlerhafte Minuten-Eingabe!!!");
                            labelGetArbeitsZeitEnde.setForeground(Color.red);
                            labelGetArbeitsZeitEnde.setText(getMinutenEnde() + " min Minuten?! Fehlerhafte Minuten!!!");
                        } else if (falscheStundenEingabe == true) {
                            System.err.println("Fehlerhafte Stunden-Eingabe!!!");
                            labelGetArbeitsZeitEnde.setForeground(Color.red);
                            labelGetArbeitsZeitEnde.setText(getStundenEnde() + " h  Stunden?! Fehlerhafte Stunden!!!");
                        } else if (falscheMinutenEingabe == false && falscheStundenEingabe == false) {
                            labelGetArbeitsZeitEnde.setText("" + getStundenEnde() + " : " + getMinutenEnde() + " Uhr");
                        }
                    } else if (stringArbeitsZeitEnde.length() == 0) {
                        final java.text.SimpleDateFormat zeitFormat = new java.text.SimpleDateFormat("HH:mm");
                        String uhrzeitText = zeitFormat.format(new Date());
                        splittStringXX(uhrzeitText, split);
                        setMinutenEnde(minute);
                        setStundenEnde(stunde);
                        labelGetArbeitsZeitEnde.setForeground(Color.black);
                        labelGetArbeitsZeitEnde.setText("" + getStundenEnde() + " : " + getMinutenEnde() + " Uhr (momentane Zeit)");
                    } else {
                        System.err.println("Fehlerhafte Eingabe!!!");
                        labelGetArbeitsZeitEnde.setForeground(Color.red);
                        labelGetArbeitsZeitEnde.setText("Fehlerhafte Eingabe!!!");
                    }
                    BerechneZeitVergleichArbeitsZeit();//boolean booleanGreen

                    if (getBooleanUeberZeit() == true) {

                        labelGetBerechneZeitVergleichArbeitsZeit.setText(getStringZeitBerechnetVergleichArbeitsZeitStunden() + " h "
                                + getStringZeitBerechnetVergleichArbeitsZeitMinuten() + " min   --->    Überzeit    :)");
                    } else {
                        labelGetBerechneZeitVergleichArbeitsZeit.setText(getStringZeitBerechnetVergleichArbeitsZeitStunden() + " h "
                                + getStringZeitBerechnetVergleichArbeitsZeitMinuten() + " min");
                    }

                }
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 12;
        add(labelGetArbeitsZeitEnde, c);

        textFieldArbeitsZeitEnde.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buttonArbeitsZeitEnde.doClick();
            }
        });

        buttonArbeitsZeitEnde.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buttonArbeitsZeitEnde.doClick();
            }
        });
//------------------------------------------------------------------------------
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 12;
        c.gridy = 10;
        add(labelArbeitsZeitEndeOhnePause, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 13;
        c.gridy = 10;
        add(labelGetArbeitsZeitEndeOhnePause, c);
//------------------------------------------------------------------------------
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 11;
        add(labelKleinePauseGesamt, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 11;
        add(textFieldKleinePauseGesamt, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 11;
        add(buttonKleinePauseGesamt, c);

        buttonKleinePauseGesamt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                stringKleinePauseGesamt = textFieldKleinePauseGesamt.getText();

                if (stringKleinePauseGesamt.length() == 0) {
                    stringKleinePauseGesamt = "0.0";
                    labelGetKleinePauseGesamt.setForeground(Color.black);
                    splittStringXX(stringKleinePauseGesamt, split);
                    setKleinePauseGesamtStunden(stunde);
                    setKleinePauseGesamtMinuten(minute);
                    eingabePrueferXX(stunde, minute, falscheZeitEingabe);
                    labelGetKleinePauseGesamt.setText("" + getKleinePauseGesamtStunden() + " h " + getKleinePauseGesamtMinuten() + " min");
                } else if ((stringKleinePauseGesamt.matches("[0-9]" + "[0-9]" + "[0-9]" + "[0-9]"))
                        || (stringKleinePauseGesamt.matches("[0-9]" + "[0-9]" + "[;,.:/ -]" + "[0-9]" + "[0-9]"))
                        || (stringKleinePauseGesamt.matches("[0-9]" + "[;,.:/ -]" + "[0-9]" + "[0-9]"))
                        || (stringKleinePauseGesamt.matches("[0-9]" + "[0-9]" + "[0-9]"))
                        || (stringKleinePauseGesamt.matches("[0-9]" + "[0-9]"))
                        || (stringKleinePauseGesamt.matches("[0-9]"))
                        && (falscheZeitEingabe != true)) {// || (stringKleinePauseGesamt.length()==0))

                    labelGetKleinePauseGesamt.setForeground(Color.black);
                    splittStringXX(stringKleinePauseGesamt, split);
                    setKleinePauseGesamtStunden(stunde);
                    setKleinePauseGesamtMinuten(minute);

                    eingabePrueferXX(stunde, minute, falscheZeitEingabe);

                    if (falscheMinutenEingabe == true) {
                        System.err.println("Fehlerhafte Minuten-Eingabe!!!");
                        labelGetKleinePauseGesamt.setForeground(Color.red);
                        labelGetKleinePauseGesamt.setText(getKleinePauseGesamtMinuten() + " min Minuten?! Fehlerhafte Minuten!!!");
                    } else if (falscheStundenEingabe == true) {
                        System.err.println("Fehlerhafte Stunden-Eingabe!!!");
                        labelGetKleinePauseGesamt.setForeground(Color.red);
                        labelGetKleinePauseGesamt.setText(getKleinePauseGesamtStunden() + " h  Stunden?! Fehlerhafte Stunden!!!");
                    } else if (falscheMinutenEingabe == false && falscheStundenEingabe == false) {
                        labelGetKleinePauseGesamt.setText("" + getKleinePauseGesamtStunden() + " h " + getKleinePauseGesamtMinuten() + " min");
                    }
                } else {
                    System.err.println("Fehlerhafte Eingabe!!!");
                    labelGetKleinePauseGesamt.setForeground(Color.red);
                    labelGetKleinePauseGesamt.setText("Fehlerhafte Eingabe!!!");
                }

                BerechneArbeitsZeitMitPause();
                Zeit24Rechner(getStringBerechnetArbeitsZeitEndeMitPauseStunden(), getStringBerechnetArbeitsZeitEndeMitPauseMinuten());

                setStringBerechnetArbeitsZeitEndeMitPauseStunden(stundeEnde);
              
                int i = Integer.parseInt(minuteEnde);
                if(i > 10 || i == 10){                   
                    setStringBerechnetArbeitsZeitEndeMitPauseMinuten(minuteEnde);
                    //System.out.println("Hallo Neu Jahr: " + minuteEnde);
                }else{
                    setStringBerechnetArbeitsZeitEndeMitPauseMinuten("0" + minuteEnde);
                    //System.out.println("Hallo Neu Jahr: mit zero " + minuteEnde);
                }
                
                //setStringBerechnetArbeitsZeitEndeMitPauseMinuten(minuteEnde);
                //System.out.println("Hallo Neu Jahr: minuteEnde " + minuteEnde);
                labelGetArbeitsZeitEndeMitPause.setText("" + getStringBerechnetArbeitsZeitEndeMitPauseStunden() + " : " + getStringBerechnetArbeitsZeitEndeMitPauseMinuten() + " Uhr");

            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 11;
        add(labelGetKleinePauseGesamt, c);

        textFieldKleinePauseGesamt.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buttonKleinePauseGesamt.doClick();
            }
        });

        buttonKleinePauseGesamt.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buttonKleinePauseGesamt.doClick();
            }
        });
//------------------------------------------------------------------------------
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 12;
        c.gridy = 11;
        add(labelArbeitsZeitEndeMitPause, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 13;
        c.gridy = 11;
        add(labelGetArbeitsZeitEndeMitPause, c);

//------------------------------------------------------------------------------        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 13;
        add(labelBerechneZeitZwischenStartUndEnde, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 13;
        add(buttonBerechneZeitZwischenStartUndEnde, c);

        buttonBerechneZeitZwischenStartUndEnde.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                BerechneZeitZwischenStartUndEnde();
                labelGetBerechneZeitZwischenStartUndEnde.setText(getStringZeitBerechnetZwischenStartUndEndeStunden() + " h "
                        + getStringZeitBerechnetZwischenStartUndEndeMinuten() + " min");
                labelGetBerechneZeitZwischenStartUndEnde.setForeground(Color.black);

                setStringEingabeStunden(stringZeitBerechnetZwischenStartUndEndeStunden);
                setStringEingabeMinuten(stringZeitBerechnetZwischenStartUndEndeMinuten);
                
//                ausgeben(stringZeitBerechnetZwischenStartUndEndeStunden);
//                ausgeben(getStringZeitBerechnetZwischenStartUndEndeStunden());
//                ausgeben(getStringEingabeStunden());
                
                
                BerechneNochZuArbeitendeZeit(stringEingabeStunden, stringEingabeMinuten);
//                System.out.println(stringEingabeStunden + " stringEingabeStunden");
//                System.out.println(getStringEingabeStunden()   +   "    getStringEingabeStunden()");
//                
//                setStringBerechnetArbeitsZeitEndeOhnePauseMinuten(stringAusgabeMinuten);
//                setStringBerechnetArbeitsZeitEndeOhnePauseStunden(getStringAusgabeStunden());
                stringNochZuArbeitendeZeitOhnePauseStunden = getStringAusgabeStunden();
                stringNochZuArbeitendeZeitOhnePauseMinuten = getStringAusgabeStunden();
                setStringBerechnetArbeitsZeitEndeOhnePauseStunden(stringNochZuArbeitendeZeitOhnePauseStunden);
                setStringBerechnetArbeitsZeitEndeOhnePauseMinuten(stringNochZuArbeitendeZeitOhnePauseMinuten);
                //setStringBerechnetArbeitsZeitEndeOhnePauseStunden(stringAusgabeStunden);                   
//                System.out.println(getStringBerechnetArbeitsZeitEndeOhnePauseMinuten() + " = getStringBerechnetArbeitsZeitEndeOhnePauseMinuten()");
                
                //BerechneNochZuArbeitendeZeitOhnePausen();
                labelGetNochZuArbeitendeZeitOhnePause.setText(getStringNochZuArbeitendeZeitOhnePauseStunden() + " h "
                        + getStringNochZuArbeitendeZeitOhnePauseMinuten() + " min");
                labelGetNochZuArbeitendeZeitOhnePause.setForeground(Color.black);
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 13;
        add(labelGetBerechneZeitZwischenStartUndEnde, c);

        buttonBerechneZeitZwischenStartUndEnde.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buttonBerechneZeitZwischenStartUndEnde.doClick();
            }
        });
//------------------------------------------------------------------------------
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 12;
        c.gridy = 13;
        add(labelNochZuArbeitendeZeitOhnePause, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 13;
        c.gridy = 13;
        add(labelGetNochZuArbeitendeZeitOhnePause, c);
//------------------------------------------------------------------------------        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 17;
        add(labelBerechneZeitMinusAbzugStartEnde, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 17;
        add(buttonBerechneZeitMinusAbzugStartEnde, c);

        buttonBerechneZeitMinusAbzugStartEnde.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                BerechneZeitMinusAbzugStartEnde();
                labelGetBerechneZeitMinusAbzugStartEnde.setText(getStringZeitBerechnetMinusAbzugStartEndeStunden() + " h "
                        + getStringZeitBerechnetMinusAbzugStartEndeMinuten() + " min");
                labelGetBerechneZeitMinusAbzugStartEnde.setForeground(Color.black);
                
//                setStringEingabeStunden(getStringZeitBerechnetMinusAbzugStartEndeStunden());
//                setStringEingabeMinuten(getStringZeitBerechnetMinusAbzugStartEndeMinuten());
//                
//                BerechneNochZuArbeitendeZeit(getStringEingabeStunden(), getStringEingabeMinuten());
//                
//                setStringBerechnetArbeitsZeitEndeMitPauseMinuten(getStringAusgabeMinuten());
//                setStringBerechnetArbeitsZeitEndeMitPauseStunden(getStringAusgabeStunden());             
                
                setStringEingabeStunden(stringZeitBerechnetMinusAbzugStartEndeStunden);
                setStringEingabeMinuten(stringZeitBerechnetMinusAbzugStartEndeMinuten);
                
//                ausgeben(stringZeitBerechnetZwischenStartUndEndeStunden);
//                ausgeben(getStringZeitBerechnetZwischenStartUndEndeStunden());
//                ausgeben(getStringEingabeStunden());
                
                
                BerechneNochZuArbeitendeZeit(stringEingabeStunden, stringEingabeMinuten);
//                System.out.println(stringEingabeStunden + " stringEingabeStunden");
//                System.out.println(getStringEingabeStunden()   +   "    getStringEingabeStunden()");
//                
//                setStringBerechnetArbeitsZeitEndeOhnePauseMinuten(stringAusgabeMinuten);
//                setStringBerechnetArbeitsZeitEndeOhnePauseStunden(getStringAusgabeStunden());
                stringNochZuArbeitendeZeitMitPauseStunden = getStringAusgabeStunden();
                stringNochZuArbeitendeZeitMitPauseMinuten = getStringAusgabeStunden();
                setStringBerechnetArbeitsZeitEndeMitPauseStunden(stringNochZuArbeitendeZeitMitPauseStunden);
                setStringBerechnetArbeitsZeitEndeMitPauseMinuten(stringNochZuArbeitendeZeitMitPauseMinuten);                
                
                
                
                labelGetNochZuArbeitendeZeitMitPause.setText(getStringNochZuArbeitendeZeitMitPauseStunden() + " h "
                        + getStringNochZuArbeitendeZeitMitPauseMinuten() + " min");
                labelGetNochZuArbeitendeZeitMitPause.setForeground(Color.black);
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 17;
        add(labelGetBerechneZeitMinusAbzugStartEnde, c);

        buttonBerechneZeitMinusAbzugStartEnde.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buttonBerechneZeitMinusAbzugStartEnde.doClick();
            }
        });

//------------------------------------------------------------------------------
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 12;
        c.gridy = 14;
        add(labelNochZuArbeitendeZeitMitPause, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 13;
        c.gridy = 14;
        add(labelGetNochZuArbeitendeZeitMitPause, c);
//------------------------------------------------------------------------------        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 12;//2;
        c.gridy = 12;//19;
        add(labelBerechneGearbeiteteArbeitsZeit, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 13;//5;
        c.gridy = 12;//19;
        add(labelGetBerechneZeitVergleichArbeitsZeit, c);
//------------------------------------------------------------------------------
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 12;
//        c.gridy = 12;
//        add(labelVerbleibendeZeitBisSchlussMitPause, c);
//        
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 13;
//        c.gridy = 12;
//        add(labelGetVerbleibendeZeitBisSchlussMitPause, c);
//        
//------------------------------------------------------------------------------
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 30;
        add(labelBerechneGearbeiteteArbeitsZeit, c); 
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 30;
        add(buttonBerechneGearbeiteteArbeitsZeit, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 30;
        add(labelGetGearbeiteteArbeitszeit, c);        

        buttonBerechneGearbeiteteArbeitsZeit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {

//                    if (falscheMinutenEingabe == true) {
//                        System.err.println("Fehlerhafte Minuten-Eingabe!!!");
//                        labelGetKleinePauseGesamt.setForeground(Color.red);
//                        labelGetKleinePauseGesamt.setText(getKleinePauseGesamtMinuten() + " min Minuten?! Fehlerhafte Minuten!!!");
//                    } else if (falscheStundenEingabe == true) {
//                        System.err.println("Fehlerhafte Stunden-Eingabe!!!");
//                        labelGetKleinePauseGesamt.setForeground(Color.red);
//                        labelGetKleinePauseGesamt.setText(getKleinePauseGesamtStunden() + " h  Stunden?! Fehlerhafte Stunden!!!");
//                    } else if (falscheMinutenEingabe == false && falscheStundenEingabe == false) {
//                        labelGetKleinePauseGesamt.setText("" + getKleinePauseGesamtStunden() + " h " + getKleinePauseGesamtMinuten() + " min");
//                    }
//                BerechneArbeitsZeitMitPause();
                labelGetGearbeiteteArbeitszeit.setText("Hello Kitty");   
            }
        });

        buttonBerechneGearbeiteteArbeitsZeit.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buttonBerechneGearbeiteteArbeitsZeit.doClick();
            }
        });        
  
//------------------------------------------------------------------------------

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 31;
        add(labelBerechneNochZuArbeitendeZeit, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 31;
        add(buttonBerechneNochZuArbeitendeZeit, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 31;
        add(labelGetNochZuArbeitendeZeit, c);

        buttonBerechneNochZuArbeitendeZeit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {

//                    if (falscheMinutenEingabe == true) {
//                        System.err.println("Fehlerhafte Minuten-Eingabe!!!");
//                        labelGetKleinePauseGesamt.setForeground(Color.red);
//                        labelGetKleinePauseGesamt.setText(getKleinePauseGesamtMinuten() + " min Minuten?! Fehlerhafte Minuten!!!");
//                    } else if (falscheStundenEingabe == true) {
//                        System.err.println("Fehlerhafte Stunden-Eingabe!!!");
//                        labelGetKleinePauseGesamt.setForeground(Color.red);
//                        labelGetKleinePauseGesamt.setText(getKleinePauseGesamtStunden() + " h  Stunden?! Fehlerhafte Stunden!!!");
//                    } else if (falscheMinutenEingabe == false && falscheStundenEingabe == false) {
//                        labelGetKleinePauseGesamt.setText("" + getKleinePauseGesamtStunden() + " h " + getKleinePauseGesamtMinuten() + " min");
//                    }
//                BerechneArbeitsZeitMitPause();
                labelGetNochZuArbeitendeZeit.setText("Hello Kitty --> noch");              
            }
        });        
         
        buttonBerechneNochZuArbeitendeZeit.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buttonBerechneNochZuArbeitendeZeit.doClick();
            }
        });           
//------------------------------------------------------------------------------        
//------------------------------------------------------------------------------        
               
        JLabel labelMittagZeitStartEingabe = new JLabel("Mittag Startzeit:");
        labelMittagZeitStartEingabe.setFont(new Font("Calibri", Font.BOLD, 16));
        labelMittagZeitStartEingabe.setPreferredSize(new Dimension(230, 30));

        final JTextField textFieldMittagZeitStart = new JTextField(MittagStartEingabe);
        textFieldMittagZeitStart.setFont(new Font("Calibri", Font.BOLD, 16));
        textFieldMittagZeitStart.setPreferredSize(new Dimension(230, 30));
        
        JLabel labelBeispielMittagZeitStartEingabe = new JLabel("z.B: 12.00");
        labelBeispielMittagZeitStartEingabe.setFont(new Font("Calibri", Font.ITALIC, 16));
        labelBeispielMittagZeitStartEingabe.setPreferredSize(new Dimension(230, 30)); 

        final JButton MittagZeitStartEingabeButton = new JButton("OK");
        MittagZeitStartEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        MittagZeitStartEingabeButton.setPreferredSize(new Dimension(230, 30));

        textFieldMittagZeitStart.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MittagZeitStartEingabeButton.doClick();
            }
        });                

        MittagZeitStartEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                MittagZeitStartEingabeButton.doClick();
            }
        });
                      
        final JLabel labelGetMittagZeitStart = new JLabel("Ausgabe Mittagzeit Start:");
        labelGetMittagZeitStart.setFont(new Font("Calibri", Font.BOLD, 16));
        labelGetMittagZeitStart.setPreferredSize(new Dimension(230, 30));    
        
        final JLabel MittagZeitStartAusgabeGetLabel = new JLabel("");

//        MittagZeitStartAusgabeGetLabel.setText(MittagStartEingabe);
        MittagZeitStartAusgabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        MittagZeitStartAusgabeGetLabel.setPreferredSize(new Dimension(230, 30));          
        
        MittagZeitStartEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {

                        labelGetMittagZeitStart.setForeground(Color.black);                                   
                        labelGetMittagZeitStart.setFont(new Font("Calibri", Font.BOLD, 16));   
                        labelGetMittagZeitStart.setText("Ausgabe Mittag- Startzeit:");  

                        MittagStartEingabe = textFieldMittagZeitStart.getText();

                        MittagZeitStartAusgabeGetLabel.setText("" + MittagStartEingabe);
                        MittagZeitStartAusgabeGetLabel.setForeground(Color.green);             
                                
                        setMittagStartEingabe(MittagStartEingabe);
                        System.out.println(MittagStartEingabe);
                        MittagZeitStartAusgabeGetLabel.setText("" + getMittagStartEingabe());   
                        
//***************************************************************************************************************************************
//                stringKleinePauseGesamt = textFieldKleinePauseGesamt.getText();
//
                if (MittagStartEingabe.length() == 0) {
                    MittagStartEingabe = "0.0";
                    labelGetMittagZeitStart.setForeground(Color.black);
                    splittStringXX(MittagStartEingabe, split);
//                    setKleinePauseGesamtStunden(stunde);
//                    setKleinePauseGesamtMinuten(minute);
                    eingabePrueferXX(stunde, minute, falscheZeitEingabe);
                }
//                    labelGetKleinePauseGesamt.setText("" + getKleinePauseGesamtStunden() + " h " + getKleinePauseGesamtMinuten() + " min");
//                } else if ((stringKleinePauseGesamt.matches("[0-9]" + "[0-9]" + "[0-9]" + "[0-9]"))
//                        || (stringKleinePauseGesamt.matches("[0-9]" + "[0-9]" + "[;,.:/ -]" + "[0-9]" + "[0-9]"))
//                        || (stringKleinePauseGesamt.matches("[0-9]" + "[;,.:/ -]" + "[0-9]" + "[0-9]"))
//                        || (stringKleinePauseGesamt.matches("[0-9]" + "[0-9]" + "[0-9]"))
//                        || (stringKleinePauseGesamt.matches("[0-9]" + "[0-9]"))
//                        || (stringKleinePauseGesamt.matches("[0-9]"))
//                        && (falscheZeitEingabe != true)) {// || (stringKleinePauseGesamt.length()==0))
//
//                    labelGetKleinePauseGesamt.setForeground(Color.black);
// ///                   splittStringXX(stringKleinePauseGesamt, split);
//                    setKleinePauseGesamtStunden(stunde);
//                    setKleinePauseGesamtMinuten(minute);
//
//                    eingabePrueferXX(stunde, minute, falscheZeitEingabe);
//
//                    if (falscheMinutenEingabe == true) {
//                        System.err.println("Fehlerhafte Minuten-Eingabe!!!");
//                        labelGetKleinePauseGesamt.setForeground(Color.red);
//                        labelGetKleinePauseGesamt.setText(getKleinePauseGesamtMinuten() + " min Minuten?! Fehlerhafte Minuten!!!");
//                    } else if (falscheStundenEingabe == true) {
//                        System.err.println("Fehlerhafte Stunden-Eingabe!!!");
//                        labelGetKleinePauseGesamt.setForeground(Color.red);
//                        labelGetKleinePauseGesamt.setText(getKleinePauseGesamtStunden() + " h  Stunden?! Fehlerhafte Stunden!!!");
//                    } else if (falscheMinutenEingabe == false && falscheStundenEingabe == false) {
//                        labelGetKleinePauseGesamt.setText("" + getKleinePauseGesamtStunden() + " h " + getKleinePauseGesamtMinuten() + " min");
//                    }
//                } else {
//                    System.err.println("Fehlerhafte Eingabe!!!");
//                    labelGetKleinePauseGesamt.setForeground(Color.red);
//                    labelGetKleinePauseGesamt.setText("Fehlerhafte Eingabe!!!");
//                }
//
//                BerechneArbeitsZeitMitPause();
//                Zeit24Rechner(getStringBerechnetArbeitsZeitEndeMitPauseStunden(), getStringBerechnetArbeitsZeitEndeMitPauseMinuten());
//
//                setStringBerechnetArbeitsZeitEndeMitPauseStunden(stundeEnde);
//              
//                int i = Integer.parseInt(minuteEnde);
//                if(i > 10 || i == 10){                   
//                    setStringBerechnetArbeitsZeitEndeMitPauseMinuten(minuteEnde);
//                    //System.out.println("Hallo Neu Jahr: " + minuteEnde);
//                }else{
//                    setStringBerechnetArbeitsZeitEndeMitPauseMinuten("0" + minuteEnde);
//                    //System.out.println("Hallo Neu Jahr: mit zero " + minuteEnde);
//                }
//                
//                //setStringBerechnetArbeitsZeitEndeMitPauseMinuten(minuteEnde);
//                //System.out.println("Hallo Neu Jahr: minuteEnde " + minuteEnde);
//                labelGetArbeitsZeitEndeMitPause.setText("" + getStringBerechnetArbeitsZeitEndeMitPauseStunden() + " : " + getStringBerechnetArbeitsZeitEndeMitPauseMinuten() + " Uhr");
//
//       TODO êingabe absichern und überprüfen
                        
//***************************************************************************************************************************************                        
                        
            }
        });

    

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 25;
        add(labelMittagZeitStartEingabe, c);         
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 25;
        add(textFieldMittagZeitStart, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 25;
        add(labelBeispielMittagZeitStartEingabe, c);        

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 25;
        add(MittagZeitStartEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 6;
        c.gridy = 25;
        add(labelGetMittagZeitStart, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 7;
        c.gridy = 25;
        add(MittagZeitStartAusgabeGetLabel, c);            
//------------------------------------------------------------------------------        
//------------------------------------------------------------------------------        
               
        JLabel labelMittagZeitEndeEingabe = new JLabel("Mittag Endezeit:");
        labelMittagZeitEndeEingabe.setFont(new Font("Calibri", Font.BOLD, 16));
        labelMittagZeitEndeEingabe.setPreferredSize(new Dimension(230, 30));

        final JTextField textFieldMittagZeitEnde = new JTextField(MittagEndeEingabe);
        textFieldMittagZeitEnde.setFont(new Font("Calibri", Font.BOLD, 16));
        textFieldMittagZeitEnde.setPreferredSize(new Dimension(230, 30));
        
        JLabel labelBeispielMittagZeitEndeEingabe = new JLabel("z.B: 13.30");
        labelBeispielMittagZeitEndeEingabe.setFont(new Font("Calibri", Font.ITALIC, 16));
        labelBeispielMittagZeitEndeEingabe.setPreferredSize(new Dimension(230, 30)); 

        final JButton MittagZeitEndeEingabeButton = new JButton("Endezeit Mittag bestätigen");
        MittagZeitEndeEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        MittagZeitEndeEingabeButton.setPreferredSize(new Dimension(230, 30));

        textFieldMittagZeitEnde.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MittagZeitEndeEingabeButton.doClick();
            }
        });                

        MittagZeitEndeEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                MittagZeitEndeEingabeButton.doClick();
            }
        });
                      
        final JLabel labelGetMittagZeitEnde = new JLabel("Ausgabe Mittagzeit Ende:");
        labelGetMittagZeitEnde.setFont(new Font("Calibri", Font.BOLD, 16));
        labelGetMittagZeitEnde.setPreferredSize(new Dimension(230, 30));    
        
        final JLabel MittagZeitEndeAusgabeGetLabel = new JLabel("");

        MittagZeitEndeEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                        labelGetMittagZeitEnde.setForeground(Color.black);                                   
                        labelGetMittagZeitEnde.setFont(new Font("Calibri", Font.BOLD, 16));   
                        labelGetMittagZeitEnde.setText("Ausgabe Mittag- Endezeit:");  

                        MittagEndeEingabe = textFieldMittagZeitEnde.getText();

                        MittagZeitEndeAusgabeGetLabel.setText("" + MittagEndeEingabe);
                        MittagZeitEndeAusgabeGetLabel.setForeground(Color.green);             
                                
                        setMittagEndeEingabe(MittagEndeEingabe);
                        System.out.println(MittagEndeEingabe);
                        MittagZeitEndeAusgabeGetLabel.setText("" + getMittagEndeEingabe()); 
            }
        });

        MittagZeitEndeAusgabeGetLabel.setText(MittagEndeEingabe);
        MittagZeitEndeAusgabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        MittagZeitEndeAusgabeGetLabel.setPreferredSize(new Dimension(230, 30));      
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 26;
        add(labelMittagZeitEndeEingabe, c);         
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 26;
        add(textFieldMittagZeitEnde, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 26;
        add(labelBeispielMittagZeitEndeEingabe, c);        

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 26;
        add(MittagZeitEndeEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 6;
        c.gridy = 26;
        add(labelGetMittagZeitEnde, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 7;
        c.gridy = 26;
        add(MittagZeitEndeAusgabeGetLabel, c);                 
//******************************************************************************        
//*****************************Mittag*******************************************        
//------------------------------------------------------------------------------          
    }
//------------------------------------------------------------------------------

    public String getMittagStartEingabe() {
        return MittagStartEingabe;
    }

    public void setMittagStartEingabe(String MittagStartEingabe) {
        MittagStartEingabe = MittagStartEingabe;
    }       

    public String getMittagEndeEingabe() {
        return MittagEndeEingabe;
    }    
    
    public void setMittagEndeEingabe(String MittagEndeEingabe) {
        MittagEndeEingabe = MittagEndeEingabe;
    }   
            
    public void setBooleanUeberZeit(boolean booleanUeberZeit) {
        this.booleanUeberZeit = booleanUeberZeit;
    }

    public boolean getBooleanUeberZeit() {
        return booleanUeberZeit;
    }

    public void setKleinePauseGesamtMinuten(String stringKleinePauseGesamtMinuten) {
        this.stringKleinePauseGesamtMinuten = stringKleinePauseGesamtMinuten;
    }

    public String getKleinePauseGesamtMinuten() {
        return stringKleinePauseGesamtMinuten;
    }

    public void setKleinePauseGesamtStunden(String stringKleinePauseGesamtStunden) {
        this.stringKleinePauseGesamtStunden = stringKleinePauseGesamtStunden;
    }

    public String getKleinePauseGesamtStunden() {
        return stringKleinePauseGesamtStunden;
    }

    public void setArbeitsZeitMinuten(String stringArbeitsZeitMinuten) {
        this.stringArbeitsZeitMinuten = stringArbeitsZeitMinuten;
    }

    public String getArbeitsZeitMinuten() {
        return stringArbeitsZeitMinuten;
    }

    public void setArbeitsZeitStunden(String stringArbeitsZeitStunden) {
        this.stringArbeitsZeitStunden = stringArbeitsZeitStunden;
    }

    public String getArbeitsZeitStunden() {
        return stringArbeitsZeitStunden;
    }

    public void setArbeitsZeit(String stringArbeitsZeit) {
        this.stringArbeitsZeit = stringArbeitsZeit;
    }

    public String getArbeitsZeit() {
        return stringArbeitsZeit;
    }

    public void setStringZeitBerechnetMinusAbzugStartEndeStunden(String stringZeitBerechnetMinusAbzugStartEndeStunden) {
        this.stringZeitBerechnetMinusAbzugStartEndeStunden = stringZeitBerechnetMinusAbzugStartEndeStunden;
    }

    public String getStringZeitBerechnetMinusAbzugStartEndeStunden() {
        return stringZeitBerechnetMinusAbzugStartEndeStunden;
    }

    public void setStringZeitBerechnetMinusAbzugStartEndeMinuten(String stringZeitBerechnetMinusAbzugStartEndeMinuten) {
        this.stringZeitBerechnetMinusAbzugStartEndeMinuten = stringZeitBerechnetMinusAbzugStartEndeMinuten;
    }

    public String getStringZeitBerechnetMinusAbzugStartEndeMinuten() {
        return stringZeitBerechnetMinusAbzugStartEndeMinuten;
    }

    public void setStringZeitBerechnetZwischenStartUndEndeStunden(String stringZeitBerechnetZwischenStartUndEndeStunden) {
        this.stringZeitBerechnetZwischenStartUndEndeStunden = stringZeitBerechnetZwischenStartUndEndeStunden;
    }

    public String getStringZeitBerechnetZwischenStartUndEndeStunden() {
        return stringZeitBerechnetZwischenStartUndEndeStunden;
    }

    public void setStringZeitBerechnetZwischenStartUndEndeMinuten(String stringZeitBerechnetZwischenStartUndEndeMinuten) {
        this.stringZeitBerechnetZwischenStartUndEndeMinuten = stringZeitBerechnetZwischenStartUndEndeMinuten;
    }

    public String getStringZeitBerechnetZwischenStartUndEndeMinuten() {
        return stringZeitBerechnetZwischenStartUndEndeMinuten;
    }

    public void setStringBerechnetArbeitsZeitEndeOhnePauseStunden(String stringBerechnetArbeitsZeitEndeOhnePauseStunden) {
        this.stringZeitBerechnetArbeitsZeitEndeOhnePauseStunden = stringBerechnetArbeitsZeitEndeOhnePauseStunden;
    }

    public String getStringBerechnetArbeitsZeitEndeOhnePauseStunden() {
        return stringZeitBerechnetArbeitsZeitEndeOhnePauseStunden;
    }

    public void setStringBerechnetArbeitsZeitEndeOhnePauseMinuten(String stringBerechnetArbeitsZeitEndeOhnePauseMinuten) {
        this.stringZeitBerechnetArbeitsZeitEndeOhnePauseMinuten = stringBerechnetArbeitsZeitEndeOhnePauseMinuten;
    }

    public String getStringBerechnetArbeitsZeitEndeOhnePauseMinuten() {
        return stringZeitBerechnetArbeitsZeitEndeOhnePauseMinuten;
    }

    public void setStringMomentanStunden(String stringMomentanStunden) {
        this.stringMomentanStunden = stringMomentanStunden;
    }

    public String getMomentanStunden() {
        return stringMomentanStunden;
    }

    public void setStringMomentanMinuten(String stringMomentanMinuten) {
        this.stringMomentanMinuten = stringMomentanMinuten;
    }

    public String getMomentanMinuten() {
        return stringMomentanMinuten;
    }

    public void setStringBerechnetArbeitsZeitEndeMitPauseStunden(String stringBerechnetArbeitsZeitEndeMitPauseStunden) {
        this.stringZeitBerechnetArbeitsZeitEndeMitPauseStunden = stringBerechnetArbeitsZeitEndeMitPauseStunden;
    }

    public String getStringBerechnetArbeitsZeitEndeMitPauseStunden() {
        return stringZeitBerechnetArbeitsZeitEndeMitPauseStunden;
    }

    public void setStringBerechnetArbeitsZeitEndeMitPauseMinuten(String stringBerechnetArbeitsZeitEndeMitPauseMinuten) {
        this.stringZeitBerechnetArbeitsZeitEndeMitPauseMinuten = stringBerechnetArbeitsZeitEndeMitPauseMinuten;
    }

    public String getStringBerechnetArbeitsZeitEndeMitPauseMinuten() {
        return stringZeitBerechnetArbeitsZeitEndeMitPauseMinuten;
    }

    public void setStringZeitBerechnetVergleichArbeitsZeitStunden(String stringZeitBerechnetVergleichArbeitsZeitStunden) {
        this.stringZeitBerechnetVergleichArbeitsZeitStunden = stringZeitBerechnetVergleichArbeitsZeitStunden;
    }

    public String getStringZeitBerechnetVergleichArbeitsZeitStunden() {
        return stringZeitBerechnetVergleichArbeitsZeitStunden;
    }

    public void setStringZeitBerechnetVergleichArbeitsZeitMinuten(String stringZeitBerechnetVergleichArbeitsZeitMinuten) {
        this.stringZeitBerechnetVergleichArbeitsZeitMinuten = stringZeitBerechnetVergleichArbeitsZeitMinuten;
    }

    public String getStringZeitBerechnetVergleichArbeitsZeitMinuten() {
        return stringZeitBerechnetVergleichArbeitsZeitMinuten;
    }

    public void ausgeben(String ausgeben) {
        System.out.println("Ihre Ausgabe lautet: " + ausgeben);
    }

    public void setFalscheMinutenEingabe(boolean falscheMinutenEingabe) {
        this.falscheMinutenEingabe = falscheMinutenEingabe;
    }

    public boolean getFalscheMinutenEingabe() {
        return falscheMinutenEingabe;
    }

    public void setFalscheStundenEingabe(boolean falscheMinutenEingabe) {
        this.falscheStundenEingabe = falscheStundenEingabe;
    }

    public boolean getFalscheStundenEingabe() {
        return falscheStundenEingabe;
    }

    public void setFalscheZeitEingabe(boolean falscheZeitEingabe) {
        this.falscheZeitEingabe = falscheZeitEingabe;
    }

    public boolean getFalscheZeitEingabe() {
        return falscheZeitEingabe;
    }

    public void setStringArbeitsZeitStart(String stringArbeitsZeitStart) {
        this.stringArbeitsZeitStart = stringArbeitsZeitStart;
    }

    public String getStringArbeitsZeitStart() {
        return stringArbeitsZeitStart;
    }

    public void setStringArbeitsZeitEnde(String stringArbeitsZeitEnde) {
        this.stringArbeitsZeitEnde = stringArbeitsZeitEnde;
    }

    public String getStringArbeitsZeitEnde() {
        return stringArbeitsZeitEnde;
    }

    public void setMinutenEnde(String minuteEnde) {
        this.minuteEnde = minuteEnde;
    }

    public String getMinutenEnde() {
        return minuteEnde;
    }

    public void setStundenEnde(String stundeEnde) {
        this.stundeEnde = stundeEnde;
    }

    public String getStundenEnde() {
        return stundeEnde;
    }

    public void setMinutenStart(String minuteStart) {
        this.minuteStart = minuteStart;
    }

    public String getMinutenStart() {
        return minuteStart;
    }

    public void setStundenStart(String stundeStart) {
        this.stundeStart = stundeStart;
    }

    public String getStundenStart() {
        return stundeStart;
    }

    public void setBooleanNacht(boolean booleanNacht) {
        this.booleanNacht = booleanNacht;
    }

    public boolean getBooleanNacht() {
        return booleanNacht;
    }

    public void setStringNochZuArbeitendeZeitOhnePauseStunden(String stringNochZuArbeitendeZeitOhnePauseStunden) {
        this.stringNochZuArbeitendeZeitOhnePauseStunden = stringNochZuArbeitendeZeitOhnePauseStunden;
    }

    public String getStringNochZuArbeitendeZeitOhnePauseStunden() {
        return stringNochZuArbeitendeZeitOhnePauseStunden;
    }

    public void setStringNochZuArbeitendeZeitOhnePauseMinuten(String stringNochZuArbeitendeZeitOhnePauseMinuten) {
        this.stringNochZuArbeitendeZeitOhnePauseMinuten = stringNochZuArbeitendeZeitOhnePauseMinuten;
    }

    public String getStringNochZuArbeitendeZeitOhnePauseMinuten() {
        return stringNochZuArbeitendeZeitOhnePauseMinuten;
    }

    public void setStringNochZuArbeitendeZeitMitPauseStunden(String stringNochZuArbeitendeZeitMitPauseStunden) {
        this.stringNochZuArbeitendeZeitMitPauseStunden = stringNochZuArbeitendeZeitMitPauseStunden;
    }

    public String getStringNochZuArbeitendeZeitMitPauseStunden() {
        return stringNochZuArbeitendeZeitMitPauseStunden;
    }

    public void setStringNochZuArbeitendeZeitMitPauseMinuten(String stringNochZuArbeitendeZeitMitPauseMinuten) {
        this.stringNochZuArbeitendeZeitMitPauseMinuten = stringNochZuArbeitendeZeitMitPauseMinuten;
    }

    public String getStringNochZuArbeitendeZeitMitPauseMinuten() {
        return stringNochZuArbeitendeZeitMitPauseMinuten;
    }
    
    public void setBooleanArbeitsZeitEreicht(boolean booleanArbeitsZeitEreicht) {
        this.booleanArbeitsZeitEreicht = booleanArbeitsZeitEreicht;
    }

    public boolean getBooleanArbeitsZeitEreicht() {
        return booleanArbeitsZeitEreicht;
    }    
    
    public void setStringEingabeMinuten (String stringEingabeMinuten) {
        this.stringEingabeMinuten = stringEingabeMinuten;
    }

    public String getStringEingabeMinuten() {
        return stringEingabeMinuten;
    }    
    
    public void setStringEingabeStunden (String stringEingabeStunden){
            this.stringEingabeStunden = stringEingabeStunden;
    }

    public String getStringEingabeStunden() {
        return stringEingabeStunden;
    }    

    public void setStringAusgabeMinuten (String stringAusgabeMinuten) {
        this.stringAusgabeMinuten = stringAusgabeMinuten;
    }

    public String getStringAusgabeMinuten() {
        return stringAusgabeMinuten;
    }    
    
    public void setStringAusgabeStunden (String stringAusgabeStunden){
            this.stringAusgabeStunden = stringAusgabeStunden;
    }

    public String getStringAusgabeStunden() {
        return stringAusgabeStunden;
    }    

    // String stringNochZuArbeitendeZeit = "";
    
    public void setStringGearbeitendeArbeitszeit (String stringGearbeiteteArbeitszeit){
        this.stringGearbeiteteArbeitszeit = stringGearbeiteteArbeitszeit;
    }
    
    public String getStringGearbeitendeArbeitszeit(){
        return stringGearbeiteteArbeitszeit;
    }

    public void setStringNochZuArbeitendeZeit (String stringNochZuArbeitendeZeit){
        this.stringNochZuArbeitendeZeit = stringNochZuArbeitendeZeit;
    }
    
    public String getStringNochZuArbeitendeZeit(){
        return stringNochZuArbeitendeZeit;
    }
//------------------------------------------------------------------------------

    public String BerechneNochZuArbeitendeZeitOhnePausen() {

        int stundeNAZOP = 0;
        int minuteNAZOP = 0;

        int StundeEnde = Integer.parseInt(this.getStundenEnde());
        int minuteEnde = Integer.parseInt(this.getMinutenEnde());

        int stundePauseA = 0;
        int minutePauseA = 0;
        
        if (
              (getStringBerechnetArbeitsZeitEndeOhnePauseStunden().length() == 0 || getArbeitsZeit().length()==0 || this.getMinutenEnde().length()==0) ||
              (  ( Integer.parseInt(this.getArbeitsZeitStunden())==0 && Integer.parseInt(this.getArbeitsZeitMinuten())==0) || this.getBooleanArbeitsZeitEreicht()==true)   
             || this.getBooleanUeberZeit()==true
                ){
            stundeNAZOP = 0;
            minuteNAZOP = 0;         
        } 
        else {
            System.out.println("geht in zweite Schlaufe");
            stundePauseA = Integer.parseInt(this.getStringBerechnetArbeitsZeitEndeOhnePauseStunden());
            minutePauseA = Integer.parseInt(this.getStringBerechnetArbeitsZeitEndeOhnePauseMinuten());
                
            if(minutePauseA > minuteEnde && stundePauseA > StundeEnde){
                minuteNAZOP = minutePauseA - minuteEnde;
                stundeNAZOP = stundePauseA - StundeEnde;
            } else if(minutePauseA < minuteEnde && stundePauseA < StundeEnde){
                minuteNAZOP = minuteEnde - minutePauseA;
                stundeNAZOP = StundeEnde - stundePauseA;
                
                        //1700                     16.52
             //            00         18                17             08                
            } else if(minutePauseA < minuteEnde && stundePauseA > StundeEnde){
                minuteNAZOP = minuteEnde - minutePauseA;
                stundeNAZOP = stundePauseA - StundeEnde;         
               // 1750   1703
                     
            } else if(minutePauseA > minuteEnde && stundePauseA < StundeEnde){
                minuteNAZOP = minutePauseA - minuteEnde;
                stundeNAZOP = StundeEnde - stundePauseA;
//                if(stundePauseA - StundeEnde==1){
//                    stundeNAZMP = 0;
//                } else{
//                    stundeNAZMP = stundePauseA - StundeEnde;
//                }      
            } else if(minutePauseA == minuteEnde && stundePauseA == StundeEnde){
                minuteNAZOP = 0;
                stundeNAZOP = 0;                    
            } else if(minutePauseA == minuteEnde && stundePauseA < StundeEnde){
                minuteNAZOP = 0;
                stundeNAZOP = StundeEnde - stundePauseA;
            } else if(minutePauseA == minuteEnde && stundePauseA > StundeEnde){
                minuteNAZOP = 0;
                stundeNAZOP = stundePauseA - StundeEnde;       
            } else if(minutePauseA < minuteEnde && stundePauseA == StundeEnde){
                minuteNAZOP = minuteEnde - minutePauseA;
                stundeNAZOP = 0;
            } else if(minutePauseA > minuteEnde && stundePauseA == StundeEnde){
                minuteNAZOP = minutePauseA - minuteEnde;
                stundeNAZOP = 0;
            }                            
        }

        this.setStringNochZuArbeitendeZeitOhnePauseStunden(Integer.toString(stundeNAZOP));
        this.setStringNochZuArbeitendeZeitOhnePauseMinuten(Integer.toString(minuteNAZOP));

        return stringNochZuArbeitendeZeitOhnePauseStunden + stringNochZuArbeitendeZeitOhnePauseMinuten;
    }

    public String BerechneNochZuArbeitendeZeit(String stringEingabeStunden, String stringEingabeMinuten) { 

    //    ausgeben(stringEingabeStunden + "    haaaaalllloooo");
        
        int stundeNAZMP = 0;
        int minuteNAZMP = 0;

        int StundeEnde = Integer.parseInt(this.getStundenEnde());
        int minuteEnde = Integer.parseInt(this.getMinutenEnde());

        int stundePauseA = 0;
        int minutePauseA = 0;
      
        System.out.println(this.booleanUeberZeit + " überzeitboolean");
        
        if (
              (getStringEingabeMinuten().length() == 0 || getArbeitsZeit().length()==0 || this.getMinutenEnde().length()==0) ||
              (  ( Integer.parseInt(this.getArbeitsZeitStunden())==0 && Integer.parseInt(this.getArbeitsZeitMinuten())==0) || this.getBooleanArbeitsZeitEreicht()==true)   
             || this.getBooleanUeberZeit()==true
                ){
            stundeNAZMP = 0;
            minuteNAZMP = 0;
        } 
        else {
            System.out.println("geht in zweite Schlaufe");
            stundePauseA = Integer.parseInt(getStringEingabeStunden());
            minutePauseA = Integer.parseInt(getStringEingabeMinuten());
                
            if(minutePauseA > minuteEnde && stundePauseA > StundeEnde){
                minuteNAZMP = minutePauseA - minuteEnde;
                stundeNAZMP = stundePauseA - StundeEnde;
            } else if(minutePauseA < minuteEnde && stundePauseA < StundeEnde){
                minuteNAZMP = minuteEnde - minutePauseA;
                stundeNAZMP = StundeEnde - stundePauseA;
                
                        //1700                     16.52
             //            00         18                17             08                
            } else if(minutePauseA < minuteEnde && stundePauseA > StundeEnde){
                minuteNAZMP = minuteEnde - minutePauseA;
                stundeNAZMP = stundePauseA - StundeEnde;         
               // 1750   1703
                     
            } else if(minutePauseA > minuteEnde && stundePauseA < StundeEnde){
                minuteNAZMP = minutePauseA - minuteEnde;
                stundeNAZMP = StundeEnde - stundePauseA;
//                if(stundePauseA - StundeEnde==1){
//                    stundeNAZMP = 0;
//                } else{
//                    stundeNAZMP = stundePauseA - StundeEnde;
//                }      
            } else if(minutePauseA == minuteEnde && stundePauseA == StundeEnde){
                minuteNAZMP = 0;
                stundeNAZMP = 0;                    
            } else if(minutePauseA == minuteEnde && stundePauseA < StundeEnde){
                minuteNAZMP = 0;
                stundeNAZMP = StundeEnde - stundePauseA;
            } else if(minutePauseA == minuteEnde && stundePauseA > StundeEnde){
                minuteNAZMP = 0;
                stundeNAZMP = stundePauseA - StundeEnde;       
            } else if(minutePauseA < minuteEnde && stundePauseA == StundeEnde){
                minuteNAZMP = minuteEnde - minutePauseA;
                stundeNAZMP = 0;
            } else if(minutePauseA > minuteEnde && stundePauseA == StundeEnde){
                minuteNAZMP = minutePauseA - minuteEnde;
                stundeNAZMP = 0;
            }                            
        }

        this.setStringAusgabeStunden(Integer.toString(stundeNAZMP));
        this.setStringAusgabeMinuten(Integer.toString(minuteNAZMP));
//
        //return stringNochZuArbeitendeZeitMitPauseStunden + stringNochZuArbeitendeZeitMitPauseMinuten;
        return stringAusgabeStunden + stringAusgabeMinuten;
    }

//------------------------------------------------------------------------------
    public String BerechneArbeitsZeitMitPause() {

        int stundeAZOP = 0;
        int minuteAZOP = 0;
        int stundeKPGM = 0;
        int minuteKPGM = 0;
        int stundeAZMP = 0;
        int minuteAZMP = 0;

        if (getStringBerechnetArbeitsZeitEndeOhnePauseStunden().length() == 0 || getKleinePauseGesamtStunden().length() == 0 || getStundenStart().length() == 0) {
            stundeAZMP = 0;
            minuteAZMP = 0;
        } else {
            stundeAZOP = Integer.parseInt(this.getStringBerechnetArbeitsZeitEndeOhnePauseStunden());
            minuteAZOP = Integer.parseInt(this.getStringBerechnetArbeitsZeitEndeOhnePauseMinuten());
            stundeKPGM = Integer.parseInt(this.getKleinePauseGesamtStunden());
            minuteKPGM = Integer.parseInt(this.getKleinePauseGesamtMinuten());
            stundeAZMP = Integer.parseInt(this.getStundenStart());
            minuteAZMP = Integer.parseInt(this.getMinutenStart());
            stundeAZMP = stundeAZOP + stundeKPGM;
            minuteAZMP = minuteAZOP + minuteKPGM;
        }

        setStringBerechnetArbeitsZeitEndeMitPauseStunden(Integer.toString(stundeAZMP));
        setStringBerechnetArbeitsZeitEndeMitPauseMinuten(Integer.toString(minuteAZMP));

        return stringZeitBerechnetArbeitsZeitEndeMitPauseStunden + stringZeitBerechnetArbeitsZeitEndeMitPauseMinuten;
    }

    public String berechneArbeitsZeitEndeOhnePause() {
        
        int stundeAZMP = 0;
        int minuteAZMP = 0;
        int stundeMZ = 0;
        int minuteMZ = 0;
        int stundeAZOP = 0;
        int minuteAZOP = 0;

        if (getStundenStart().length() == 0) {
            stundeAZMP = 0;
            minuteAZMP = 0;
            stundeAZOP = stundeAZMP + stundeMZ;
            minuteAZOP = minuteAZMP + minuteMZ;
            stringZeitBerechnetArbeitsZeitEndeOhnePauseStunden = Integer.toString(stundeAZOP);
            stringZeitBerechnetArbeitsZeitEndeOhnePauseMinuten = Integer.toString(minuteAZOP);
        } else {
            stundeAZMP = Integer.parseInt(this.getStundenStart());
            minuteAZMP = Integer.parseInt(this.getMinutenStart());
            if (this.stringAnwesenheitszeit.length() == 0) {
                stundeMZ = Integer.parseInt(this.getMomentanStunden());
                minuteMZ = Integer.parseInt(this.getMomentanMinuten());

                labelGetListArbeitsZeiten.setForeground(Color.red);
                labelGetListArbeitsZeiten.setText("Keine Präsenzzeit angewählt");
                stringZeitBerechnetArbeitsZeitEndeOhnePauseStunden = getMomentanStunden();
                stringZeitBerechnetArbeitsZeitEndeOhnePauseMinuten = getMomentanMinuten() + " Momentane ";
            } else {
                stundeMZ = Integer.parseInt(this.getArbeitsZeitStunden());
                minuteMZ = Integer.parseInt(this.getArbeitsZeitMinuten());
                stundeAZOP = stundeAZMP + stundeMZ;
                minuteAZOP = minuteAZMP + minuteMZ;
                stringZeitBerechnetArbeitsZeitEndeOhnePauseStunden = Integer.toString(stundeAZOP);
                stringZeitBerechnetArbeitsZeitEndeOhnePauseMinuten = Integer.toString(minuteAZOP);
            }
        }
        return stringZeitBerechnetArbeitsZeitEndeOhnePauseStunden + stringZeitBerechnetArbeitsZeitEndeOhnePauseMinuten;
    }
  
    public String BerechneZeitVergleichArbeitsZeit() {

        int stundeAZ = Integer.parseInt(getArbeitsZeitStunden());
        int minuteAZ = Integer.parseInt(getArbeitsZeitMinuten());

        int stundeMA = 0;
        int minuteMA = 0;

        int stundeMSE = 0;
        int minuteMSE = 0;

        if (this.getArbeitsZeitStunden().length() == 0) {
            this.labelGetListArbeitsZeiten = new JLabel("Anwesenheitszeit eingeben");
            stundeMSE = 0;
            minuteMSE = 0;
        } else if (this.getStringArbeitsZeitStart().length() == 0) {
            this.labelGetArbeitsZeitStart = new JLabel("Arbeits-Startzeit eingeben");
            stundeMSE = 0;
            minuteMSE = 0;
        } else if (this.getStringBerechnetArbeitsZeitEndeMitPauseMinuten().length() == 0 || getStringBerechnetArbeitsZeitEndeMitPauseStunden().length() == 0) {

            stundeMA = Integer.parseInt(this.getStringBerechnetArbeitsZeitEndeOhnePauseStunden());
            minuteMA = Integer.parseInt(this.getStringBerechnetArbeitsZeitEndeOhnePauseMinuten());

            if (Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseStunden()) < Integer.parseInt(this.getStundenEnde())
                    && Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseMinuten()) < Integer.parseInt(this.getMinutenEnde())) {
                stundeMSE = Integer.parseInt(getStundenEnde()) - stundeMA;
                minuteMSE = Integer.parseInt(getMinutenEnde()) - minuteMA;
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.green.darker());
                booleanUeberZeit = true;
                setBooleanUeberZeit(booleanUeberZeit);
            } else if ((Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseStunden()) < (Integer.parseInt(this.getStundenEnde()))
                    && (Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseMinuten())) == (Integer.parseInt(this.getMinutenEnde())))) {
                stundeMSE = Integer.parseInt(getStundenEnde()) - stundeMA;
                minuteMSE = 0;
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.green.darker());
                booleanUeberZeit = true;
                setBooleanUeberZeit(booleanUeberZeit);
            } else if ((Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseStunden()) == (Integer.parseInt(this.getStundenEnde()))
                    && (Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseMinuten())) < (Integer.parseInt(this.getMinutenEnde())))) {
                stundeMSE = 0;
                minuteMSE = Integer.parseInt(getMinutenEnde()) - minuteMA;
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.green.darker());
                booleanUeberZeit = true;
                setBooleanUeberZeit(booleanUeberZeit);
            } else if ((Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseStunden()) == (Integer.parseInt(this.getStundenEnde()))
                    && (Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseMinuten())) == (Integer.parseInt(this.getMinutenEnde())))) {
                stundeMSE = 0;
                minuteMSE = 0;
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.cyan.darker());
                booleanUeberZeit = false;
                booleanArbeitsZeitEreicht = true;
                setBooleanArbeitsZeitEreicht(booleanArbeitsZeitEreicht);
                setBooleanUeberZeit(booleanUeberZeit);
            } else if ((Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseStunden()) == (Integer.parseInt(this.getStundenEnde()))
                    && (Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseMinuten())) > (Integer.parseInt(this.getMinutenEnde())))) {
                stundeMSE = 0;
                minuteMSE = minuteMA - Integer.parseInt(getMinutenEnde());
                booleanUeberZeit = false;
                setBooleanUeberZeit(booleanUeberZeit);
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.red.darker());
            } else if ((Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseStunden()) > (Integer.parseInt(getStundenEnde()))
                    && (Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseMinuten())) == (Integer.parseInt(this.getMinutenEnde())))) {
                stundeMSE = stundeMA - Integer.parseInt(getStundenEnde());
                minuteMSE = 0;
                booleanUeberZeit = false;
                setBooleanUeberZeit(booleanUeberZeit);
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.red.darker());
            } else if ((Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseStunden()) > (Integer.parseInt(getStundenEnde()))
                    && (Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseMinuten())) > (Integer.parseInt(this.getMinutenEnde())))) {
                stundeMSE = stundeMA - Integer.parseInt(getStundenEnde());
                minuteMSE = minuteMA - Integer.parseInt(getMinutenEnde());
                booleanUeberZeit = false;
                setBooleanUeberZeit(booleanUeberZeit);
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.red.darker());
            } else if ((Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseStunden()) > (Integer.parseInt(getStundenEnde()))
                    && (Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseMinuten())) < (Integer.parseInt(this.getMinutenEnde())))) {
                stundeMSE = stundeMA - Integer.parseInt(getStundenEnde())-1;
                minuteMSE = (60-Integer.parseInt(getMinutenEnde())) + minuteMA;
                booleanUeberZeit = false;
                setBooleanUeberZeit(booleanUeberZeit);
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.red.darker());
            } else if ((Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseStunden()) < (Integer.parseInt(getStundenEnde()))
                    && (Integer.parseInt(getStringBerechnetArbeitsZeitEndeOhnePauseMinuten())) > (Integer.parseInt(this.getMinutenEnde())))) {
                if (Integer.parseInt(getStundenEnde()) - stundeMA == 1) {
                    stundeMSE = 0;
                    minuteMSE = (60 - minuteMA);
                } else {
                    stundeMSE = Integer.parseInt(getStundenEnde()) - stundeMA - 1;
                    minuteMSE = (60 - minuteMA) + Integer.parseInt(getMinutenEnde());
                }
                booleanUeberZeit = true;
                setBooleanUeberZeit(booleanUeberZeit);
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.green.darker());
            }
        } else {

            stundeMA = Integer.parseInt(this.getStringBerechnetArbeitsZeitEndeMitPauseStunden());
            minuteMA = Integer.parseInt(this.getStringBerechnetArbeitsZeitEndeMitPauseMinuten());

            if ((Integer.parseInt(this.getStringBerechnetArbeitsZeitEndeMitPauseStunden()) > Integer.parseInt(this.getStundenEnde()))
                    && (Integer.parseInt(getStringBerechnetArbeitsZeitEndeMitPauseMinuten()) > Integer.parseInt(this.getMinutenEnde()))) {

                minuteMSE = minuteMA - Integer.parseInt(getMinutenEnde());
                stundeMSE = stundeMA - Integer.parseInt(getStundenEnde());
                booleanUeberZeit = false;
                setBooleanUeberZeit(booleanUeberZeit);
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.red.darker());

            } else if ((Integer.parseInt(getStringBerechnetArbeitsZeitEndeMitPauseStunden()) > (Integer.parseInt(getStundenEnde()))
                    && (Integer.parseInt(getStringBerechnetArbeitsZeitEndeMitPauseMinuten())) == (Integer.parseInt(getMinutenEnde())))) {
                stundeMSE = stundeMA - Integer.parseInt(getStundenEnde());
                minuteMSE = 0;
                booleanUeberZeit = false;
                setBooleanUeberZeit(booleanUeberZeit);
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.red.darker());
            } else if ((Integer.parseInt(getStringBerechnetArbeitsZeitEndeMitPauseStunden()) == (Integer.parseInt(getStundenEnde()))
                    && (Integer.parseInt(getStringBerechnetArbeitsZeitEndeMitPauseMinuten())) > (Integer.parseInt(getMinutenEnde())))) {
                stundeMSE = 0;
                minuteMSE = minuteMA - Integer.parseInt(getMinutenEnde());
                booleanUeberZeit = false;
                setBooleanUeberZeit(booleanUeberZeit);
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.red.darker());
            } else if ((Integer.parseInt(getStringBerechnetArbeitsZeitEndeMitPauseStunden()) == (Integer.parseInt(getStundenEnde()))
                    && (Integer.parseInt(getStringBerechnetArbeitsZeitEndeMitPauseMinuten())) == (Integer.parseInt(getMinutenEnde())))) {
                stundeMSE = 0;
                minuteMSE = 0;
                booleanUeberZeit = false;
                setBooleanUeberZeit(booleanUeberZeit);
                booleanArbeitsZeitEreicht = true;
                setBooleanArbeitsZeitEreicht(booleanArbeitsZeitEreicht);
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.cyan.darker());
            } else if ((Integer.parseInt(getStringBerechnetArbeitsZeitEndeMitPauseStunden()) == (Integer.parseInt(getStundenEnde()))
                    && (Integer.parseInt(getStringBerechnetArbeitsZeitEndeMitPauseMinuten())) < (Integer.parseInt(getMinutenEnde())))) {
                stundeMSE = 0;
                minuteMSE = Integer.parseInt(getMinutenEnde()) - minuteMA;
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.green.darker());
                booleanUeberZeit = true;
                setBooleanUeberZeit(booleanUeberZeit);
            } else if ((Integer.parseInt(getStringBerechnetArbeitsZeitEndeMitPauseStunden()) < (Integer.parseInt(getStundenEnde()))
                    && (Integer.parseInt(getStringBerechnetArbeitsZeitEndeMitPauseMinuten())) == (Integer.parseInt(getMinutenEnde())))) {
                stundeMSE = Integer.parseInt(getStundenEnde()) - stundeMA;
                minuteMSE = 0;
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.green.darker());
                booleanUeberZeit = true;
                setBooleanUeberZeit(booleanUeberZeit);
            } else if ((Integer.parseInt(getStringBerechnetArbeitsZeitEndeMitPauseStunden()) < (Integer.parseInt(getStundenEnde()))
                    && (Integer.parseInt(getStringBerechnetArbeitsZeitEndeMitPauseMinuten())) < (Integer.parseInt(getMinutenEnde())))) {
                stundeMSE = Integer.parseInt(getStundenEnde()) - stundeMA;
                minuteMSE = Integer.parseInt(getMinutenEnde()) - minuteMA;;
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.green.darker());
                booleanUeberZeit = true;
                setBooleanUeberZeit(booleanUeberZeit);
            } else if ((Integer.parseInt(getStringBerechnetArbeitsZeitEndeMitPauseStunden()) < (Integer.parseInt(getStundenEnde()))
                    && (Integer.parseInt(getStringBerechnetArbeitsZeitEndeMitPauseMinuten())) > (Integer.parseInt(getMinutenEnde())))) {
                if (Integer.parseInt(getStundenEnde()) - stundeMA == 1) {
                    stundeMSE = 0;
                    minuteMSE = (60 - minuteMA);                                                
                } else {
                    stundeMSE = Integer.parseInt(getStundenEnde()) - stundeMA - 1;
                    minuteMSE = (60 - minuteMA) + Integer.parseInt(getMinutenEnde());
                }
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.green.darker());
                booleanUeberZeit = true;
                setBooleanUeberZeit(booleanUeberZeit);
            } else if ((Integer.parseInt(getStringBerechnetArbeitsZeitEndeMitPauseStunden()) > (Integer.parseInt(getStundenEnde()))
                    && (Integer.parseInt(getStringBerechnetArbeitsZeitEndeMitPauseMinuten())) < (Integer.parseInt(getMinutenEnde())))) {          
                stundeMSE = stundeMA - Integer.parseInt(getStundenEnde())-1;
                minuteMSE = (60-Integer.parseInt(getMinutenEnde())) + minuteMA;
                this.labelGetBerechneZeitVergleichArbeitsZeit.setForeground(Color.red.darker());
                booleanUeberZeit = false;
                setBooleanUeberZeit(booleanUeberZeit);
            }
        }

        this.setStringZeitBerechnetVergleichArbeitsZeitStunden(Integer.toString(stundeMSE));
        this.setStringZeitBerechnetVergleichArbeitsZeitMinuten(Integer.toString(minuteMSE));

        return stringZeitBerechnetVergleichArbeitsZeitStunden + stringZeitBerechnetVergleichArbeitsZeitMinuten;
    }
//------------------------------------------------------------------------------    

    public String splittStringXX(String eingabe, boolean split) {

        //System.out.println(eingabe + " = Eingabe ");
        zaehler = 0;
        while (zaehler < eingabe.length()) {
            if (eingabe.substring(zaehler, zaehler + 1).equals(" ")) {
                split = true;
                String[] getrenntUhrzeitStart = eingabe.split("\\ ");
                stunde = getrenntUhrzeitStart[0];
                minute = getrenntUhrzeitStart[1];
            } else if (eingabe.substring(zaehler, zaehler + 1).equals(".")) {
                split = true;
                String[] getrenntUhrzeitStart = eingabe.split("\\.");
                stunde = getrenntUhrzeitStart[0];
                minute = getrenntUhrzeitStart[1];
            } else if (eingabe.substring(zaehler, zaehler + 1).equals(":")) {
                split = true;
                String[] getrenntUhrzeitStart = eingabe.split("\\:");
                stunde = getrenntUhrzeitStart[0];
                minute = getrenntUhrzeitStart[1];
            } else if (eingabe.substring(zaehler, zaehler + 1).equals(",")) {
                split = true;
                String[] getrenntUhrzeitStart = eingabe.split("\\,");
                stunde = getrenntUhrzeitStart[0];
                minute = getrenntUhrzeitStart[1];
            } else if (eingabe.substring(zaehler, zaehler + 1).equals(";")) {
                split = true;
                String[] getrenntUhrzeitStart = eingabe.split("\\;");
                stunde = getrenntUhrzeitStart[0];
                minute = getrenntUhrzeitStart[1];
            }
            zaehler++;
        }

        zaehler = 0;
        zaehler = eingabe.length();
        if (zaehler == 0) {
            System.err.println("Fehler, keine Eingabe und trotzdem gedrückt!!!");
        } else if (zaehler == 1 && !split) {
            stunde = eingabe.substring(0, 1);
            minute = "00";
        } else if (zaehler == 2 && !split) {
            stunde = eingabe.substring(0, 2);
            minute = "00";
        } else if (zaehler == 3 && !split) {
            stunde = eingabe.substring(0, 1);
            minute = eingabe.substring(1, eingabe.length());
        } else if (zaehler == 4 && !split) {
            stunde = eingabe.substring(0, 2);
            minute = eingabe.substring(2, eingabe.length());
        }

        return (minute + stunde);
    }
//------------------------------------------------------------------------------

    public boolean eingabePrueferXX(String minuten, String stunden, boolean falscheZeiteingabe) {

        falscheZeitEingabe = false;

        if (Integer.parseInt(stunde) > 23) {
            falscheStundenEingabe = true;
        } else if (Integer.parseInt(stunden) <= 23) {
            falscheStundenEingabe = false;
        }

        if (Integer.parseInt(minute) > 59) {
            falscheMinutenEingabe = true;
        } else if (Integer.parseInt(minute) <= 59) {
            falscheMinutenEingabe = false;
        }

        setFalscheMinutenEingabe(falscheMinutenEingabe);
        setFalscheStundenEingabe(falscheStundenEingabe);

        return falscheZeitEingabe;
    }

    public String BerechneZeitMinusAbzugStartEnde() {

        int stundeMSE = 0;
        int minuteMSE = 0;

        if (getStringZeitBerechnetZwischenStartUndEndeStunden().length() == 0 || getKleinePauseGesamtStunden().length() == 0) {
            stundeMSE = 0;
            minuteMSE = 0;
        } else {
            int stundeZSE = Integer.parseInt(getStringZeitBerechnetZwischenStartUndEndeStunden());
            int minuteZSE = Integer.parseInt(getStringZeitBerechnetZwischenStartUndEndeMinuten());
            int stundePause = Integer.parseInt(this.getKleinePauseGesamtStunden());
            int minutePause = Integer.parseInt(this.getKleinePauseGesamtMinuten());
            stundeMSE = stundeZSE - stundePause;
            minuteMSE = minuteZSE - minutePause;

            if (minuteMSE < 0) {
               // System.out.print("Zahl ist negativ");
                stundeMSE = stundeMSE - 1;
                minuteMSE = 60 - minuteMSE;
            }
            if (minuteMSE > 59) {
               // System.out.print("Zahl ist grösser 59");
                stundeMSE = stundeMSE;
                minuteMSE = 60 - (minuteMSE - 60);
            } else {
                stundeMSE = stundeZSE - stundePause;
                minuteMSE = minuteZSE - minutePause;
            }
        }

        stringZeitBerechnetMinusAbzugStartEndeStunden = Integer.toString(stundeMSE);
        stringZeitBerechnetMinusAbzugStartEndeMinuten = Integer.toString(minuteMSE);

        setStringZeitBerechnetMinusAbzugStartEndeStunden(stringZeitBerechnetMinusAbzugStartEndeStunden);
        setStringZeitBerechnetMinusAbzugStartEndeMinuten(stringZeitBerechnetMinusAbzugStartEndeMinuten);

        return stringZeitBerechnetMinusAbzugStartEndeStunden + stringZeitBerechnetMinusAbzugStartEndeMinuten;
    }

    public String BerechneZeitZwischenStartUndEnde() {
        int minuten = 0;
        int stunden = 0;
        int mStart = 0;
        int sStart = 0;
        int mEnde = 0;
        int sEnde = 0;
        int restMinuten = 60 - mStart;
        int restStunden = 24 - sStart;
        int mx = 60 - restMinuten - mEnde;
        int restTag = 0;
        int zeitMinuten = 0;

        if (getStundenStart().length() == 0 || getStundenEnde().length() == 0) {
            mStart = 0;
            sStart = 0;
            mEnde = 0;
            sEnde = 0;
        } else {
            mStart = Integer.parseInt(getMinutenStart());
            sStart = Integer.parseInt(getStundenStart());
            mEnde = Integer.parseInt(getMinutenEnde());
            sEnde = Integer.parseInt(getStundenEnde());

            if (sStart == sEnde && mEnde == mStart) {
                stunden = 0 + restTag * 24;
                minuten = 0;
            }
            if (sStart == sEnde && mEnde > mStart) {
                stunden = 0 + restTag * 24;
                minuten = mEnde - mStart;
            }
            if (sStart == sEnde && mEnde < mStart) {
                stunden = 23 + restTag * 24;
                minuten = 60 - mx;
            }
            if (sStart < sEnde && mEnde == mStart) {
                stunden = sEnde - sStart + restTag * 24;
                minuten = 0;
            }
            if (sStart > sEnde && mEnde == mStart) {
                stunden = 24 - (sStart - sEnde) + restTag * 24;
                minuten = 0;
            }
            if (sStart < sEnde && mEnde < mStart) {
                if ((sEnde - sStart) == 1) {
                    stunden = 0 + restTag * 24;
                } else if ((sEnde - sStart) > 1) {
                    stunden = sEnde - sStart - 1 + restTag * 24;
                }
                minuten = (60 - mx);
            }
            if (sStart < sEnde && mEnde > mStart) {
                stunden = sEnde - sStart + restTag * 24;
                minuten = mEnde - mStart;
            }
            if (sStart > sEnde && mEnde > mStart) {
                if ((sStart - sEnde) == 1) {
                    stunden = 23 + restTag * 24;
                } else if ((sStart - sEnde) > 1) {
                    stunden = 24 - (sStart - sEnde) + restTag * 24;
                }
                minuten = mEnde - mStart;
            }
            if (sStart > sEnde && mEnde < mStart) {

                if ((sStart - sEnde) == 23) {
                    stunden = 0 + restTag * 24;
                } else if ((sStart - sEnde) < 23) {
                    stunden = restStunden + restTag * 24;
                }
                minuten = 60 - mx;
            }
        }
        
        
        if(minuten>59){
            stunden = stunden +1;
            minuten = minuten - 60;
        }
        
        stringZeitBerechnetZwischenStartUndEndeStunden = Integer.toString(stunden);
        stringZeitBerechnetZwischenStartUndEndeMinuten = Integer.toString(minuten);

        return stringZeitBerechnetZwischenStartUndEndeStunden + stringZeitBerechnetZwischenStartUndEndeMinuten;
    }

    public boolean FrageBooleanNacht() {

        int mStart = Integer.parseInt(getMinutenStart());
        int sStart = Integer.parseInt(getStundenStart());
        int mEnde = Integer.parseInt(this.getStringBerechnetArbeitsZeitEndeOhnePauseMinuten());
        int sEnde = Integer.parseInt(this.getStringBerechnetArbeitsZeitEndeOhnePauseStunden());

        if (getStundenStart().length() == 0 || getStundenEnde().length() == 0 || getStringBerechnetArbeitsZeitEndeOhnePauseStunden().length() == 0) {
            mStart = 0;
            sStart = 0;
            mEnde = 0;
            sEnde = 0;
            booleanNacht = false;
        } else {
            if (sStart > sEnde) {
                booleanNacht = true;
            } else {
                booleanNacht = false;
            }
        }

        setBooleanNacht(booleanNacht);
        System.out.println("booleanNacht: " + booleanNacht);
        return booleanNacht;
    }

    public String Zeit24Rechner(String stundeStart, String minuteStart) {

        int minute = 0;
        int stunde = 0;

        int mStart = 0;
        int sStart = 0;

        String stunden = "";
        String minuten = "";

        if (stundeStart.length() == 0 || minuteStart.length() == 0) {
            minuten = Integer.toString(minute);
            stunden = Integer.toString(stunde);
        } 
        else {
            mStart = Integer.parseInt(minuteStart);
            sStart = Integer.parseInt(stundeStart);

            if (mStart > 59) {

                if (mStart % 60 == 0) {
                    minuten = Integer.toString(minute);
                    stunden = Integer.toString(sStart + (mStart / 60));
                }
                else {
                    minuten = Integer.toString(mStart % 60);
                    stunden = Integer.toString(sStart + (mStart / 60));
                }
            } 
            else if (mStart <= 59) {
                stunden = Integer.toString(sStart);
                minuten = Integer.toString(mStart);
            } 
            else if (mStart == 60) {
                stunden = Integer.toString(sStart + 1);
                minuten = Integer.toString(minute);
            }

            if (Integer.parseInt(stunden) > 24) {
                stunden = Integer.toString(Integer.parseInt(stunden) - 24);
            } 
            else if (Integer.parseInt(stunden) == 24) {
                stunden = Integer.toString(0);
            }
        }

        stundeEnde = stunden;
        minuteEnde = minuten;

        return stunden + minuten;
    }

//------------------------------------------------------------------------------   
//------------------------------------------------------------------------------   
//------------------------------------------------------------------------------       
//------------------------------------------------------------------------------        
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 2;
//        c.gridy = 22;
//        add(labelGrossePauseStart, c);
//
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 3;
//        c.gridy = 22;
//        add(textFieldGrossePauseStart, c);
//
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 4;
//        c.gridy = 22;
//        add(buttonGrossePauseStart, c);
//
//        buttonGrossePauseStart.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent evt) {
//                    
//                //BerechneZeit();
//                //stringBerechneZeit = Integer.toString(Integer.parseInt(getStundenEnde())-Integer.parseInt(getStundenStart()));
//                labelGetGrossePauseStart.setText(getGrossePauseStart());
//                labelGetGrossePauseStart.setForeground(Color.black);
//
//                
//            }
//        });
//
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 5;
//        c.gridy = 22;
//        add(labelGetGrossePauseStart, c);
//        
//        textFieldGrossePauseStart.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                buttonGrossePauseStart.doClick();
//            }
//        });
//
//        buttonGrossePauseStart.addKeyListener(new java.awt.event.KeyAdapter() {
//            @Override
//            public void keyReleased(java.awt.event.KeyEvent evt) {
//                buttonGrossePauseStart.doClick();
//            }
//        }); 
//        

//------------------------------------------------------------------------------        
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 2;
//        c.gridy = 23;
//        add(labelGrossePauseEnde, c);
//
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 3;
//        c.gridy = 23;
//        add(textFieldGrossePauseEnde, c);
//
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 4;
//        c.gridy = 23;
//        add(buttonGrossePauseEnde, c);
//
//        buttonGrossePauseEnde.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent evt) {
//                    
//               // BerechneZeit();
//                //stringBerechneZeit = Integer.toString(Integer.parseInt(getStundenEnde())-Integer.parseInt(getStundenStart()));
//                //stringGrossePauseEnde = getGrossePauseEnde()() + " h " + getGrossePauseEnde()() + " min";
//                //labelGetListArbeitsZeiten.setText(stringAnwesenheitszeit);
//                labelGetGrossePauseEnde.setText(getGrossePauseEnde());
//                labelGetGrossePauseEnde.setForeground(Color.black);
//
//                
//            }
//        });
//
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 5;
//        c.gridy = 23;
//        add(labelGetGrossePauseEnde, c);
//        
//        textFieldGrossePauseEnde.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                buttonGrossePauseEnde.doClick();
//            }
//        });
//
//        buttonGrossePauseEnde.addKeyListener(new java.awt.event.KeyAdapter() {
//            @Override
//            public void keyReleased(java.awt.event.KeyEvent evt) {
//                buttonGrossePauseEnde.doClick();
//            }
//        }); 
//        
//-*----------------------------------------------------------------------------        
//------------------------------------------------------------------------------             
//------------------------------------------------------------------------------        
//     JTextField jtfInput;
//	JTextArea jtAreaOutput;
//	String newline = "\n";
//        
//        
//     jtfInput = new JTextField(20);
//		jtfInput.addActionListener(this);
//		jtAreaOutput = new JTextArea(5, 20);
//		jtAreaOutput.setCaretPosition(jtAreaOutput.getDocument()
//				.getLength());
//		jtAreaOutput.setEditable(false);
//		JScrollPane scrollPane = new JScrollPane(jtAreaOutput,
//				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
//				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
//		GridBagLayout gridBag = new GridBagLayout();
//		Container contentPane = getContentPane();
//		contentPane.setLayout(gridBag);
//		GridBagConstraints gridCons1 = new GridBagConstraints();
//		gridCons1.gridwidth = GridBagConstraints.REMAINDER;
//		gridCons1.fill = GridBagConstraints.HORIZONTAL;
//		contentPane.add(jtfInput, gridCons1);
//		GridBagConstraints gridCons2 = new GridBagConstraints();
//		gridCons2.weightx = 1.0;
//		gridCons2.weighty = 1.0;
//		add(scrollPane, gridCons2);   
//        
//        
//        
//------------------------------------------------------------------------------   
//------------------------------------------------------------------------------    
//    public void splittStringEnde(String stringArbeitsZeitEnde, boolean split){//String zeitEingabe
//
//        String eingabe = getStringArbeitsZeitEnde();
//        System.out.println(eingabe + " = Eingabe ");
//        zaehler = 0;
//        while (zaehler < eingabe.length()) {
//            if (eingabe.substring(zaehler, zaehler + 1).equals(" ")) {
//                System.out.println("hat leertaste " + split);
//                split = true;
//                String[] getrenntUhrzeitStart = eingabe.split("\\ ");
//                stundeEnde = getrenntUhrzeitStart[0];
//                minuteEnde = getrenntUhrzeitStart[1];
//                System.out.println(stundeEnde + " = stundeEnde");
//                System.out.println(minuteEnde + " = minuteEnde");
//            } else if (eingabe.substring(zaehler, zaehler + 1).equals(".")) {
//                split = true;
//                System.out.println("hat punkt " + split);
//                String[] getrenntUhrzeitStart = eingabe.split("\\.");
//                setStundenEnde(getrenntUhrzeitStart[0]);
//                setMinutenEnde(getrenntUhrzeitStart[1]);
//                //split = false;
//            } else if (eingabe.substring(zaehler, zaehler + 1).equals(":")) {
//                split = true;
//                System.out.println("hat Doppel punkt " + split);
//                String[] getrenntUhrzeitStart = eingabe.split("\\:");
//                stundeEnde = getrenntUhrzeitStart[0];
//                minuteEnde = getrenntUhrzeitStart[1];
//            } else if (eingabe.substring(zaehler, zaehler + 1).equals(",")) {
//                split = true;
//                System.out.println("hat komma " + split);
//                String[] getrenntUhrzeitStart = eingabe.split("\\,");
//                stundeEnde = getrenntUhrzeitStart[0];
//                minuteEnde = getrenntUhrzeitStart[1];
//            } else if (eingabe.substring(zaehler, zaehler + 1).equals(";")) {
//                split = true;
//                System.out.println("hat Strich Punkt " + split);
//                String[] getrenntUhrzeitStart = eingabe.split("\\;");
//                stundeEnde = getrenntUhrzeitStart[0];
//                minuteEnde = getrenntUhrzeitStart[1];
//            }
//            zaehler++;
//        }
//        
//        zaehler = 0;
//        zaehler = eingabe.length();        
//        if(zaehler == 0){
//            System.out.println("Fehler, keine Eingabe und trotzdem gedrückt!!!");
//        }
//        else if(zaehler == 1 && !split){
//            stundeEnde = eingabe.substring(0,1);
//            minuteEnde = "00";
//        }
//        else if(zaehler == 2 && !split){
//            stundeEnde = eingabe.substring(0,2);
//            minuteEnde = "00";
//        }        
//        else if(zaehler == 3 && !split){
//            stundeEnde = eingabe.substring(0,1);
//            minuteEnde = eingabe.substring(1,eingabe.length());
//        }           
//        else if(zaehler == 4 && !split){
//            stundeEnde = eingabe.substring(0,2);
//            minuteEnde = eingabe.substring(2,eingabe.length());
//            System.out.println(stundeEnde + " = stundeEnde ojoijoj");
//            System.out.println(minuteEnde + " = minuteEnde ookokok");
//        }           
//    
//        setMinutenEnde(minuteEnde);
//        setStundenEnde(stundeEnde);
//        //return minuten;
//        //return stunden;
//    }    
////------------------------------------------------------------------------------
//    public void eingabePrueferEnde(String minuteEnde, String stundeEnde, boolean falscheZeiteingabe){//String minuteStart, String stundeStart
////        int x = zaehler;
////        
////        System.out.println(zaehler + " = zaehler Hoffentlich");
////        
//        System.out.println(getMinutenEnde() + " = stundeStarthoffffffentlichgetMinutenStart()");
//        System.out.println(minuteEnde + " = minuteStarthoffffffentlich");
//        //int dd = 23;
//        falscheZeitEingabe = false;
//       
//        if(Integer.parseInt(getStundenEnde()) > 23){
//            falscheStundenEingabe = true;
//            System.out.println(getFalscheStundenEingabe() + " = getFalscheStundenEingabe()");
//        }
//        else if(Integer.parseInt(getStundenEnde()) <= 23){
//            falscheStundenEingabe = false;
//            //return falscheMinutenEingabe = true
//            //falscheZeitEingabe = false;
//            System.out.println(getFalscheStundenEingabe() + " = getFalscheStundenEingabe()");
//        }
//        
//        if (Integer.parseInt(getMinutenEnde()) > 59){
//            //falscheZeitEingabe = true;
//            
//            falscheMinutenEingabe = true;
//            System.out.println(getFalscheMinutenEingabe() + " = getFalscheMinutenEingabe()");
//        }
//        else if (Integer.parseInt(getMinutenEnde()) <= 59){
//            //falscheZeitEingabe = false;
//                    System.out.println(falscheZeitEingabe + " = falscheZeitEingabe");
//            falscheMinutenEingabe = false;
//          //  System.out.println("falsch = falscheMinutenEingabe");
//            //return falscheStundenEingabe = false;
//            System.out.println(getFalscheMinutenEingabe() + " = getFalscheMinutenEingabe()");
//        }
//
//        //setFalscheZeitEingabe(falscheZeitEingabe);
//        setFalscheMinutenEingabe(falscheMinutenEingabe);
//        setFalscheStundenEingabe(falscheStundenEingabe);
//        //return falscheZeitEingabe;
////        return falscheMinutenEingabe = false;
////        return falscheStundenEingabe = false;
//        System.out.println(getFalscheStundenEingabe() + " = falscheStundenEingabe");
//        System.out.println(getFalscheMinutenEingabe() + " = falscheMinutenEingabe");
//        //System.out.println(falscheZeitEingabe + " = falscheZeitEingabe");
//        //return false;
//       //return falscheZeitEingabe
//    }
//        
//    
//    
//------------------------------------------------------------------------------    
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 2;
//        c.gridy = 13;
//        add(labelAnzahlRaucherPausen, c);
//
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 3;
//        c.gridy = 13;
//        add(textFieldAnzahlRaucherPausen, c);
//
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 4;
//        c.gridy = 13;
//        add(buttonAnzahlRaucherPausen, c);
//
//        //Integer.parseInt(getAnzahlRaucherPausen()) = 0;
//        buttonAnzahlRaucherPausen.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent evt) {
//                stringAnzahlRaucherPausen = textFieldAnzahlRaucherPausen.getText();
//                if (stringAnzahlRaucherPausen.matches("[0-9]+")){
//                    System.out.println(stringAnzahlRaucherPausen + " = Anzahl Raucher- Pausen");
//                    setAnzahlRaucherPausen(stringAnzahlRaucherPausen);
//                    labelGetAnzahlRaucherPausen.setText("" + stringAnzahlRaucherPausen + " Mal"+ getMinuten1()+getMinuten2()+"");
//                    labelGetAnzahlRaucherPausen.setForeground(Color.black);
//                    
//                    
//    final String[] stringAnzahlRaucherPausen = new String[Integer.parseInt(getAnzahlRaucherPausen())];
//    JLabel[] labelAnzahlRaucherPausen =  new JLabel[Integer.parseInt(getAnzahlRaucherPausen())];
//    final JTextField[] textFieldAnzahlRaucherPausen = new JTextField[Integer.parseInt(getAnzahlRaucherPausen())];
//    JButton[] buttonAnzahlRaucherPausen = new JButton[Integer.parseInt(getAnzahlRaucherPausen())];
//    final JLabel[] labelGetAnzahlRaucherPausen =  new JLabel[Integer.parseInt(getAnzahlRaucherPausen())];
//
//    
////int x = 0;
//   
//    for( int i = 1;  i <= Integer.parseInt(getAnzahlRaucherPausen())+1; i++ ) {
//        //x=i;
//        labelAnzahlRaucherPausen [i] = new JLabel ("AnzahlRaucherPausen "+i);
////        c.fill = GridBagConstraints.HORIZONTAL;
////        c.weightx = 0.5;
////        c.gridx = 2;
////        c.gridy = 40+i;
////        add(labelAnzahlRaucherPausen[i], c);
////        
//        
//        textFieldAnzahlRaucherPausen[i] = new JTextField();
//        textFieldAnzahlRaucherPausen[i].setText("");
//        
//// textFieldAnzahlRaucherPausen[i].setText ("Hallo welt");
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 3;
//        c.gridy = 40+i;
//        add(textFieldAnzahlRaucherPausen[i], c);//textFieldAnzahlRaucherPausen[i]
//        
//        
//        buttonAnzahlRaucherPausen[i] = new JButton("OK");
//        
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 4;
//        c.gridy = 40+i;
//        add(buttonAnzahlRaucherPausen[i], c);
//        
//        stringAnzahlRaucherPausen[i] = new String("a");
////        buttonAnzahlRaucherPausen[i].addActionListener(new ActionListener() {
////            @Override
////            public void actionPerformed(ActionEvent evt) {
////                
//////                //x = z;
//////                //x++;
////                stringAnzahlRaucherPausen[x] = textFieldAnzahlRaucherPausen[x].getText();
////                if (stringAnzahlRaucherPausen[x].matches("[0-9]+")){
////                    System.out.println(stringAnzahlRaucherPausen[x] + " = Anzahl Raucher- Pausen");
////                    //setAnzahlRaucherPausen[i]=stringAnzahlRaucherPausen[i];
////                    labelGetAnzahlRaucherPausen[x].setText("" + stringAnzahlRaucherPausen[x] +"");
////                    labelGetAnzahlRaucherPausen[x].setForeground(Color.black);
////                    //x++;
////                }
////                else {
////                    System.err.println("nicht erlaubt; Keine Zahl eingegeben!!!");
////                    labelGetAnzahlRaucherPausen[x].setText("keine Zahl eingegeben!!!");
////                    labelGetAnzahlRaucherPausen[x].setForeground(Color.red);
////                    //x++;
////                }
////                   //x++;
////            }
////        });        
//
//        labelGetAnzahlRaucherPausen[i] =  new JLabel("ww");   
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 5;
//        c.gridy = 40+i;
//        add(labelGetAnzahlRaucherPausen[i], c);
//        
//        
//        textFieldAnzahlRaucherPausen[i].addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//               // buttonAnzahlRaucherPausen[i].doClick();
//            }
//        });
//
//        buttonAnzahlRaucherPausen[i].addKeyListener(new java.awt.event.KeyAdapter() {
//            @Override
//            public void keyReleased(java.awt.event.KeyEvent evt) {
//               // buttonAnzahlRaucherPausen[i].doClick();
//            }
//        }); 
//        
//     
//        
//    }
//                    
//                    
//                }
//                else {
//                    System.err.println("nicht erlaubt; Keine Zahl eingegeben!!!");
//                    labelGetAnzahlRaucherPausen.setText("keine Zahl eingegeben!!!");
//                    labelGetAnzahlRaucherPausen.setForeground(Color.red);
//                }
//            }
//        });
//
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 5;
//        c.gridy = 13;
//        add(labelGetAnzahlRaucherPausen, c);
//        
//        textFieldAnzahlRaucherPausen.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                buttonAnzahlRaucherPausen.doClick();
//            }
//        });
//
//        buttonAnzahlRaucherPausen.addKeyListener(new java.awt.event.KeyAdapter() {
//            @Override
//            public void keyReleased(java.awt.event.KeyEvent evt) {
//                buttonAnzahlRaucherPausen.doClick();
//            }
//        });               
//------------------------------------------------------------------------------
//     c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 2;
//        c.gridy = 40+i;
//        add(labelAnzahlRaucherPausen[i], c);
//        
//------------------------------------------------------------------------------
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 2;
//        c.gridy = 14;
//        add(labelAnzahlMinutenPausen, c);
//
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 3;
//        c.gridy = 14;
//        add(textFieldAnzahlMinuten1Pausen, c);
//
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 4;
//        c.gridy = 14;
//        add(buttonAnzahlMinuten1Pausen, c);
//
//        buttonAnzahlMinuten1Pausen.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent evt) {
//                stringAnzahlMinuten1Pausen = textFieldAnzahlMinuten1Pausen.getText();
//                if (stringAnzahlMinuten1Pausen.matches("[0-9]+")){
//                    rechnewas(stringAnzahlMinuten1Pausen);
//                    setMinutenKleinePause(minuten);
//                    ausgebenMinuten1();
//                    System.out.println(getMinuten1() + " = Anzahl Minuten1- Pausen");
//                    labelGetAnzahlMinutenPausen.setText(getMinuten1());
//                    labelGetAnzahlMinutenPausen.setForeground(Color.green);
//                }
//                else {
//                    System.err.println("nicht erlaubt; Keine Zahl eingegeben!!!");
//                    labelGetAnzahlMinutenPausen.setText("keine Zahl eingegeben!!!");
//                    labelGetAnzahlMinutenPausen.setForeground(Color.red);
//                }
//            }
//        });
//
//        c.fill = GridBagConstraints.HORIZONTAL;
//        c.weightx = 0.5;
//        c.gridx = 5;
//        c.gridy = 14;
//        add(labelGetAnzahlMinutenPausen, c);
//        
//        textFieldAnzahlMinuten1Pausen.addActionListener(new ActionListener() {
//            public void actionPerformed(ActionEvent e) {
//                buttonAnzahlMinuten1Pausen.doClick();
//            }
//        });
//
//        buttonAnzahlMinuten1Pausen.addKeyListener(new java.awt.event.KeyAdapter() {
//            @Override
//            public void keyReleased(java.awt.event.KeyEvent evt) {
//                buttonAnzahlMinuten1Pausen.doClick();
//            }
//        });               
//------------------------------------------------------------------------------    
    private void fontSetzenAktuell(JComponent componentDorn, String stringSchriftArt, boolean schriftDicke, int schriftGroesse, boolean schriftKursiv) {
        if (schriftDicke) {
            componentDorn.setFont(new Font(stringSchriftArt, Font.BOLD, schriftGroesse));
        }
        if (schriftKursiv) {
            componentDorn.setFont(new Font(stringSchriftArt, Font.ITALIC, schriftGroesse));
        }
        if (schriftDicke && schriftKursiv) {
            componentDorn.setFont(new Font(stringSchriftArt, Font.ITALIC + Font.BOLD, schriftGroesse));
        }
    }
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//******************************************************************************
class CoilRechner extends JPanel implements ActionListener {

    JLabel labelCoilrechner;

    JLabel labelCoilBreite;
    JLabel labelCoilGewicht;
    JLabel labelCoilRinggroesse;
    JLabel labelCoilLaenge;
    JLabel labelCoilInnenDurchmesser;
    JLabel labelCoilAussenDurchmesser;
    JLabel labelCoilAuflaufhoehe;
    JLabel labelCoilMaterialDicke;
    JLabel labelCoilMaterialDichte;

    JTextField textfieldCoilBreite;
    JTextField textfieldCoilGewicht;
    JTextField textfieldCoilRinggroesse;
    JTextField textfieldCoilLaenge;
    JTextField textfieldCoilInnenDurchmesser;
    JTextField textfieldCoilAussenDurchmesser;
    JTextField textfieldCoilAuflaufhoehe;
    JTextField textfieldCoilMaterialDicke;
    JTextField textfieldCoilMaterialDichte;

    JButton buttonCoilBreiteBestaetigen;
    JButton buttonCoilGewichtBestaetigen;
    JButton buttonCoilRinggroesseBestaetigen;
    JButton buttonCoilLaengeBestaetigen;
    JButton buttonCoilInnenDurchmesserBestaetigen;
    JButton buttonCoilAussenDurchmesserBestaetigen;
    JButton buttonCoilAuflaufhoeheBestaetigen;
    JButton buttonCoilMaterialDickeBestaetigen;
    JButton buttonCoilMaterialDichteBestaetigen;

    JLabel labelgetCoilBreite;
    JLabel labelgetCoilGewicht;
    JLabel labelgetCoilRinggroesse;
    JLabel labelgetCoilLaenge;
    JLabel labelgetCoilInnenDurchmesser;
    JLabel labelgetCoilAussenDurchmesser;
    JLabel labelgetCoilAuflaufhoehe;
    JLabel labelgetCoilMaterialDicke;
    JLabel labelgetCoilMaterialDichte;

    String stringCoilBreite = "";
    String stringCoilGewicht = "";
    String stringCoilRinggroesse = "";
    String stringCoilLaenge = "";
    String stringCoilInnenDurchmesser = "";
    String stringCoilAussenDurchmesser = "";
    String stringCoilAuflaufhoehe = "";
    String stringCoilMaterialDicke = "";
    String stringCoilMaterialDichte = "";

    String stringSchriftArtARIAL = "Arial";
    String stringSchriftArtCALIBRI = "Calibri";

    public CoilRechner() {
        initCoilRechnerPanel();
    }

    private void initCoilRechnerPanel() {

        labelCoilrechner = new JLabel("Coilrechner");

        labelCoilBreite = new JLabel("Breite des Coils:");
        labelCoilGewicht = new JLabel("Coil- Gewicht:");
        labelCoilRinggroesse = new JLabel("Ringgröße:");
        labelCoilLaenge = new JLabel("Coil- Laenge:");
        labelCoilInnenDurchmesser = new JLabel("Innen-Ø:");
        labelCoilAussenDurchmesser = new JLabel("Außen-Ø:");
        labelCoilAuflaufhoehe = new JLabel("Auflaufhöhe:");
        labelCoilMaterialDicke = new JLabel("Coil- Materialdicke:");
        labelCoilMaterialDichte = new JLabel("Coil- Materialdichte:");

        textfieldCoilBreite = new JTextField(stringCoilBreite);
        textfieldCoilGewicht = new JTextField(stringCoilGewicht);
        textfieldCoilRinggroesse = new JTextField(stringCoilRinggroesse);
        textfieldCoilLaenge = new JTextField(stringCoilLaenge);
        textfieldCoilInnenDurchmesser = new JTextField(stringCoilInnenDurchmesser);
        textfieldCoilAussenDurchmesser = new JTextField(stringCoilAussenDurchmesser);
        textfieldCoilAuflaufhoehe = new JTextField(stringCoilAuflaufhoehe);
        textfieldCoilMaterialDicke = new JTextField(stringCoilMaterialDicke);
        textfieldCoilMaterialDichte = new JTextField(stringCoilMaterialDichte);

        buttonCoilBreiteBestaetigen = new JButton("OK");
        buttonCoilGewichtBestaetigen = new JButton("OK");
        buttonCoilRinggroesseBestaetigen = new JButton("OK");
        buttonCoilLaengeBestaetigen = new JButton("OK");
        buttonCoilInnenDurchmesserBestaetigen = new JButton("OK");
        buttonCoilAussenDurchmesserBestaetigen = new JButton("OK");
        buttonCoilAuflaufhoeheBestaetigen = new JButton("OK");
        buttonCoilMaterialDickeBestaetigen = new JButton("OK");
        buttonCoilMaterialDichteBestaetigen = new JButton("OK");

        labelgetCoilBreite = new JLabel();//"mm"
        labelgetCoilGewicht = new JLabel();//"kg"
        labelgetCoilRinggroesse = new JLabel();//"kg/mm"
        labelgetCoilLaenge = new JLabel();// "m"       
        labelgetCoilInnenDurchmesser = new JLabel();//"mm"
        labelgetCoilAussenDurchmesser = new JLabel();// "mm"       
        labelgetCoilAuflaufhoehe = new JLabel();//"mm"
        labelgetCoilMaterialDicke = new JLabel();// "mm"       
        labelgetCoilMaterialDichte = new JLabel();// "kg/dm3"       

        fontSetzenAktuell(labelCoilrechner, stringSchriftArtARIAL, true, 16, true);

        fontSetzenAktuell(labelCoilBreite, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(labelCoilGewicht, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(labelCoilRinggroesse, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(labelCoilLaenge, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(labelCoilInnenDurchmesser, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(labelCoilAussenDurchmesser, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(labelCoilAuflaufhoehe, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(labelCoilMaterialDicke, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(labelCoilMaterialDichte, stringSchriftArtARIAL, true, 12, true);

        fontSetzenAktuell(textfieldCoilBreite, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(textfieldCoilGewicht, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(textfieldCoilRinggroesse, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(textfieldCoilLaenge, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(textfieldCoilInnenDurchmesser, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(textfieldCoilAussenDurchmesser, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(textfieldCoilAuflaufhoehe, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(textfieldCoilMaterialDicke, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(textfieldCoilMaterialDichte, stringSchriftArtARIAL, true, 12, true);

        fontSetzenAktuell(buttonCoilBreiteBestaetigen, stringSchriftArtCALIBRI, true, 12, false);
        fontSetzenAktuell(buttonCoilGewichtBestaetigen, stringSchriftArtCALIBRI, true, 12, false);
        fontSetzenAktuell(buttonCoilRinggroesseBestaetigen, stringSchriftArtCALIBRI, true, 12, false);
        fontSetzenAktuell(buttonCoilLaengeBestaetigen, stringSchriftArtCALIBRI, true, 12, false);
        fontSetzenAktuell(buttonCoilInnenDurchmesserBestaetigen, stringSchriftArtCALIBRI, true, 12, false);
        fontSetzenAktuell(buttonCoilAussenDurchmesserBestaetigen, stringSchriftArtCALIBRI, true, 12, false);
        fontSetzenAktuell(buttonCoilAuflaufhoeheBestaetigen, stringSchriftArtCALIBRI, true, 12, false);
        fontSetzenAktuell(buttonCoilMaterialDickeBestaetigen, stringSchriftArtCALIBRI, true, 12, false);
        fontSetzenAktuell(buttonCoilMaterialDichteBestaetigen, stringSchriftArtCALIBRI, true, 12, false);

        fontSetzenAktuell(labelgetCoilBreite, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(labelgetCoilGewicht, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(labelgetCoilRinggroesse, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(labelgetCoilLaenge, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(labelgetCoilInnenDurchmesser, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(labelgetCoilAussenDurchmesser, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(labelgetCoilAuflaufhoehe, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(labelgetCoilMaterialDicke, stringSchriftArtARIAL, true, 12, true);
        fontSetzenAktuell(labelgetCoilMaterialDichte, stringSchriftArtARIAL, true, 12, true);

        buttonCoilBreiteBestaetigen.setPreferredSize(new Dimension(230, 30));
        buttonCoilGewichtBestaetigen.setPreferredSize(new Dimension(230, 30));
        buttonCoilRinggroesseBestaetigen.setPreferredSize(new Dimension(230, 30));
        buttonCoilLaengeBestaetigen.setPreferredSize(new Dimension(230, 30));
        buttonCoilInnenDurchmesserBestaetigen.setPreferredSize(new Dimension(230, 30));
        buttonCoilAussenDurchmesserBestaetigen.setPreferredSize(new Dimension(230, 30));
        buttonCoilAuflaufhoeheBestaetigen.setPreferredSize(new Dimension(230, 30));
        buttonCoilMaterialDickeBestaetigen.setPreferredSize(new Dimension(230, 30));
        buttonCoilMaterialDichteBestaetigen.setPreferredSize(new Dimension(230, 30));

        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 10);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 2;
        add(labelCoilrechner, c);
//------------------------------------------------------------------------------
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 11;
        add(labelCoilBreite, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 11;
        add(textfieldCoilBreite, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 11;
        add(buttonCoilBreiteBestaetigen, c);

        buttonCoilBreiteBestaetigen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                stringCoilBreite = textfieldCoilBreite.getText();
                System.out.println(stringCoilBreite);
                labelgetCoilBreite.setText("" + stringCoilBreite + " mm");
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 11;
        add(labelgetCoilBreite, c);
//------------------------------------------------------------------------------        
        textfieldCoilBreite.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buttonCoilBreiteBestaetigen.doClick();
            }
        });

        buttonCoilBreiteBestaetigen.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buttonCoilBreiteBestaetigen.doClick();
            }
        });
//------------------------------------------------------------------------------

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 12;
        add(labelCoilGewicht, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 12;
        add(textfieldCoilGewicht, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 12;
        add(buttonCoilGewichtBestaetigen, c);

        buttonCoilGewichtBestaetigen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                stringCoilGewicht = textfieldCoilGewicht.getText();
                System.out.println(stringCoilGewicht);
                labelgetCoilGewicht.setText("" + stringCoilGewicht + " kg");
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 12;
        add(labelgetCoilGewicht, c);
//------------------------------------------------------------------------------        
        textfieldCoilGewicht.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buttonCoilGewichtBestaetigen.doClick();
            }
        });

        buttonCoilGewichtBestaetigen.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buttonCoilGewichtBestaetigen.doClick();
            }
        });
//------------------------------------------------------------------------------

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 13;
        add(labelCoilRinggroesse, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 13;
        add(textfieldCoilRinggroesse, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 13;
        add(buttonCoilRinggroesseBestaetigen, c);

        buttonCoilRinggroesseBestaetigen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                stringCoilRinggroesse = textfieldCoilRinggroesse.getText();
                System.out.println(stringCoilRinggroesse);
                labelgetCoilRinggroesse.setText("" + stringCoilRinggroesse + " kg/mm");
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 13;
        add(labelgetCoilRinggroesse, c);
//------------------------------------------------------------------------------        
        textfieldCoilRinggroesse.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buttonCoilRinggroesseBestaetigen.doClick();
            }
        });

        buttonCoilRinggroesseBestaetigen.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buttonCoilRinggroesseBestaetigen.doClick();
            }
        });
//------------------------------------------------------------------------------

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 14;
        add(labelCoilLaenge, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 14;
        add(textfieldCoilLaenge, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 14;
        add(buttonCoilLaengeBestaetigen, c);

        buttonCoilLaengeBestaetigen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                stringCoilLaenge = textfieldCoilLaenge.getText();
                System.out.println(stringCoilLaenge);
                labelgetCoilLaenge.setText("" + stringCoilLaenge + " m");
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 14;
        add(labelgetCoilLaenge, c);
//------------------------------------------------------------------------------        
        textfieldCoilLaenge.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buttonCoilLaengeBestaetigen.doClick();
            }
        });

        buttonCoilLaengeBestaetigen.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buttonCoilLaengeBestaetigen.doClick();
            }
        });
//------------------------------------------------------------------------------

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 15;
        add(labelCoilInnenDurchmesser, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 15;
        add(textfieldCoilInnenDurchmesser, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 15;
        add(buttonCoilInnenDurchmesserBestaetigen, c);

        buttonCoilInnenDurchmesserBestaetigen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                stringCoilInnenDurchmesser = textfieldCoilInnenDurchmesser.getText();
                System.out.println(stringCoilInnenDurchmesser);
                labelgetCoilInnenDurchmesser.setText("" + stringCoilInnenDurchmesser + " mm");
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 15;
        add(labelgetCoilInnenDurchmesser, c);
//------------------------------------------------------------------------------        
        textfieldCoilInnenDurchmesser.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buttonCoilInnenDurchmesserBestaetigen.doClick();
            }
        });

        buttonCoilInnenDurchmesserBestaetigen.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buttonCoilInnenDurchmesserBestaetigen.doClick();
            }
        });
//------------------------------------------------------------------------------

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 16;
        add(labelCoilAussenDurchmesser, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 16;
        add(textfieldCoilAussenDurchmesser, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 16;
        add(buttonCoilAussenDurchmesserBestaetigen, c);

        buttonCoilAussenDurchmesserBestaetigen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                stringCoilAussenDurchmesser = textfieldCoilAussenDurchmesser.getText();
                System.out.println(stringCoilAussenDurchmesser);
                labelgetCoilAussenDurchmesser.setText("" + stringCoilAussenDurchmesser + " mm");
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 16;
        add(labelgetCoilAussenDurchmesser, c);
//------------------------------------------------------------------------------        
        textfieldCoilAussenDurchmesser.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buttonCoilAussenDurchmesserBestaetigen.doClick();
            }
        });

        buttonCoilAussenDurchmesserBestaetigen.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buttonCoilAussenDurchmesserBestaetigen.doClick();
            }
        });
//------------------------------------------------------------------------------

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 17;
        add(labelCoilAuflaufhoehe, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 17;
        add(textfieldCoilAuflaufhoehe, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 17;
        add(buttonCoilAuflaufhoeheBestaetigen, c);

        buttonCoilAuflaufhoeheBestaetigen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                stringCoilAuflaufhoehe = textfieldCoilAuflaufhoehe.getText();
                System.out.println(stringCoilAuflaufhoehe);
                labelgetCoilAuflaufhoehe.setText("" + stringCoilAuflaufhoehe + " m");
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 17;
        add(labelgetCoilAuflaufhoehe, c);
//------------------------------------------------------------------------------        
        textfieldCoilAuflaufhoehe.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buttonCoilAuflaufhoeheBestaetigen.doClick();
            }
        });

        buttonCoilAuflaufhoeheBestaetigen.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buttonCoilAuflaufhoeheBestaetigen.doClick();
            }
        });
//------------------------------------------------------------------------------

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 18;
        add(labelCoilMaterialDicke, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 18;
        add(textfieldCoilMaterialDicke, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 18;
        add(buttonCoilMaterialDickeBestaetigen, c);

        buttonCoilMaterialDickeBestaetigen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                stringCoilMaterialDicke = textfieldCoilMaterialDicke.getText();
                System.out.println(stringCoilMaterialDicke);
                labelgetCoilMaterialDicke.setText("" + stringCoilMaterialDicke + " mm");
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 18;
        add(labelgetCoilMaterialDicke, c);
//------------------------------------------------------------------------------        
        textfieldCoilMaterialDicke.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buttonCoilMaterialDickeBestaetigen.doClick();
            }
        });

        buttonCoilMaterialDickeBestaetigen.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buttonCoilMaterialDickeBestaetigen.doClick();
            }
        });
//------------------------------------------------------------------------------

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 19;
        add(labelCoilMaterialDichte, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 19;
        add(textfieldCoilMaterialDichte, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 19;
        add(buttonCoilMaterialDichteBestaetigen, c);

        buttonCoilMaterialDichteBestaetigen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                stringCoilMaterialDichte = textfieldCoilMaterialDichte.getText();
                System.out.println(stringCoilMaterialDichte);
                labelgetCoilMaterialDichte.setText("" + stringCoilMaterialDichte + " kg/dm3");
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 19;
        add(labelgetCoilMaterialDichte, c);
//------------------------------------------------------------------------------        
        textfieldCoilMaterialDichte.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buttonCoilMaterialDichteBestaetigen.doClick();
            }
        });

        buttonCoilMaterialDichteBestaetigen.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                buttonCoilMaterialDichteBestaetigen.doClick();
            }
        });
//------------------------------------------------------------------------------        
    }

    private void fontSetzenAktuell(JComponent componentDorn, String stringSchriftArt, boolean schriftDicke, int schriftGroesse, boolean schriftKursiv) {
        if (schriftDicke) {
            componentDorn.setFont(new Font(stringSchriftArt, Font.BOLD, schriftGroesse));
        }
        if (schriftKursiv) {
            componentDorn.setFont(new Font(stringSchriftArt, Font.ITALIC, schriftGroesse));
        }
        if (schriftDicke && schriftKursiv) {
            componentDorn.setFont(new Font(stringSchriftArt, Font.ITALIC + Font.BOLD, schriftGroesse));
        }
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

//******************************************************************************
class Schweissen extends JPanel {

    final private CardLayout cardManager;
    final private JPanel cardPanel;

    public Schweissen(JPanel cardPanel, CardLayout cardManager) {
        this.cardManager = cardManager;
        this.cardPanel = cardPanel;
        initSchweissen();
    }

    public void initSchweissen() {

        JButton rs25Button = new JButton("RS25");
        rs25Button.setFont(new Font("Calibri", Font.BOLD, 16));
        rs25Button.setPreferredSize(new Dimension(230, 30));

        JButton rs30Button = new JButton("RS30");
        rs30Button.setFont(new Font("Calibri", Font.BOLD, 16));
        rs30Button.setPreferredSize(new Dimension(230, 30));

        JButton rs50Button = new JButton("RS50");
        rs50Button.setFont(new Font("Calibri", Font.BOLD, 16));
        rs50Button.setPreferredSize(new Dimension(230, 30));

        JButton rs60Button = new JButton("RS60");
        rs60Button.setFont(new Font("Calibri", Font.BOLD, 16));
        rs60Button.setPreferredSize(new Dimension(230, 30));

        JButton rs65Button = new JButton("RS65");
        rs65Button.setFont(new Font("Calibri", Font.BOLD, 16));
        rs65Button.setPreferredSize(new Dimension(230, 30));

        rs25Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                cardManager.show(cardPanel, "RS25");
            }
        });

        rs30Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                cardManager.show(cardPanel, "RS30");
            }
        });

        rs50Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                cardManager.show(cardPanel, "RS50");
            }
        });

        rs60Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                cardManager.show(cardPanel, "RS60");
            }
        });

        rs65Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                cardManager.show(cardPanel, "RS65");
            }
        });

        final JPanel schweissenPanel = new JPanel();

        schweissenPanel.add(rs25Button);
        schweissenPanel.add(rs30Button);
        schweissenPanel.add(rs50Button);
        schweissenPanel.add(rs60Button);
        schweissenPanel.add(rs65Button);
        add(schweissenPanel);

        final JPanel grafikPanel = new JPanel();
        add(grafikPanel);

    }
}

class SchweissenMaschine extends JPanel implements ActionListener {

    final private CardLayout cardManager;
    final private JPanel cardPanel;

    String maschinenName;

    JLabel labelMaschinenName;

    String RS50EingabeRohrlaenge = "";
    JLabel RS50RohrlaengeEingabeLabel = new JLabel("Eingabe produzierende Rohrlänge:");
    final JTextField RS50RohrlaengeTextField = new JTextField(RS50EingabeRohrlaenge);
    JButton RS50RohrlaengeEingabeButton = new JButton("Rohrlänge bestätigen");
    final JLabel RS50RohrlaengeEingabeGetLabel = new JLabel("");

    String RS50EingabeStoerung = "";
    JLabel RS50StoerungLabel = new JLabel("Eingabe Störungs-Zeit:");
    final JTextField RS50StoerungTextField = new JTextField(RS50EingabeStoerung);
    JButton RS50EingabeStoerungButton = new JButton("Störung bestätigen");
    final JLabel RS50StoerungEingabeGetLabel = new JLabel("");

    String RS50EingabeGeschwindigkeit = "";
    String RS50GeschwindigkeitEingabe = "";
    JLabel RS50GeschwindigkeitEingabeLabel = new JLabel("Eingabe durchschnittliche Geschwindigkeit:");
    final JTextField RS50GeschwindigkeitTextField = new JTextField(RS50GeschwindigkeitEingabe);
    JButton RS50GeschwindigkeitEingabeButton = new JButton("Geschwindigkeit bestätigen");
    final JLabel RS50GeschwindigkeitEingabeGetLabel = new JLabel("");

    String RS50EingabeUmbau = "";
    JLabel RS50UmbauEingabeLabel = new JLabel("Eingabe Umbau:");
    final JTextField RS50UmbauTextField = new JTextField(RS50EingabeUmbau);
    JButton RS50UmbauEingabeButton = new JButton("Umbau bestätigen");
    final JLabel RS50UmbauEingabeGetLabel = new JLabel("");

    String RS50EingabePause = "";
    JLabel RS50PauseEingabeLabel = new JLabel("Eingabe Pause:");
    final JTextField RS50PauseTextField = new JTextField(RS50EingabePause);
    JButton RS50PauseEingabeButton = new JButton("Pause bestätigen");
    final JLabel RS50PauseEingabeGetLabel = new JLabel("");

    JLabel RS50AusgabeLabel = new JLabel("Ausgabe Zeit:");
    JButton RS50AusgabeButton = new JButton("Berechnen...");
    final JLabel RS50AusgabeGetLabelAusgabe = new JLabel("");

    String ausgabe = "";

    JRadioButton RS50PauseRadioButton = new JRadioButton("Pause");
    JRadioButton RS50UmbauRadioButton = new JRadioButton("Umbau");

    String anzahlpausen = "";

    JLabel RS50ProSchichtLabel = new JLabel("Pro Schicht:");

    String ausgabeschichten = "";
    String ausgabeZeit2 = "";
    String ausgabeschichtenUndPausen = "";
    JLabel RS50berechne2AusgabeZeitGetLabel = new JLabel("");
    JLabel RS50berechne2AusgabeSchichtGetLabel = new JLabel("");
    JLabel RS50berechne2AusgabeSchichtUndPauseGetLabel = new JLabel("");
    JButton RS50berechne2Button = new JButton("Berechnen2...");

    boolean stoehrung = false;
    boolean umbau = true;

    JLabel RS50PauseMitarbeiterLabel = new JLabel("Pause Mitarbeiter mitberechnen");
    JLabel RS50UmbauLabel = new JLabel("Umbau mitberechnen");

    public SchweissenMaschine(JPanel cardPanel, CardLayout cardManager, String maschinenName) throws IOException {
        this.cardManager = cardManager;
        this.cardPanel = cardPanel;
        this.maschinenName = maschinenName;
        initSchweissenMaschine();
    }

    public void initSchweissenMaschine() {

        labelMaschinenName = new JLabel(maschinenName);

        labelMaschinenName.setFont(new Font("Calibri", Font.BOLD, 24));
        labelMaschinenName.setPreferredSize(new Dimension(230, 30));

        RS50RohrlaengeEingabeLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50RohrlaengeEingabeLabel.setPreferredSize(new Dimension(230, 30));
        RS50RohrlaengeTextField.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50RohrlaengeTextField.setPreferredSize(new Dimension(230, 30));
        RS50RohrlaengeEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50RohrlaengeEingabeButton.setPreferredSize(new Dimension(230, 30));
        RS50RohrlaengeEingabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50RohrlaengeEingabeGetLabel.setPreferredSize(new Dimension(230, 30));

        RS50GeschwindigkeitEingabeLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50GeschwindigkeitEingabeLabel.setPreferredSize(new Dimension(230, 30));
        RS50GeschwindigkeitTextField.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50GeschwindigkeitTextField.setPreferredSize(new Dimension(230, 30));
        RS50GeschwindigkeitEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50GeschwindigkeitEingabeButton.setPreferredSize(new Dimension(230, 30));
        RS50GeschwindigkeitEingabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50GeschwindigkeitEingabeGetLabel.setPreferredSize(new Dimension(230, 30));

        RS50UmbauEingabeLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50UmbauEingabeLabel.setPreferredSize(new Dimension(230, 30));
        RS50UmbauTextField.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50UmbauTextField.setPreferredSize(new Dimension(230, 30));
        RS50UmbauEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50UmbauEingabeButton.setPreferredSize(new Dimension(230, 30));
        RS50UmbauEingabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50UmbauEingabeGetLabel.setPreferredSize(new Dimension(230, 30));

        RS50PauseEingabeLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50PauseEingabeLabel.setPreferredSize(new Dimension(230, 30));
        RS50PauseTextField.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50PauseTextField.setPreferredSize(new Dimension(230, 30));
        RS50PauseEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50PauseEingabeButton.setPreferredSize(new Dimension(230, 30));
        RS50PauseEingabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50PauseEingabeGetLabel.setPreferredSize(new Dimension(230, 30));

        RS50ProSchichtLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50ProSchichtLabel.setPreferredSize(new Dimension(230, 30));

        RS50berechne2Button.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50berechne2Button.setPreferredSize(new Dimension(230, 30));

        RS50berechne2AusgabeSchichtGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50berechne2AusgabeSchichtGetLabel.setPreferredSize(new Dimension(230, 30));

        RS50berechne2AusgabeSchichtUndPauseGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50berechne2AusgabeSchichtUndPauseGetLabel.setPreferredSize(new Dimension(230, 30));

        RS50berechne2AusgabeZeitGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50berechne2AusgabeZeitGetLabel.setPreferredSize(new Dimension(230, 30));

        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 10);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 7;
        add(labelMaschinenName, c);

//------------------------------------------------------------------------------        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 8;
        add(RS50RohrlaengeEingabeLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 8;
        add(RS50RohrlaengeTextField, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 8;
        add(RS50RohrlaengeEingabeButton, c);

        RS50RohrlaengeEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                RS50EingabeRohrlaenge = RS50RohrlaengeTextField.getText();
                System.out.println(RS50EingabeRohrlaenge);
                RS50RohrlaengeEingabeGetLabel.setText("" + RS50EingabeRohrlaenge + " m");
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 8;
        add(RS50RohrlaengeEingabeGetLabel, c);
//------------------------------------------------------------------------------        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 12;
        add(RS50GeschwindigkeitEingabeLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 12;
        add(RS50GeschwindigkeitTextField, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 12;
        add(RS50GeschwindigkeitEingabeButton, c);

        RS50GeschwindigkeitEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                RS50EingabeGeschwindigkeit = RS50GeschwindigkeitTextField.getText();
                System.out.println(RS50EingabeGeschwindigkeit);
                RS50GeschwindigkeitEingabeGetLabel.setText("" + RS50EingabeGeschwindigkeit + " m/Min");
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 12;
        add(RS50GeschwindigkeitEingabeGetLabel, c);
//------------------------------------------------------------------------------

        RS50AusgabeLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50AusgabeLabel.setPreferredSize(new Dimension(230, 30));

        RS50AusgabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50AusgabeButton.setPreferredSize(new Dimension(230, 30));

        RS50AusgabeGetLabelAusgabe.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50AusgabeGetLabelAusgabe.setPreferredSize(new Dimension(230, 30));

        RS50AusgabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent RS50AusgabeButtonevt) {
                String RS50EingabeRohrlaenge = RS50RohrlaengeTextField.getText();
                BerechneZeit();
                RS50AusgabeGetLabelAusgabe.setText(ausgabe);
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 13;
        add(RS50AusgabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 13;
        add(RS50AusgabeGetLabelAusgabe, c);

//******************************************************************************   
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 19;
        add(RS50ProSchichtLabel, c);
//******************************************************************************           

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 21;
        add(RS50UmbauEingabeLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 21;
        add(RS50UmbauTextField, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 21;
        add(RS50UmbauEingabeButton, c);

        RS50UmbauEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                RS50EingabeUmbau = RS50UmbauTextField.getText();
                System.out.println(RS50EingabeUmbau);
                RS50UmbauEingabeGetLabel.setText("" + RS50EingabeUmbau + " Min");
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 21;
        add(RS50UmbauEingabeGetLabel, c);

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 22;
        add(RS50PauseEingabeLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 22;
        add(RS50PauseTextField, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 22;
        add(RS50PauseEingabeButton, c);

        RS50PauseEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                RS50EingabePause = RS50PauseTextField.getText();
                System.out.println(RS50EingabePause);
                RS50PauseEingabeGetLabel.setText("" + RS50EingabePause + " Min");
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 22;
        add(RS50PauseEingabeGetLabel, c);

//------------------------------------------------------------------------------        
        RS50StoerungLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50StoerungLabel.setPreferredSize(new Dimension(230, 30));
        RS50StoerungTextField.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50StoerungTextField.setPreferredSize(new Dimension(230, 30));
        RS50EingabeStoerungButton.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50EingabeStoerungButton.setPreferredSize(new Dimension(230, 30));
        RS50StoerungEingabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RS50StoerungEingabeGetLabel.setPreferredSize(new Dimension(230, 30));

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 20;
        add(RS50StoerungLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 20;
        add(RS50StoerungTextField, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 20;
        add(RS50EingabeStoerungButton, c);

        RS50EingabeStoerungButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                stoehrung = true;
                RS50EingabeStoerung = RS50StoerungTextField.getText();
                System.out.println(RS50EingabeStoerung);
                RS50StoerungEingabeGetLabel.setText("" + RS50EingabeStoerung + " Min");
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 20;
        add(RS50StoerungEingabeGetLabel, c);

//------------------------------------------------------------------------------
        RS50berechne2Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent RS50AusgabeButtonevt) {
                Berechne2();
                RS50berechne2AusgabeZeitGetLabel.setText(ausgabeZeit2);
                RS50berechne2AusgabeSchichtGetLabel.setText(ausgabeschichten);
                RS50berechne2AusgabeSchichtUndPauseGetLabel.setText(ausgabeschichtenUndPausen);
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 30;
        add(RS50berechne2Button, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 30;
        add(RS50berechne2AusgabeZeitGetLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 31;
        add(RS50berechne2AusgabeSchichtGetLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 32;
        add(RS50berechne2AusgabeSchichtUndPauseGetLabel, c);

//------------------------------------------------------------------------------        
        RS50StoerungTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                RS50EingabeStoerungButton.doClick();
            }
        });

        RS50PauseTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                RS50PauseEingabeButton.doClick();
            }
        });

        RS50UmbauTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                RS50UmbauEingabeButton.doClick();
            }
        });

        RS50GeschwindigkeitTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                RS50GeschwindigkeitEingabeButton.doClick();
            }
        });

        RS50RohrlaengeTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                RS50RohrlaengeEingabeButton.doClick();
            }
        });

        RS50AusgabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RS50AusgabeButton.doClick();
            }
        });

        RS50berechne2Button.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RS50berechne2Button.doClick();
            }
        });

        RS50RohrlaengeEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RS50RohrlaengeEingabeButton.doClick();
            }
        });

        RS50GeschwindigkeitEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RS50GeschwindigkeitEingabeButton.doClick();
            }
        });

        RS50UmbauEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RS50UmbauEingabeButton.doClick();
            }
        });

        RS50PauseEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RS50PauseEingabeButton.doClick();
            }
        });

        RS50EingabeStoerungButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RS50EingabeStoerungButton.doClick();
            }
        });

    }

    public void Berechne2() {
        double rohrlaenge = Double.valueOf(RS50EingabeRohrlaenge);
        double geschwindigkeit = Double.valueOf(RS50EingabeGeschwindigkeit);

        double doubleausgabe2 = 0;

        double doubleminuten = 0;
        double doublestunden = 0;
        double doubletage = 0;
        double doublereststund = 0;
        double doublerestmin = 0;
        double doubleresttag = 0;

        doubleausgabe2 = (rohrlaenge / geschwindigkeit) + (Double.valueOf(RS50EingabeUmbau) + Double.valueOf(RS50EingabeStoerung) + Double.valueOf(RS50EingabePause));//+ doublestoehrung + doubleumbau+doublepause
        doubleminuten = doubleausgabe2 % 60;
        doublerestmin = doubleausgabe2 % 60;
        doublestunden = (doubleausgabe2 - doublerestmin) / 60;
        doubletage = (Math.floor(doubleausgabe2 / (60 * 24)));//1440

        if (doublestunden >= 24) {
            ausgabeZeit2 = Double.toString(doubletage) + " d  " + "0.0" + " h  " + Double.toString(doubleminuten) + " m";
        } else if (doublestunden < 24) {
            ausgabeZeit2 = Double.toString(doubletage) + " d  " + Double.toString(doublestunden) + " h  " + Double.toString(doubleminuten) + " m";
        }

        double schichtstunden = 8 * 60;
        double x = 0;
        x = 480 - Double.valueOf(RS50EingabeUmbau) - Double.valueOf(RS50EingabeStoerung);

        double doubleschichtzeiten = x + Double.valueOf(RS50EingabeUmbau) + Double.valueOf(RS50EingabeStoerung);// 8 * 60;
        double doubleschichtundpausen = (x + Double.valueOf(RS50EingabeUmbau) + Double.valueOf(RS50EingabeStoerung)) + Double.valueOf(RS50EingabePause);//(8 * 60) + 30;
        double doublepausenzeiten = Double.valueOf(RS50EingabePause);//30;

        double doubleschichtanzahl = Math.floor(doubleausgabe2 / doubleschichtzeiten);
        double doubleschichtrest = 0;

        double doublepausenanzahl = Math.floor(doubleausgabe2 / doubleschichtundpausen);
        double doublepausenrest = 0;

        System.out.println(Math.floor(doubleausgabe2 / doubleschichtzeiten) + " --> Anzahl Schichten ohne Pause"); // --> Anzahl Schichten
        System.out.println(Math.floor(doubleausgabe2 / doubleschichtundpausen) + " --> Anzahl Schicht und Pausen");

        ausgabeschichten = (Math.round(100.0 * (doubleausgabe2 / doubleschichtzeiten)) / 100.0) + " Anzahl Schichten";
        ausgabeschichtenUndPausen = Double.toString(doublepausenanzahl) + " Anzahl Pausen";

        System.out.println(doubleschichtanzahl + "schichtanzahl");
        System.out.println((Math.round(100.0 * (doubleausgabe2 / doubleschichtzeiten)) / 100.0));

    }

    public void BerechneZeit() {

        double rohrlaenge = Double.valueOf(RS50EingabeRohrlaenge);
        double geschwindigkeit = Double.valueOf(RS50EingabeGeschwindigkeit);

        double doubleausgabe = 0;

        double doubleminuten = 0;
        double doublestunden = 0;
        double doubletage = 0;
        double doublereststund = 0;
        double doublerestmin = 0;
        double doubleresttag = 0;

        doubleausgabe = (rohrlaenge / geschwindigkeit);//+ doublestoehrung + doubleumbau+doublepause

        doubleminuten = doubleausgabe % 60;
        doublerestmin = doubleausgabe % 60;
        doublestunden = (doubleausgabe - doublerestmin) / 60;

        doubletage = (Math.floor(doubleausgabe / (60 * 24)));//1440

        if (doublestunden >= 24) {
            ausgabe = Double.toString(doubletage) + " d  " + "0.0" + " h  " + Double.toString(doubleminuten) + " m";
        } else if (doublestunden < 24) {
            ausgabe = Double.toString(doubletage) + " d  " + Double.toString(doublestunden) + " h  " + Double.toString(doubleminuten) + " m";
        }

    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}

//------------------------------------------------------------------------------
class Ziehen extends JPanel {

    final private CardLayout cardManager;
    final private JPanel cardPanel;

    public Ziehen(JPanel cardPanel, CardLayout cardManager) {
        this.cardManager = cardManager;
        this.cardPanel = cardPanel;
        initZiehen();
    }

    public void initZiehen() {
        JButton asmagButton = new JButton("ASAMAG");
        asmagButton.setFont(new Font("Calibri", Font.BOLD, 16));
        asmagButton.setPreferredSize(new Dimension(230, 30));

        JButton inderButton = new JButton("INDER");
        inderButton.setFont(new Font("Calibri", Font.BOLD, 16));
        inderButton.setPreferredSize(new Dimension(230, 30));

        final JPanel ziehenPanel = new JPanel();
        ziehenPanel.add(asmagButton);
        ziehenPanel.add(inderButton);
        add(ziehenPanel);

        final JPanel grafikPanel = new JPanel();
        add(grafikPanel);

        asmagButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                cardManager.show(cardPanel, "ASMAG");
            }
        });

        inderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                cardManager.show(cardPanel, "INDER");
            }
        });

    }
}

//------------------------------------------------------------------------------
class Saegen extends JPanel {

    final private CardLayout cardManager;
    final private JPanel cardPanel;

    public Saegen(JPanel cardPanel, CardLayout cardManager) throws IOException {
        this.cardManager = cardManager;
        this.cardPanel = cardPanel;
        initSaegen();
    }

    public void initSaegen() throws IOException {

        final JButton rattundeButton = new JButton("Rezept");
        rattundeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        rattundeButton.setPreferredSize(new Dimension(230, 30));        
        
        final JButton rattunde1Button = new JButton("Rattunde 1");
        rattunde1Button.setFont(new Font("Calibri", Font.BOLD, 16));
        rattunde1Button.setPreferredSize(new Dimension(230, 30));

        JButton rattunde2Button = new JButton("Rattunde 2");
        rattunde2Button.setFont(new Font("Calibri", Font.BOLD, 16));
        rattunde2Button.setPreferredSize(new Dimension(230, 30));

        JButton rattunde3Button = new JButton("Rattunde 3");
        rattunde3Button.setFont(new Font("Calibri", Font.BOLD, 16));
        rattunde3Button.setPreferredSize(new Dimension(230, 30));

        JButton rattunde4Button = new JButton("Rattunde 4");
        rattunde4Button.setFont(new Font("Calibri", Font.BOLD, 16));
        rattunde4Button.setPreferredSize(new Dimension(230, 30));

        final JPanel saegenPanel = new JPanel();
        saegenPanel.add(rattundeButton);
        saegenPanel.add(rattunde1Button);
        saegenPanel.add(rattunde2Button);
        saegenPanel.add(rattunde3Button);
        saegenPanel.add(rattunde4Button);
        add(saegenPanel);

        rattundeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                cardManager.show(cardPanel, "Rezept");
            }
        });        
        
        rattunde1Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                cardManager.show(cardPanel, "Rattunde1");
            }
        });

        rattunde2Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                cardManager.show(cardPanel, "Rattunde2");
            }
        });

        rattunde3Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                cardManager.show(cardPanel, "Rattunde3");
            }
        });

        rattunde4Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                cardManager.show(cardPanel, "Rattunde4");
            }
        });

    }
}

//-*****************************************************************************
class SaegenMaschine extends JPanel {

    String maschinenName;
    String verfahrenName;
    final private CardLayout cardManager;
    final private JPanel cardPanel;

    String Rattunde1RohrlaengeEingabe = "";

    JLabel Rattunde1NameLabel;
    JLabel Rattunde1RohrlaengeEingabeLabel;

    final JTextField Rattunde1RohrlaengeTextField = new JTextField(Rattunde1RohrlaengeEingabe);

    JButton Rattunde1RohrlaengeEingabeButton = new JButton("Berechne...");
    JLabel Rattunde1AusgabeLabel = new JLabel("Ausgabe Zeit:");

    JLabel Rattunde1GeschwindigkeitEingabeLabel = new JLabel("Eingabe durchschnittliche Geschwindigkeit:");
    String Rattunde1GeschwindigkeitEingabeString = "";
    final JTextField Rattunde1GeschwindigkeitTextField = new JTextField(Rattunde1GeschwindigkeitEingabeString);
    JButton Rattunde1GeschwindigkeitEingabeButton = new JButton("Geschwindigkeit bestätigen");
    final JLabel Rattunde1GeschwindigkeitEingabeGetLabel = new JLabel("");

    JLabel Rattunde1UhrzeitStartEingabeLabel = new JLabel("Eingabe Uhrzeit Start:");

    String berechneGeschwindigkeitMomentAusgabe = "";
    String berechneDurchschnittlicheGeschwindigkeitAusgabe = "";//

    String berechneZeitGesamtAusgabe = "";

    String Rattunde1UhrzeitStartEingabeString = "";
    String Rattunde1UhrzeitEndeEingabeString = "";
    String Rattunde1DatumStartEingabeString = "";
    String Rattunde1DatumEndeEingabeString = "";
    String Rattunde1AnlageUmbauEingabeString = "";
    String Rattunde1FertigProduziertEingabeString = "";
    String Rattunde1AnlageStoerungEingabeString = "";

    int zeitStunden = 0;
    
//    
//            public static  boolean geschwindigkeitueberprüfunghundert(boolean geschwindigkeitueberprüfunghundert){
//            
//        //    if (Rezept.)
//        //    Rezept.getRezeptGeschwindigkeitEingabe(RezeptGeschwindigkeitEingabe);
//            
//            return geschwindigkeitueberprüfunghundert;
//        }        
           
    

    final JTextField Rattunde1UhrzeitStartTextField = new JTextField(Rattunde1UhrzeitStartEingabeString);
    final JButton Rattunde1UhrzeitStartEingabeButton = new JButton("Uhrzeit Start bestätigen");
    final JLabel Rattunde1UhrzeitStartEingabeGetLabel = new JLabel("");

    public SaegenMaschine(JPanel cardPanel, CardLayout cardManager, String maschinenName, String verfahrenName) throws IOException {//
        this.cardManager = cardManager;
        this.cardPanel = cardPanel;
        this.maschinenName = maschinenName;
        this.verfahrenName = verfahrenName;
        initSaegenMaschine();
    }

    public void initSaegenMaschine() {

        Rattunde1RohrlaengeEingabeLabel = new JLabel(verfahrenName);
        Rattunde1NameLabel = new JLabel(maschinenName);
        Rattunde1NameLabel.setFont(new Font("Calibri", Font.BOLD, 24));
        Rattunde1NameLabel.setPreferredSize(new Dimension(230, 30));
        Rattunde1RohrlaengeEingabeLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        Rattunde1RohrlaengeEingabeLabel.setPreferredSize(new Dimension(230, 30));
        Rattunde1RohrlaengeTextField.setFont(new Font("Calibri", Font.BOLD, 16));
        Rattunde1RohrlaengeTextField.setPreferredSize(new Dimension(230, 30));
        Rattunde1RohrlaengeEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        Rattunde1RohrlaengeEingabeButton.setPreferredSize(new Dimension(230, 30));
        Rattunde1AusgabeLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        Rattunde1AusgabeLabel.setPreferredSize(new Dimension(230, 30));

        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 10);
//******************************************************************************        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 2;
        add(Rattunde1NameLabel, c);
//******************************************************************************        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 8;
        add(Rattunde1RohrlaengeEingabeLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 8;
        add(Rattunde1RohrlaengeTextField, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 8;
        add(Rattunde1RohrlaengeEingabeButton, c);

        final JLabel Rattunde1AusgabeGetLabel = new JLabel("");

        Rattunde1RohrlaengeEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                Rattunde1RohrlaengeEingabe = Rattunde1RohrlaengeTextField.getText();
                System.out.println(Rattunde1RohrlaengeEingabe);
                Rattunde1AusgabeGetLabel.setText("" + Rattunde1RohrlaengeEingabe);
            }
        });

        Rattunde1AusgabeGetLabel.setText(Rattunde1RohrlaengeEingabe);
        Rattunde1AusgabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        Rattunde1AusgabeGetLabel.setPreferredSize(new Dimension(230, 30));

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 8;
        add(Rattunde1AusgabeGetLabel, c);

//******************************************************************************        
        JLabel Rattunde1GeschwindigkeitEingabeLabel = new JLabel("Eingabe durchschnittliche Geschwindigkeit:");

        final JTextField Rattunde1GeschwindigkeitTextField = new JTextField(Rattunde1GeschwindigkeitEingabeString);
        final JButton Rattunde1GeschwindigkeitEingabeButton = new JButton("Geschwindigkeit bestätigen");
        final JLabel Rattunde1GeschwindigkeitEingabeGetLabel = new JLabel("");

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 40;
        add(Rattunde1GeschwindigkeitEingabeLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 40;
        add(Rattunde1GeschwindigkeitTextField, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 40;
        add(Rattunde1GeschwindigkeitEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 40;
        add(Rattunde1GeschwindigkeitEingabeGetLabel, c);

        Rattunde1GeschwindigkeitEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {

                Rattunde1GeschwindigkeitEingabeString = Rattunde1GeschwindigkeitTextField.getText();
                System.out.println(Rattunde1GeschwindigkeitEingabeString);
                Rattunde1GeschwindigkeitEingabeGetLabel.setText("" + Rattunde1GeschwindigkeitEingabeString);
            }
        });

//------------------------------------------------------------------------------        
        final JButton Rattunde1DurchschnittlicheGeschwindigkeitBerechneButton = new JButton("Durchschn. Geschw. berechnen:");

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 10;
        add(Rattunde1DurchschnittlicheGeschwindigkeitBerechneButton, c);

        final JLabel Rattunde1DurchschnittlicheGeschwindigkeitBerechneAusgabeLabel = new JLabel("");

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 10;
        add(Rattunde1DurchschnittlicheGeschwindigkeitBerechneAusgabeLabel, c);

        Rattunde1DurchschnittlicheGeschwindigkeitBerechneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                berechneDurchschnittlicheGeschwindigkeit();
                Rattunde1DurchschnittlicheGeschwindigkeitBerechneAusgabeLabel.setText("" + berechneDurchschnittlicheGeschwindigkeitAusgabe);
            }
        });
//------------------------------------------------------------------------------        

        JLabel Rattunde1FertigProduziertEingabeLabel = new JLabel("Eingabe FertigProduziert:");

        final JTextField Rattunde1FertigProduziertTextField = new JTextField(Rattunde1FertigProduziertEingabeString);
        final JButton Rattunde1FertigProduziertEingabeButton = new JButton("FertigProduziert bestätigen");
        final JLabel Rattunde1FertigProduziertEingabeGetLabel = new JLabel("");

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 11;
        add(Rattunde1FertigProduziertEingabeLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 11;
        add(Rattunde1FertigProduziertTextField, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 11;
        add(Rattunde1FertigProduziertEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 11;
        add(Rattunde1FertigProduziertEingabeGetLabel, c);

        Rattunde1FertigProduziertEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {

                Rattunde1FertigProduziertEingabeString = Rattunde1FertigProduziertTextField.getText();
                System.out.println(Rattunde1FertigProduziertEingabeString);
                Rattunde1FertigProduziertEingabeGetLabel.setText("" + Rattunde1FertigProduziertEingabeString);
            }
        });

//------------------------------------------------------------------------------        
        final JButton Rattunde1GeschwindigkeitMomentBerechneButton = new JButton("Geschw. Moment berechnen:");

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 12;
        add(Rattunde1GeschwindigkeitMomentBerechneButton, c);

        final JLabel Rattunde1GeschwindigkeitMomentBerechneAusgabeLabel = new JLabel("");

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 12;
        add(Rattunde1GeschwindigkeitMomentBerechneAusgabeLabel, c);

        Rattunde1GeschwindigkeitMomentBerechneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                berechneGeschwindigkeitMoment();
                Rattunde1GeschwindigkeitMomentBerechneAusgabeLabel.setText("" + berechneGeschwindigkeitMomentAusgabe);
            }
        });
//------------------------------------------------------------------------------          

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 4;
        add(Rattunde1UhrzeitStartEingabeLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 4;
        add(Rattunde1UhrzeitStartTextField, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 4;
        add(Rattunde1UhrzeitStartEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 4;
        add(Rattunde1UhrzeitStartEingabeGetLabel, c);

        Rattunde1UhrzeitStartEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {

                Rattunde1UhrzeitStartEingabeString = Rattunde1UhrzeitStartTextField.getText();
                System.out.println(Rattunde1UhrzeitStartEingabeString);
                Rattunde1UhrzeitStartEingabeGetLabel.setText("" + Rattunde1UhrzeitStartEingabeString);
            }
        });
//*/////////////////////////////////////////////////////////////////////////////
        JLabel Rattunde1DatumStartEingabeLabel = new JLabel("Eingabe Datum Start:");

        final JTextField Rattunde1DatumStartTextField = new JTextField(Rattunde1DatumStartEingabeString);
        final JButton Rattunde1DatumStartEingabeButton = new JButton("Datum Start bestätigen");
        final JLabel Rattunde1DatumStartEingabeGetLabel = new JLabel("");

        Rattunde1DatumStartTextField.setFont(new Font("Calibri", Font.BOLD, 16));
        Rattunde1DatumStartTextField.setPreferredSize(new Dimension(230, 30));

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 6;
        c.gridy = 4;
        add(Rattunde1DatumStartEingabeLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 7;
        c.gridy = 4;
        add(Rattunde1DatumStartTextField, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 8;
        c.gridy = 4;
        add(Rattunde1DatumStartEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 9;
        c.gridy = 4;
        add(Rattunde1DatumStartEingabeGetLabel, c);

        Rattunde1DatumStartEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                Rattunde1DatumStartEingabeString = Rattunde1DatumStartTextField.getText();
                System.out.println(Rattunde1DatumStartEingabeString);
                Rattunde1DatumStartEingabeGetLabel.setText("" + Rattunde1DatumStartEingabeString);
            }
        });
//*/////////////////////////////////////////////////////////////////////////////        

        JLabel Rattunde1UhrzeitEndeEingabeLabel = new JLabel("Eingabe Uhrzeit Ende:");

        final JTextField Rattunde1UhrzeitEndeTextField = new JTextField(Rattunde1UhrzeitEndeEingabeString);
        final JButton Rattunde1UhrzeitEndeEingabeButton = new JButton("Uhrzeit Ende bestätigen");
        final JLabel Rattunde1UhrzeitEndeEingabeGetLabel = new JLabel("");

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 5;
        add(Rattunde1UhrzeitEndeEingabeLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 5;
        add(Rattunde1UhrzeitEndeTextField, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 5;
        add(Rattunde1UhrzeitEndeEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 5;
        add(Rattunde1UhrzeitEndeEingabeGetLabel, c);

        Rattunde1UhrzeitEndeEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {

                Rattunde1UhrzeitEndeEingabeString = Rattunde1UhrzeitEndeTextField.getText();
                System.out.println(Rattunde1UhrzeitEndeEingabeString);
                Rattunde1UhrzeitEndeEingabeGetLabel.setText("" + Rattunde1UhrzeitEndeEingabeString);
            }
        });

//******************************************************************************
        JLabel Rattunde1DatumEndeEingabeLabel = new JLabel("Eingabe Datum Ende:");

        final JTextField Rattunde1DatumEndeTextField = new JTextField(Rattunde1DatumEndeEingabeString);
        final JButton Rattunde1DatumEndeEingabeButton = new JButton("Datum Ende bestätigen");
        final JLabel Rattunde1DatumEndeEingabeGetLabel = new JLabel("");

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 6;
        c.gridy = 5;
        add(Rattunde1DatumEndeEingabeLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 7;
        c.gridy = 5;
        add(Rattunde1DatumEndeTextField, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 8;
        c.gridy = 5;
        add(Rattunde1DatumEndeEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 9;
        c.gridy = 5;
        add(Rattunde1DatumEndeEingabeGetLabel, c);

        Rattunde1DatumEndeEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {

                Rattunde1DatumEndeEingabeString = Rattunde1DatumEndeTextField.getText();
                System.out.println(Rattunde1DatumEndeEingabeString);
                Rattunde1DatumEndeEingabeGetLabel.setText("" + Rattunde1DatumEndeEingabeString);
            }
        });

//*///////////////////////////////////////////////////////////////////////////// 
        JLabel Rattunde1BerechneZeitGesamtEingabeLabel = new JLabel("BerechneZeitGesamt:");
        final JButton Rattunde1BerechneZeitGesamtEingabeButton = new JButton("BerechneZeitGesamt");
        final JLabel Rattunde1BerechneZeitGesamtAusgabeGetLabel = new JLabel("");

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 6;
        add(Rattunde1BerechneZeitGesamtEingabeLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 6;
        add(Rattunde1BerechneZeitGesamtEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 6;
        add(Rattunde1BerechneZeitGesamtAusgabeGetLabel, c);

        Rattunde1BerechneZeitGesamtEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                BerechneUhrzeitDatum();
                Rattunde1BerechneZeitGesamtAusgabeGetLabel.setText(berechneZeitGesamtAusgabe);
            }
        });

//******************************************************************************
        JLabel Rattunde1BerechneZeitReinProduktivEingabeLabel = new JLabel("BerechneZeitReinProduktiv:");

        final JButton Rattunde1BerechneZeitReinProduktivEingabeButton = new JButton("BerechneZeitReinProduktiv");
        final JLabel Rattunde1BerechneZeitReinProduktivAusgabeGetLabel = new JLabel("");

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 22;
        add(Rattunde1BerechneZeitReinProduktivEingabeLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 22;
        add(Rattunde1BerechneZeitReinProduktivEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 22;
        add(Rattunde1BerechneZeitReinProduktivAusgabeGetLabel, c);

        Rattunde1BerechneZeitReinProduktivEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
            }
        });

//******************************************************************************
        JLabel Rattunde1AnlageStoerungEingabeLabel = new JLabel("Eingabe Anlage Störung:");

        final JTextField Rattunde1AnlageStoerungTextField = new JTextField(Rattunde1AnlageStoerungEingabeString);
        final JButton Rattunde1AnlageStoerungEingabeButton = new JButton("AnlageStörung bestätigen");
        final JLabel Rattunde1AnlageStoerungEingabeGetLabel = new JLabel("");

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 20;
        add(Rattunde1AnlageStoerungEingabeLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 20;
        add(Rattunde1AnlageStoerungTextField, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 20;
        add(Rattunde1AnlageStoerungEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 20;
        add(Rattunde1AnlageStoerungEingabeGetLabel, c);

        Rattunde1AnlageStoerungEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                Rattunde1AnlageStoerungEingabeString = Rattunde1AnlageStoerungTextField.getText();
                System.out.println(Rattunde1AnlageStoerungEingabeString);
                Rattunde1AnlageStoerungEingabeGetLabel.setText("" + Rattunde1AnlageStoerungEingabeString);
            }
        });

//******************************************************************************
        JLabel Rattunde1AnlageUmbauEingabeLabel = new JLabel("Eingabe Anlage Umbau:");

        final JTextField Rattunde1AnlageUmbauTextField = new JTextField(Rattunde1AnlageUmbauEingabeString);
        final JButton Rattunde1AnlageUmbauEingabeButton = new JButton("Anlage Umbau bestätigen");
        final JLabel Rattunde1AnlageUmbauEingabeGetLabel = new JLabel("");

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 21;
        add(Rattunde1AnlageUmbauEingabeLabel, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 21;
        add(Rattunde1AnlageUmbauTextField, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 21;
        add(Rattunde1AnlageUmbauEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 21;
        add(Rattunde1AnlageUmbauEingabeGetLabel, c);

        Rattunde1AnlageUmbauEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                Rattunde1AnlageUmbauEingabeString = Rattunde1AnlageUmbauTextField.getText();
                System.out.println(Rattunde1AnlageUmbauEingabeString);
                Rattunde1AnlageUmbauEingabeGetLabel.setText("" + Rattunde1AnlageUmbauEingabeString);
            }
        });
//*/////////////////////////////////////////////////////////////////////////////          
        Rattunde1RohrlaengeTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Rattunde1RohrlaengeEingabeButton.doClick();
            }
        });

        Rattunde1RohrlaengeEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Rattunde1RohrlaengeEingabeButton.doClick();
            }
        });

        Rattunde1GeschwindigkeitTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Rattunde1GeschwindigkeitEingabeButton.doClick();
            }
        });

        Rattunde1GeschwindigkeitEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                //if(evt.getKeyCode() == KeyEvent.VK_ENTER)
                if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
                    System.out.println("Pressed");
                    Rattunde1GeschwindigkeitEingabeButton.doClick();
                }
            }
        });//KeyStroke.getKeyStroke('a');

        Rattunde1UhrzeitStartEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Rattunde1UhrzeitStartEingabeButton.doClick();
            }
        });

        Rattunde1UhrzeitStartTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Rattunde1UhrzeitStartEingabeButton.doClick();
            }
        });

        Rattunde1DatumStartEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Rattunde1DatumStartEingabeButton.doClick();
            }
        });

        Rattunde1DatumStartTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Rattunde1DatumStartEingabeButton.doClick();
            }
        });

        Rattunde1DatumEndeEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Rattunde1DatumEndeEingabeButton.doClick();
            }
        });

        Rattunde1DatumEndeTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Rattunde1DatumEndeEingabeButton.doClick();
            }
        });

        Rattunde1AnlageStoerungEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Rattunde1AnlageStoerungEingabeButton.doClick();
            }
        });

        Rattunde1AnlageStoerungTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Rattunde1AnlageStoerungEingabeButton.doClick();
            }
        });

        Rattunde1AnlageUmbauEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Rattunde1AnlageUmbauEingabeButton.doClick();
            }
        });

        Rattunde1AnlageUmbauTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Rattunde1AnlageUmbauEingabeButton.doClick();
            }
        });

        Rattunde1UhrzeitEndeEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Rattunde1UhrzeitEndeEingabeButton.doClick();
            }
        });

        Rattunde1UhrzeitEndeTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Rattunde1UhrzeitEndeEingabeButton.doClick();
            }
        });

        Rattunde1FertigProduziertEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Rattunde1FertigProduziertEingabeButton.doClick();
            }
        });

        Rattunde1FertigProduziertTextField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Rattunde1FertigProduziertEingabeButton.doClick();
            }
        });

        Rattunde1BerechneZeitGesamtEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Rattunde1BerechneZeitGesamtEingabeButton.doClick();
            }
        });

        Rattunde1BerechneZeitReinProduktivEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Rattunde1BerechneZeitReinProduktivEingabeButton.doClick();
            }
        });

////////////////////////////////////////////////////////////////////////////////        
    }

    public void berechneZeitGesamt() {

        berechneZeitGesamtAusgabe = "WAGRVC";

        System.out.println(berechneZeitGesamtAusgabe + " = berechneZeitGesamtAusgabe");

        System.out.println(Rattunde1UhrzeitStartEingabeString + " = Rattunde1UhrzeitStartEingabeString");
        System.out.println(Rattunde1UhrzeitEndeEingabeString + " = Rattunde1UhrzeitEndeEingabeString");
        System.out.println(Rattunde1DatumStartEingabeString + " = Rattunde1DatumStartEingabeString");
        System.out.println(Rattunde1DatumEndeEingabeString + " = Rattunde1DatumEndeEingabeString");
        System.out.println(Rattunde1AnlageUmbauEingabeString + " = Rattunde1AnlageUmbauEingabeString");
        System.out.println(Rattunde1FertigProduziertEingabeString + " = Rattunde1FertigProduziertEingabeString");
        System.out.println(Rattunde1AnlageStoerungEingabeString + " = Rattunde1AnlageStoerungEingabeString");

        String datum = "1.2";
        String[] getrennt = datum.split("\\.");

        System.out.println(Arrays.toString(getrennt));

        int d = 0;
        while (d < datum.length()) {
            if (datum.substring(d, d + 1).equals(" ")) {
                System.out.print("hat leertaste");
            } else if (datum.substring(d, d + 1).equals(".")) {
                System.out.print("hat punkt");
            } else if (datum.substring(d, d + 1).equals(":")) {
                System.out.print("hat Doppel punkt");
            } else if (datum.substring(d, d + 1).equals(",")) {
                System.out.print("hat komma");
            } else if (datum.substring(d, d + 1).equals(";")) {
                System.out.print("hat Strich Punkt");
            }
            d++;
        }

    }

//---------------------------------------------------------------------*********
    public void BerechneUhrzeitDatum() {

        String datumStart = Rattunde1DatumStartEingabeString;

        String tagStart = "";
        String monatStart = "";
        String jahrStart = "";

        int zählerFürDatumStart = 0;
        while (zählerFürDatumStart < datumStart.length()) {
            if (datumStart.substring(zählerFürDatumStart, zählerFürDatumStart + 1).equals(" ")) {
                System.out.print("hat leertaste");
                String[] getrenntDatumStart = datumStart.split("\\ ");
                tagStart = getrenntDatumStart[0];
                monatStart = getrenntDatumStart[1];
                jahrStart = getrenntDatumStart[2];
            } else if (datumStart.substring(zählerFürDatumStart, zählerFürDatumStart + 1).equals(".")) {
                System.out.print("hat punkt");
                String[] getrenntDatumStart = datumStart.split("\\.");
                tagStart = getrenntDatumStart[0];
                monatStart = getrenntDatumStart[1];
                jahrStart = getrenntDatumStart[2];
            } else if (datumStart.substring(zählerFürDatumStart, zählerFürDatumStart + 1).equals(":")) {
                System.out.print("hat Doppel punkt");
                String[] getrenntDatumStart = datumStart.split("\\:");
                tagStart = getrenntDatumStart[0];
                monatStart = getrenntDatumStart[1];
                jahrStart = getrenntDatumStart[2];
            } else if (datumStart.substring(zählerFürDatumStart, zählerFürDatumStart + 1).equals(",")) {
                System.out.print("hat komma");
                String[] getrenntDatumStart = datumStart.split("\\,");
                tagStart = getrenntDatumStart[0];
                monatStart = getrenntDatumStart[1];
                jahrStart = getrenntDatumStart[2];
            } else if (datumStart.substring(zählerFürDatumStart, zählerFürDatumStart + 1).equals(";")) {
                System.out.print("hat Strich Punkt");
                String[] getrenntDatumStart = datumStart.split("\\;");
                tagStart = getrenntDatumStart[0];
                monatStart = getrenntDatumStart[1];
                jahrStart = getrenntDatumStart[2];
            }
            zählerFürDatumStart++;
        }

        System.out.println();
        System.out.println(datumStart + " datumStart");

//******************************************************************************
        String datumEnde = Rattunde1DatumEndeEingabeString;

        String tagEnde = "";
        String monatEnde = "";
        String jahrEnde = "";

        int zählerFürDatumEnde = 0;
        while (zählerFürDatumEnde < datumEnde.length()) {
            if (datumEnde.substring(zählerFürDatumEnde, zählerFürDatumEnde + 1).equals(" ")) {
                System.out.print("hat leertaste");
                String[] getrenntDatumEnde = datumEnde.split("\\ ");
                tagEnde = getrenntDatumEnde[0];
                monatEnde = getrenntDatumEnde[1];
                jahrEnde = getrenntDatumEnde[2];
            } else if (datumEnde.substring(zählerFürDatumEnde, zählerFürDatumEnde + 1).equals(".")) {
                System.out.print("hat punkt");
                String[] getrenntDatumEnde = datumEnde.split("\\.");
                tagEnde = getrenntDatumEnde[0];
                monatEnde = getrenntDatumEnde[1];
                jahrEnde = getrenntDatumEnde[2];
            } else if (datumEnde.substring(zählerFürDatumEnde, zählerFürDatumEnde + 1).equals(":")) {
                System.out.print("hat Doppel punkt");
                String[] getrenntDatumEnde = datumEnde.split("\\:");
                tagEnde = getrenntDatumEnde[0];
                monatEnde = getrenntDatumEnde[1];
                jahrEnde = getrenntDatumEnde[2];
            } else if (datumEnde.substring(zählerFürDatumEnde, zählerFürDatumEnde + 1).equals(",")) {
                System.out.print("hat komma");
                String[] getrenntDatumEnde = datumEnde.split("\\,");
                tagEnde = getrenntDatumEnde[0];
                monatEnde = getrenntDatumEnde[1];
                jahrEnde = getrenntDatumEnde[2];
            } else if (datumEnde.substring(zählerFürDatumEnde, zählerFürDatumEnde + 1).equals(";")) {
                System.out.print("hat Strich Punkt");
                String[] getrenntDatumEnde = datumEnde.split("\\;");
                tagEnde = getrenntDatumEnde[0];
                monatEnde = getrenntDatumEnde[1];
                jahrEnde = getrenntDatumEnde[2];
            }
            zählerFürDatumEnde++;
        }

        System.out.println();
        System.out.println(datumEnde + " datumEnde");
//******************************************************************************
        long tagberechne = 0;

        long monatberechnetEnde = 0;
        long monatberechnetStart = 0;
        long jahrberechne = 0;

        tagberechne = Integer.parseInt(tagEnde) - Integer.parseInt(tagStart);
        monatberechnetEnde = ((Integer.parseInt(monatEnde) + 9) % 12) - ((Integer.parseInt(monatStart) + 9) % 12);

        long jahrberechnetEnde = Integer.parseInt(jahrEnde) * 365 + Integer.parseInt(jahrEnde) / 4 - Integer.parseInt(jahrEnde) / 100 + Integer.parseInt(jahrEnde) / 400 + (Integer.parseInt(monatEnde) * 306 + 5) / 10 + (Integer.parseInt(tagEnde) - 1);
        long jahrberechnetStart = Integer.parseInt(jahrStart) * 365 + Integer.parseInt(jahrStart) / 4 - Integer.parseInt(jahrStart) / 100 + Integer.parseInt(jahrStart) / 400 + (Integer.parseInt(monatStart) * 306 + 5) / 10 + (Integer.parseInt(tagStart) - 1);

        jahrberechne = (Integer.parseInt(jahrEnde) - Integer.parseInt(monatEnde) / 10) - ((Integer.parseInt(jahrStart) - Integer.parseInt(monatStart) / 10));

        if (Integer.parseInt(monatEnde) > Integer.parseInt(monatStart)) {

        }

        System.out.println(tagberechne + " = tagberechne");
        System.out.println(monatberechnetEnde + " = monatberechnetEnde");
        System.out.println(jahrberechne + " = jahrberechne");
//******************************************************************************        
        String uhrzeitStart = Rattunde1UhrzeitStartEingabeString;  //0031
        String uhrzeitEnde = Rattunde1UhrzeitEndeEingabeString;   //0129

        String stundeStart = "";
        String minuteStart = "";

        int zaehlerFürUhrzeitStart = 0;
        while (zaehlerFürUhrzeitStart < uhrzeitStart.length()) {
            if (uhrzeitStart.substring(zaehlerFürUhrzeitStart, zaehlerFürUhrzeitStart + 1).equals(" ")) {
                System.out.print("hat leertaste");
                String[] getrenntUhrzeitStart = uhrzeitStart.split("\\ ");
                stundeStart = getrenntUhrzeitStart[0];
                minuteStart = getrenntUhrzeitStart[1];
            } else if (uhrzeitStart.substring(zaehlerFürUhrzeitStart, zaehlerFürUhrzeitStart + 1).equals(".")) {
                System.out.print("hat punkt");
                String[] getrenntUhrzeitStart = uhrzeitStart.split("\\.");
                stundeStart = getrenntUhrzeitStart[0];
                minuteStart = getrenntUhrzeitStart[1];
            } else if (uhrzeitStart.substring(zaehlerFürUhrzeitStart, zaehlerFürUhrzeitStart + 1).equals(":")) {
                System.out.print("hat Doppel punkt");
                String[] getrenntUhrzeitStart = uhrzeitStart.split("\\:");
                stundeStart = getrenntUhrzeitStart[0];
                minuteStart = getrenntUhrzeitStart[1];
            } else if (uhrzeitStart.substring(zaehlerFürUhrzeitStart, zaehlerFürUhrzeitStart + 1).equals(",")) {
                System.out.print("hat komma");
                String[] getrenntUhrzeitStart = uhrzeitStart.split("\\,");
                stundeStart = getrenntUhrzeitStart[0];
                minuteStart = getrenntUhrzeitStart[1];
            } else if (uhrzeitStart.substring(zaehlerFürUhrzeitStart, zaehlerFürUhrzeitStart + 1).equals(";")) {
                System.out.print("hat Strich Punkt");
                String[] getrenntUhrzeitStart = uhrzeitStart.split("\\;");
                stundeStart = getrenntUhrzeitStart[0];
                minuteStart = getrenntUhrzeitStart[1];
            }
            zaehlerFürUhrzeitStart++;
        }

        System.out.println();
        System.out.println(uhrzeitStart + " = UhrzeitStart");

//------------------------------------------------------------------------------     
        String stundeEnde = "";
        String minuteEnde = "";

        int zaehlerFürUhrzeitEnde = 0;
        while (zaehlerFürUhrzeitEnde < uhrzeitEnde.length()) {
            if (uhrzeitEnde.substring(zaehlerFürUhrzeitEnde, zaehlerFürUhrzeitEnde + 1).equals(" ")) {
                System.out.print("hat leertaste");
                String[] getrenntUhrzeitEnde = uhrzeitEnde.split("\\ ");
                stundeEnde = getrenntUhrzeitEnde[0];
                minuteEnde = getrenntUhrzeitEnde[1];
            } else if (uhrzeitEnde.substring(zaehlerFürUhrzeitEnde, zaehlerFürUhrzeitEnde + 1).equals(".")) {
                System.out.print("hat punkt");
                String[] getrenntUhrzeitEnde = uhrzeitEnde.split("\\.");
                stundeEnde = getrenntUhrzeitEnde[0];
                minuteEnde = getrenntUhrzeitEnde[1];
            } else if (uhrzeitEnde.substring(zaehlerFürUhrzeitEnde, zaehlerFürUhrzeitEnde + 1).equals(":")) {
                System.out.print("hat Doppel punkt");
                String[] getrenntUhrzeitEnde = uhrzeitEnde.split("\\:");
                stundeEnde = getrenntUhrzeitEnde[0];
                minuteEnde = getrenntUhrzeitEnde[1];
            } else if (uhrzeitEnde.substring(zaehlerFürUhrzeitEnde, zaehlerFürUhrzeitEnde + 1).equals(",")) {
                System.out.print("hat komma");
                String[] getrenntUhrzeitEnde = uhrzeitEnde.split("\\,");
                stundeEnde = getrenntUhrzeitEnde[0];
                minuteEnde = getrenntUhrzeitEnde[1];
            } else if (uhrzeitEnde.substring(zaehlerFürUhrzeitEnde, zaehlerFürUhrzeitEnde + 1).equals(";")) {
                System.out.print("hat Strich Punkt");
                String[] getrenntUhrzeitEnde = uhrzeitEnde.split("\\;");
                stundeEnde = getrenntUhrzeitEnde[0];
                minuteEnde = getrenntUhrzeitEnde[1];
            }
            zaehlerFürUhrzeitEnde++;
        }

        System.out.println();
        System.out.println(uhrzeitEnde + " = UhrzeitEnde");

//-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*--*-*-*-*-*--*-*--*-*-*-*----*-*-*
        int mStart = Integer.parseInt(minuteStart);
        int sStart = Integer.parseInt(stundeStart);

        int mEnde = Integer.parseInt(minuteEnde);
        int sEnde = Integer.parseInt(stundeEnde);

        int restMinuten = 60 - mStart;
        int restStunden = 24 - sStart;

        int mx = 60 - restMinuten - mEnde;

        int restTag = (int) tagberechne - 1;

        System.out.println(restMinuten + " = minutess");
        System.out.println(restStunden + " = stundess");
        System.out.println(restTag + " = restTag");

        int zeitMinuten = 0;

        if (tagberechne == 0 && monatberechnetEnde == 0) {
            if (sStart == sEnde && mEnde == mStart) {
                zeitStunden = 0;
                zeitMinuten = 0;
            }

            if (sStart == sEnde && mEnde > mStart) {
                zeitStunden = 0;
                zeitMinuten = mEnde - mStart;
            }
            if (sStart == sEnde && mEnde < mStart) {
                zeitStunden = 23;
                zeitMinuten = 60 - mx;
            }

            if (sStart < sEnde && mEnde == mStart) {
                zeitStunden = sEnde - sStart;
                zeitMinuten = 0;
            }
            if (sStart > sEnde && mEnde == mStart) {
                System.out.println("Fehler!!");
            }

            if (sStart < sEnde && mEnde < mStart) {
                if ((sEnde - sStart) == 1) {
                    zeitStunden = 0;
                } else if ((sEnde - sStart) > 1) {
                    zeitStunden = sEnde - sStart - 1;
                }
                zeitMinuten = 60 - mx;
            }
            if (sStart < sEnde && mEnde > mStart) {
                zeitStunden = sEnde - sStart;
                zeitMinuten = mEnde - mStart;
            }

            if (sStart > sEnde && mEnde > mStart) {
                System.out.println("Fehler!!");
            }
            if (sStart > sEnde && mEnde < mStart) {
                System.out.println("Fehler!!");
            }
        } else if (tagberechne == 1 && monatberechnetEnde == 0) {

            if (sStart == sEnde && mEnde == mStart) {
                zeitStunden = 24;
                zeitMinuten = 0;
            }

            if (sStart == sEnde && mEnde > mStart) {
                zeitStunden = 23;
                zeitMinuten = mEnde - mStart;
            }
            if (sStart == sEnde && mEnde < mStart) {
                zeitStunden = 23;
                zeitMinuten = 60 - mx;
            }

            if (sStart < sEnde && mEnde == mStart) {
                zeitStunden = sEnde - sStart;
                zeitMinuten = 0;
            }
            if (sStart > sEnde && mEnde == mStart) {
                zeitStunden = 24 - (sStart - sEnde);
                zeitMinuten = 0;
            }

            if (sStart < sEnde && mEnde < mStart) {
                if ((sEnde - sStart) == 1) {
                    zeitStunden = 0;
                } else if ((sEnde - sStart) > 1) {
                    zeitStunden = sEnde - sStart - 1;
                }
                zeitMinuten = 60 - mx;
            }
            if (sStart < sEnde && mEnde > mStart) {
                zeitStunden = sEnde - sStart;
                zeitMinuten = mEnde - mStart;
            }       

            if (sStart > sEnde && mEnde > mStart) {
                if ((sStart - sEnde) == 1) {
                    zeitStunden = 23;
                } else if ((sStart - sEnde) > 1) {
                    zeitStunden = 24 - (sStart - sEnde);
                }
                zeitMinuten = mEnde - mStart;
            }
            if (sStart > sEnde && mEnde < mStart) {

                if ((sStart - sEnde) == 23) {
                    zeitStunden = 0;
                } else if ((sStart - sEnde) < 23) {
                    zeitStunden = restStunden;
                }
                zeitMinuten = 60 - mx;
            }

        } else if (tagberechne > 0) {
            if (sStart == sEnde && mEnde == mStart) {
                zeitStunden = 0 + restTag * 24;
                zeitMinuten = 0;
            }

            if (sStart == sEnde && mEnde > mStart) {
                zeitStunden = 0 + restTag * 24;
                zeitMinuten = mEnde - mStart;
            }
            if (sStart == sEnde && mEnde < mStart) {
                zeitStunden = 23 + restTag * 24;
                zeitMinuten = 60 - mx;
            }

            if (sStart < sEnde && mEnde == mStart) {
                zeitStunden = sEnde - sStart + restTag * 24;
                zeitMinuten = 0;
            }
            if (sStart > sEnde && mEnde == mStart) {
                zeitStunden = 24 - (sStart - sEnde) + restTag * 24;
                zeitMinuten = 0;
            }

            if (sStart < sEnde && mEnde < mStart) {
                if ((sEnde - sStart) == 1) {
                    zeitStunden = 0 + restTag * 24;
                } else if ((sEnde - sStart) > 1) {
                    zeitStunden = sEnde - sStart - 1 + restTag * 24;
                }
                zeitMinuten = 60 - mx;
            }
            if (sStart < sEnde && mEnde > mStart) {
                zeitStunden = sEnde - sStart + restTag * 24;
                zeitMinuten = mEnde - mStart;
            }

            if (sStart > sEnde && mEnde > mStart) {
                if ((sStart - sEnde) == 1) {
                    zeitStunden = 23 + restTag * 24;
                } else if ((sStart - sEnde) > 1) {
                    zeitStunden = 24 - (sStart - sEnde) + restTag * 24;
                }
                zeitMinuten = mEnde - mStart;
            }
            if (sStart > sEnde && mEnde < mStart) {

                if ((sStart - sEnde) == 23) {
                    zeitStunden = 0 + restTag * 24;
                } else if ((sStart - sEnde) < 23) {
                    zeitStunden = restStunden + restTag * 24;
                }
                zeitMinuten = 60 - mx;
            }
        }

        System.out.println(zeitMinuten + " zeitminuten berechnet");

        System.out.println(zeitStunden + " zeitstunden berechnet");
//------------------------------------------------------------------------------

        berechneZeitGesamtAusgabe = zeitStunden + " h\n" + zeitMinuten + " m\n     " + tagberechne + " d\n" + monatberechnetEnde + " M\n" + jahrberechne + " j";

    }
//------------------------------------------------------------------------****** 

    public void berechneDurchschnittlicheGeschwindigkeit() {
        int rohrlaenge = Integer.parseInt(Rattunde1RohrlaengeEingabe);
        int stundenlaenge = zeitStunden;
        int geschwindigkeitlaenge = 0;
        geschwindigkeitlaenge = rohrlaenge / stundenlaenge;
        berechneDurchschnittlicheGeschwindigkeitAusgabe = Integer.toString(geschwindigkeitlaenge) + " Rohre / Stunde";
    }

    public void berechneGeschwindigkeitMoment() {
        int rohrlaenge = Integer.parseInt(Rattunde1RohrlaengeEingabe);//3000
        int rohrproduziert = Integer.parseInt(Rattunde1FertigProduziertEingabeString);//200
        int stundenlaenge = zeitStunden;//3
        int geschwindigkeitproduziertlaenge = 0;
        int geschwindigkeitlaenge = 0;
        geschwindigkeitlaenge = rohrlaenge / stundenlaenge;//1000     
        geschwindigkeitproduziertlaenge = (rohrproduziert / stundenlaenge);
        int vreal = rohrlaenge / geschwindigkeitproduziertlaenge;
        berechneGeschwindigkeitMomentAusgabe = Integer.toString(geschwindigkeitproduziertlaenge) + " Rohre / Stunde    " + Integer.toString(vreal) + " h";
    }

}

//******************************************************************************
class Rezept extends JPanel {

    String maschinenName;
    String verfahrenName;
    
    
    
    JButton RezeptArtikelnummerEingabeButton;
    boolean falscheRezeptErstellenFehler;
    boolean falscheArtikelnummer;
    boolean falscheArtikelname;
    boolean falscheTeilenummer;
    boolean falscheZeichnungsnummer;
    boolean falscheErstellung;
    boolean falscheGeschwindigkeit;
    boolean falscheAnzahlWanddickenUnterschied;
    
    boolean ohneAe;
    boolean KeinBuchstabe = false;
    
    
    public static boolean geschwindigkeitueberprüfunghundert;
    public static String RezeptArtikelnummerEingabe = "";
    public static String RezeptArtikelnameEingabe = "";
    public static String RezeptTeilenummerEingabe = "";
    public static String RezeptZeichnungsnummerEingabe = "";
    public static String RezeptErstellungEingabe = "";
    //public static String RattundeArtikelnummerEingabe = "";
    public static String RezeptAnzahlWanddickenUnterschiedEingabe = "";
    public static String RezeptGeschwindigkeitEingabe = "";
    public static String RezeptGeschwindigkeitEingabeRichtig = "";
    
    public static String RezeptFixlaengeEingabe = "";
    
    public static String RezeptZwischenstueckEingabe = "";
    public static String RezeptMehrfachlaengeEingabe = "";
    
    
    public static String RezeptAnzahlFixlaengeEingabe = "";
    public static String RezeptObereToleranzEingabe = "";
    public static String RezeptUntereToleranzEingabe = "";
    
    
    
    String wanddickeAktuell = "15";
    String passwortRezeptEingabe = "";
    //String passwortNameButtonLabel = ":";
    String passwortNameButtonLabel = "";
    String passwortRezept = "1234";
    
    
    final JLabel labelBeispielGeschwindigkeitEingabe = new JLabel("z.B: 15");//MTT0501DC013 026.50x3.40-2.95 - 15m/min -
    final JLabel RezeptGeschwindigkeitAusgabeGetLabel = new JLabel("");
    
    
    
    
    
    
    
        public static  boolean geschwindigkeitueberprüfunghundert(boolean geschwindigkeitueberprüfunghundert, String RezeptGeschwindigkeitEingabe){
            
            geschwindigkeitueberprüfunghundert = false;
            int zähler = 0;
            
            if (RezeptGeschwindigkeitEingabe.length() == 0){
                geschwindigkeitueberprüfunghundert = true;
            }
            else if (RezeptGeschwindigkeitEingabe.length() > 0){
                for (int i = 0; i<RezeptGeschwindigkeitEingabe.length(); i++ ){
                    zähler++;
                }
                
                if (zähler >= 3){
                    geschwindigkeitueberprüfunghundert = true;
                    
                }
                else{
                    for (int i = 0; i<RezeptGeschwindigkeitEingabe.length(); i++ ){
//                    RezeptGeschwindigkeitEingabe(i).matches("[0-9]";
                    //labelGetGeschwindigkeit.setText("Erst Geschwindigkeit eingeben!!!");
                }
                }
                //stringKleinePauseGesamt.matches("[0-9]" + "[0-9]" + "[0-9]"))
            }
            
        //    Rezept.getRezeptGeschwindigkeitEingabe(RezeptGeschwindigkeitEingabe);
            
            return geschwindigkeitueberprüfunghundert;
        }        
           
//    public static String geschwindigkeitueberprüfen(String RezeptGeschwindigkeitEingabe){
//        return 
//    }

        
        
    public static String getFixlaengeEingabe() {
        return RezeptFixlaengeEingabe;
    }

    public static void setFixlaengeEingabe(String RezeptFixlaengeEingabe) {
        Rezept.RezeptFixlaengeEingabe = RezeptFixlaengeEingabe;
    }   
                
                

    public static String getRezeptGeschwindigkeitEingabeRichtig() {
        return RezeptGeschwindigkeitEingabeRichtig;
    }

    public static void setRezeptGeschwindigkeitEingabeRichtig(String RezeptGeschwindigkeitEingabeRichtig) {
        Rezept.RezeptGeschwindigkeitEingabeRichtig = RezeptGeschwindigkeitEingabeRichtig;
    }            
        
    public static String getRezeptGeschwindigkeitEingabe() {
        return RezeptGeschwindigkeitEingabe;
    }

    public static void setRezeptGeschwindigkeitEingabe(String RezeptGeschwindigkeitEingabe) {
        Rezept.RezeptGeschwindigkeitEingabe = RezeptGeschwindigkeitEingabe;
    }    
        
    public static String getRezeptArtikelnameEingabe() {
        return RezeptArtikelnameEingabe;
    }

    public static void setRezeptArtikelnameEingabe(String RezeptArtikelnameEingabe) {
        Rezept.RezeptArtikelnameEingabe = RezeptArtikelnameEingabe;
    }
     
    public static String getRezeptArtikelnummerEingabe() {
        return RezeptArtikelnummerEingabe;
    }

    public static void setRezeptArtikelnummerEingabe(String RezeptArtikelnummerEingabe) {
Rezept.RezeptArtikelnameEingabe = RezeptArtikelnameEingabe;        
//this.RattundeArtikelnummerEingabe = RattundeArtikelnummerEingabe;
    }
   
    public static String getRezeptTeilenummerEingabe() {
        return RezeptTeilenummerEingabe;
    }

    public static void setRezeptTeilenummerEingabe(String RezeptTeilenummerEingabe) {
        Rezept.RezeptTeilenummerEingabe = RezeptTeilenummerEingabe;
    }    

    public static String getRezeptZeichnungsnummerEingabe() {
        return RezeptZeichnungsnummerEingabe;
    }

    public static void setRezeptZeichnungsnummerEingabe(String RezeptZeichnungsnummerEingabe) {
        Rezept.RezeptZeichnungsnummerEingabe = RezeptZeichnungsnummerEingabe;
    }  
    
    public static String getRezeptErstellungEingabe() {
        return RezeptErstellungEingabe;
    }

    public static void setRezeptErstellungEingabe(String RezeptErstellungEingabe) {
        Rezept.RezeptErstellungEingabe = RezeptErstellungEingabe;
    }
    
    public static String getRezeptAnzahlWanddickenUnterschiedEingabe() {
        return RezeptAnzahlWanddickenUnterschiedEingabe;
    }

    public static void setRezeptAnzahlWanddickenUnterschiedEingabe(String RezeptAnzahlWanddickenUnterschiedEingabe) {
        Rezept.RezeptAnzahlWanddickenUnterschiedEingabe = RezeptAnzahlWanddickenUnterschiedEingabe;
    }   

    final private CardLayout cardManager;
    final private JPanel cardPanel;

    public Rezept(JPanel cardPanel, CardLayout cardManager, String maschinenName, String verfahrenName) throws IOException {
        this.cardManager = cardManager;
        this.cardPanel = cardPanel;
        this.maschinenName = maschinenName;
        this.verfahrenName = verfahrenName;
        initRezept();
    }

    public void initRezept() {

        final JLabel labelMaschinenName = new JLabel(maschinenName);
        labelMaschinenName.setFont(new Font("Calibri", Font.BOLD, 36));
        labelMaschinenName.setForeground(Color.blue.brighter());
        labelMaschinenName.setPreferredSize(new Dimension(230, 30));
//------------------------------------------------------------------------------
  
        final JLabel labelGeschwindigkeitEingabe = new JLabel("Geschwindigkeit:");
        labelGeschwindigkeitEingabe.setFont(new Font("Calibri", Font.BOLD, 16));
        labelGeschwindigkeitEingabe.setPreferredSize(new Dimension(230, 30));

        final JTextField textFieldGeschwindigkeit = new JTextField(RezeptGeschwindigkeitEingabe);
        //final JTextField textFieldGeschwindigkeit = new JTextField("");
        textFieldGeschwindigkeit.setFont(new Font("Calibri", Font.BOLD, 24));
        textFieldGeschwindigkeit.setPreferredSize(new Dimension(230, 30));

        final JButton RezeptGeschwindigkeitEingabeButton = new JButton("Geschwindigkeit bestätigen");
        RezeptGeschwindigkeitEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        RezeptGeschwindigkeitEingabeButton.setPreferredSize(new Dimension(230, 30));

        final JLabel labelGetGeschwindigkeit = new JLabel("Ausgabe Geschwindigkeit:");
        labelGetGeschwindigkeit.setFont(new Font("Calibri", Font.BOLD, 16));
        labelGetGeschwindigkeit.setPreferredSize(new Dimension(230, 30)); 
        
        textFieldGeschwindigkeit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                RezeptGeschwindigkeitEingabeButton.doClick();
            }
        });             

        RezeptGeschwindigkeitEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RezeptGeschwindigkeitEingabeButton.doClick();
            }
        });
                                  
        final JButton RezeptGeschwindigkeitPasswortEingabeButton = new JButton(passwortNameButtonLabel);
        RezeptGeschwindigkeitPasswortEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        RezeptGeschwindigkeitPasswortEingabeButton.setPreferredSize(new Dimension(230, 30));  
        
        labelBeispielGeschwindigkeitEingabe.setFont(new Font("Calibri", Font.ITALIC, 16));
        labelBeispielGeschwindigkeitEingabe.setPreferredSize(new Dimension(230, 30)); 
     
        

        RezeptGeschwindigkeitEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                RezeptGeschwindigkeitEingabe = textFieldGeschwindigkeit.getText();
                //System.out.println(RezeptGeschwindigkeitEingabe + " bei Button");
                //RezeptGeschwindigkeitAusgabeGetLabel.setText("" + RezeptGeschwindigkeitEingabe);
                //15
                //setRezeptGeschwindigkeitEingabe(RezeptGeschwindigkeitEingabe);
                //RezeptGeschwindigkeitAusgabeGetLabel.setText(RezeptGeschwindigkeitEingabe);
                RezeptGeschwindigkeitAusgabeGetLabel.setText("Button OK");

                int i = Integer.parseInt(RezeptGeschwindigkeitEingabe);
                if(i > 15 || i < 15){                   
                    RezeptGeschwindigkeitAusgabeGetLabel.setText("Go to Password! -->");
                    //passwortNameButtonLabel = "Passwort Hello Kitty";
                }else{
                    setRezeptGeschwindigkeitEingabe(wanddickeAktuell);
                    //passwortNameButtonLabel = ":";
                    //RezeptGeschwindigkeitPasswortEingabeButton(passwortNameButtonLabel);
                    RezeptGeschwindigkeitEingabe = "15";
                    RezeptGeschwindigkeitAusgabeGetLabel.setText(RezeptGeschwindigkeitEingabe);
                }
                
                
            }
        });
        
        
        RezeptGeschwindigkeitAusgabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 24));
        RezeptGeschwindigkeitAusgabeGetLabel.setPreferredSize(new Dimension(230, 30));                
        
        
        
        
        RezeptGeschwindigkeitEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                        
                RezeptGeschwindigkeitEingabe = textFieldGeschwindigkeit.getText();
                falscheGeschwindigkeit = false;
                    if (RezeptGeschwindigkeitEingabe.length()==0) {
                        falscheGeschwindigkeit = true;
                        labelGetGeschwindigkeit.setForeground(Color.red);
                        labelGetGeschwindigkeit.setFont(new Font("Calibri", Font.ITALIC, 16));
                        labelGetGeschwindigkeit.setText("Erst Geschwindigkeit eingeben!!!");
                    } 
                    //gegen buchstaben sichern
                    if (RezeptGeschwindigkeitEingabe.length()>0  && (falscheGeschwindigkeit != true) ){
                        //Kontrolliere Buchstabe
                        if (RezeptGeschwindigkeitEingabe.matches("[0-9]" + "[0-9]" + "[0-9]")){
                        KeinBuchstabe = false;
                    //if (RezeptGeschwindigkeitEingabe.matches("[0-9]")
                        System.out.println("KeinBuchstabeBoolean = " + KeinBuchstabe);
                        }
                        else{
                            KeinBuchstabe = true;
                            RezeptGeschwindigkeitAusgabeGetLabel.setText("keine Zahl!!");
                            RezeptGeschwindigkeitAusgabeGetLabel.setForeground(Color.red);
                        }
//                        int i = Integer.parseInt(RezeptGeschwindigkeitEingabe);
//                        System.out.println("i für pars: " + i);
                    }
                    
                    
                    if((RezeptGeschwindigkeitEingabe.length()>0) && (KeinBuchstabe != true)) {
                        falscheGeschwindigkeit = false;
                        labelGetGeschwindigkeit.setForeground(Color.black);             
                        RezeptGeschwindigkeitEingabe = textFieldGeschwindigkeit.getText();                    
                        RezeptGeschwindigkeitEingabe = textFieldGeschwindigkeit.getText();
                        labelGetGeschwindigkeit.setFont(new Font("Calibri", Font.BOLD, 16));
                        labelGetGeschwindigkeit.setText("Ausgabe Geschwindigkeit:");                                        
                        setRezeptGeschwindigkeitEingabe(RezeptGeschwindigkeitEingabe);
                        System.out.println(RezeptGeschwindigkeitEingabe);
                        RezeptGeschwindigkeitAusgabeGetLabel.setText("" + getRezeptGeschwindigkeitEingabe());                        
                    }            
            }
        }); 
     
//------------------------------------------------------------------------------
      

        RezeptGeschwindigkeitPasswortEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RezeptGeschwindigkeitPasswortEingabeButton.doClick();

            }
        });        


        
//-*-*-*-***********************************--------*******************************************------------------        
        
        RezeptGeschwindigkeitPasswortEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {

                final JFrame passwortJFrame = new JFrame("Passwort");
                passwortJFrame.setVisible(true);
                passwortJFrame.setSize(200, 80);
                //passwortJFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
                final JPasswordField textFieldPasswortEingabe = new JPasswordField(6);
                
                //passwordField = new JPasswordField(10);
                //passwordField.setActionCommand(OK);
                //passwordField.addActionListener(this);            
                
                textFieldPasswortEingabe.setEchoChar('#');
                JPanel passwortpanel = new JPanel();
                passwortJFrame.add(passwortpanel);
                passwortpanel.add(textFieldPasswortEingabe);
                final JButton passwortEingabeButton = new JButton("weiter");
                passwortpanel.add(passwortEingabeButton);

            passwortEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                passwortEingabeButton.doClick();
            }
        });               
//            passField.addKeyListener(new java.awt.event.KeyAdapter() {
//            @Override
//            public void keyReleased(java.awt.event.KeyEvent evt) {
//                passwortEingabeButton.doClick();
//            }            
            
        textFieldPasswortEingabe.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                passwortEingabeButton.doClick();
            }
        });               
            
                     

            
        passwortEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
             //String passwd = new String (pass.getText());     
        passwortRezeptEingabe = textFieldPasswortEingabe.getText();
             if (passwortRezeptEingabe.equals("1234")){
                 //passwort.setVisible(false);
                 //Frame.setVisible(true);
                 textFieldPasswortEingabe.setBackground(Color.green);
                // geschwindigkeitueberprüfunghundert();
                setRezeptGeschwindigkeitEingabe(RezeptGeschwindigkeitEingabeRichtig);
                RezeptGeschwindigkeitEingabeRichtig = textFieldGeschwindigkeit.getText();
                
                
                //RezeptGeschwindigkeitAusgabeGetLabel.setText(RezeptGeschwindigkeitEingabeRichtig);
                
                RezeptGeschwindigkeitAusgabeGetLabel.setText(RezeptGeschwindigkeitEingabeRichtig);
                System.out.println("oiuhguzgzgzggzgg");
             } 
             else{
                 textFieldPasswortEingabe.setBackground(Color.red);
                 
                    RezeptGeschwindigkeitEingabeRichtig = "15";
                    RezeptGeschwindigkeitAusgabeGetLabel.setText(RezeptGeschwindigkeitEingabeRichtig);
                    
                    
                 //RezeptGeschwindigkeitEingabe = "15";
             }

            }    
        });            
                        
                final JFrame Frame = new JFrame("Haupfenster");
                Frame.setVisible(false);
                Frame.setSize(500, 500);
                Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            }    
        });    
        
     
    
        
//-*-*-*-***********************************--------*******************************************------------------         
        
        final JLabel labelArtikelnummerEingabe = new JLabel("Artikelnummer:");
        labelArtikelnummerEingabe.setFont(new Font("Calibri", Font.BOLD, 16));
        labelArtikelnummerEingabe.setPreferredSize(new Dimension(230, 30));       

        final JTextField textFieldArtikelnummer = new JTextField(RezeptArtikelnummerEingabe);
        textFieldArtikelnummer.setFont(new Font("Calibri", Font.BOLD, 16));
        textFieldArtikelnummer.setPreferredSize(new Dimension(230, 30));
        
        final JLabel labelBeispielArtikelnummerEingabe = new JLabel("z.B: 10182216");
        labelBeispielArtikelnummerEingabe.setFont(new Font("Calibri", Font.ITALIC, 16));
        labelBeispielArtikelnummerEingabe.setPreferredSize(new Dimension(230, 30)); 
        
        RezeptArtikelnummerEingabeButton = new JButton("Artikelnummer bestätigen");
        RezeptArtikelnummerEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        RezeptArtikelnummerEingabeButton.setPreferredSize(new Dimension(230, 30));
        
        textFieldArtikelnummer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                RezeptArtikelnummerEingabeButton.doClick();
            }
        });             

        RezeptArtikelnummerEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RezeptArtikelnummerEingabeButton.doClick();
            }
        });
        
        final JLabel labelGetArtikelnummer = new JLabel("Ausgabe Artikelnummer:");
        labelGetArtikelnummer.setFont(new Font("Calibri", Font.BOLD, 16));
        labelGetArtikelnummer.setPreferredSize(new Dimension(230, 30));
        
        final JLabel RezeptArtikelnummerAusgabeGetLabel = new JLabel("");

        RezeptArtikelnummerEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                RezeptArtikelnummerEingabe = textFieldArtikelnummer.getText();
                falscheArtikelnummer = false;
                if (RezeptArtikelnummerEingabe.length()==0) {
                    falscheArtikelnummer = true;
                    labelGetArtikelnummer.setForeground(Color.red);
                    labelGetArtikelnummer.setFont(new Font("Calibri", Font.ITALIC, 16));
                    labelGetArtikelnummer.setText("Erst Artikelnummer eingeben!!!");
                } 
                
                else if (RezeptArtikelnummerEingabe.length()<8 && RezeptArtikelnummerEingabe.length()>0){ 
                    falscheArtikelnummer = true;
                    labelGetArtikelnummer.setForeground(Color.red);
                    labelGetArtikelnummer.setFont(new Font("Calibri", Font.ITALIC, 16));
                    labelGetArtikelnummer.setText("Artikelnummer zu klein!!!");
                } else if (RezeptArtikelnummerEingabe.length()>8){ 
                    falscheArtikelnummer = true;
                    labelGetArtikelnummer.setForeground(Color.red);
                    labelGetArtikelnummer.setFont(new Font("Calibri", Font.ITALIC, 16));
                    labelGetArtikelnummer.setText("Artikelnummer zu gross!!!");
                } else 
                    
                if((RezeptArtikelnummerEingabe.matches("[0-9]" + "[0-9]" + "[0-9]" + "[0-9]" + "[0-9]" + "[0-9]" + "[0-9]" + "[0-9]")) && (falscheArtikelnummer != true)) {
                    falscheArtikelnummer = false;
                    labelGetArtikelnummer.setForeground(Color.black);             
                    RezeptArtikelnummerEingabe = textFieldArtikelnummer.getText();
                    
                    RezeptArtikelnummerEingabe = textFieldArtikelnummer.getText();
                    labelGetArtikelnummer.setText("Ausgabe Artikelnummer:");
                                        
                    setRezeptArtikelnummerEingabe(RezeptArtikelnummerEingabe);
                    System.out.println(RezeptArtikelnummerEingabe);
                    RezeptArtikelnummerAusgabeGetLabel.setText("" + getRezeptArtikelnummerEingabe());                       
                }else{
                    falscheArtikelnummer = true;
                    labelGetArtikelnummer.setForeground(Color.red);
                    labelGetArtikelnummer.setText("Enthält keine Zahl!!!");
                }
            }    
        });

        RezeptArtikelnummerAusgabeGetLabel.setText(RezeptArtikelnummerEingabe);
        RezeptArtikelnummerAusgabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RezeptArtikelnummerAusgabeGetLabel.setPreferredSize(new Dimension(230, 30));           
//------------------------------------------------------------------------------        
        
        JLabel labelArtikelnameEingabe = new JLabel("Artikelname:");
        labelArtikelnameEingabe.setFont(new Font("Calibri", Font.BOLD, 16));
        labelArtikelnameEingabe.setPreferredSize(new Dimension(230, 30));

        final JTextField textFieldArtikelname = new JTextField(RezeptArtikelnameEingabe);
        textFieldArtikelname.setFont(new Font("Calibri", Font.BOLD, 16));
        textFieldArtikelname.setPreferredSize(new Dimension(230, 30));

        final JButton RezeptArtikelnameEingabeButton = new JButton("Artikelname bestätigen");
        RezeptArtikelnameEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        RezeptArtikelnameEingabeButton.setPreferredSize(new Dimension(230, 30));
        
        textFieldArtikelname.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                RezeptArtikelnameEingabeButton.doClick();
            }
        });             

        RezeptArtikelnameEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RezeptArtikelnameEingabeButton.doClick();
            }
        });
                                  
        JLabel labelBeispielArtikelnameEingabe = new JLabel("z.B: 026.50x3.40-2.95");//MTT0501DC013 026.50x3.40-2.95 - 15m/min -
        labelBeispielArtikelnameEingabe.setFont(new Font("Calibri", Font.ITALIC, 16));
        labelBeispielArtikelnameEingabe.setPreferredSize(new Dimension(230, 30)); 

        final JLabel labelGetArtikelname = new JLabel("Ausgabe Artikelname:");
        labelGetArtikelname.setFont(new Font("Calibri", Font.BOLD, 16));
        labelGetArtikelname.setPreferredSize(new Dimension(230, 30));    
        
        final JLabel RezeptArtikelnameAusgabeGetLabel = new JLabel("");

        RezeptArtikelnameEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                RezeptArtikelnameEingabe = textFieldArtikelname.getText();
                falscheArtikelname = false;
                    if (RezeptArtikelnameEingabe.length()==0) {
                        falscheArtikelname = true;
                        labelGetArtikelname.setForeground(Color.red);
                        labelGetArtikelname.setFont(new Font("Calibri", Font.ITALIC, 16));
                        labelGetArtikelname.setText("Erst Artikelname eingeben!!!");
                    } 
                    else if((RezeptArtikelnameEingabe.length()>0) && (falscheArtikelnummer != true)) {
                        falscheArtikelname = false;
                        labelGetArtikelname.setForeground(Color.black);             
                        RezeptArtikelnameEingabe = textFieldArtikelname.getText();                    
                        labelGetArtikelname.setFont(new Font("Calibri", Font.BOLD, 16));
                        RezeptArtikelnummerEingabe = textFieldArtikelnummer.getText();
                        labelGetArtikelname.setText("Ausgabe Artikelname:");                                        
                        setRezeptArtikelnameEingabe(RezeptArtikelnameEingabe);
                        System.out.println(RezeptArtikelnameEingabe);
                        RezeptArtikelnameAusgabeGetLabel.setText("" + getRezeptArtikelnameEingabe());                        
                    }        
                }
        });

        RezeptArtikelnameAusgabeGetLabel.setText(RezeptArtikelnameEingabe);
        RezeptArtikelnameAusgabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RezeptArtikelnameAusgabeGetLabel.setPreferredSize(new Dimension(230, 30));
//------------------------------------------------------------------------------
 
        JLabel labelTeilenummerEingabe = new JLabel("Teilenummer:");
        labelTeilenummerEingabe.setFont(new Font("Calibri", Font.BOLD, 16));
        labelTeilenummerEingabe.setPreferredSize(new Dimension(230, 30));

        final JTextField textFieldTeilenummer = new JTextField(RezeptTeilenummerEingabe);
        textFieldTeilenummer.setFont(new Font("Calibri", Font.BOLD, 16));
        textFieldTeilenummer.setPreferredSize(new Dimension(230, 30));

        final JButton RezeptTeilenummerEingabeButton = new JButton("Teilenummer bestätigen");
        RezeptTeilenummerEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        RezeptTeilenummerEingabeButton.setPreferredSize(new Dimension(230, 30));
        
        textFieldTeilenummer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                RezeptTeilenummerEingabeButton.doClick();
            }
        });             

        RezeptTeilenummerEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RezeptTeilenummerEingabeButton.doClick();
            }
        });
                                    
        JLabel labelBeispielTeilenummerEingabe = new JLabel("z.B: MTT0501DC013");
        labelBeispielTeilenummerEingabe.setFont(new Font("Calibri", Font.ITALIC, 16));
        labelBeispielTeilenummerEingabe.setPreferredSize(new Dimension(230, 30)); 

        final JLabel labelGetTeilenummer = new JLabel("Ausgabe Teilenummer:");
        labelGetTeilenummer.setFont(new Font("Calibri", Font.BOLD, 16));
        labelGetTeilenummer.setPreferredSize(new Dimension(230, 30));    
        
        final JLabel RezeptTeilenummerAusgabeGetLabel = new JLabel("");

        RezeptTeilenummerEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                RezeptTeilenummerEingabe = textFieldTeilenummer.getText();
                falscheTeilenummer = false;
                    if (RezeptTeilenummerEingabe.length()==0) {
                        falscheTeilenummer = true;
                        labelGetTeilenummer.setForeground(Color.red);
                        labelGetTeilenummer.setFont(new Font("Calibri", Font.ITALIC, 16));
                        labelGetTeilenummer.setText("Erst Teilenummer eingeben!!!");
                    } 

                    if((RezeptTeilenummerEingabe.length()>0) && (falscheTeilenummer != true)) {
                        falscheTeilenummer = false;
                        labelGetTeilenummer.setForeground(Color.black);             
                        RezeptTeilenummerEingabe = textFieldTeilenummer.getText();                    
                        RezeptTeilenummerEingabe = textFieldTeilenummer.getText();
                        labelGetTeilenummer.setFont(new Font("Calibri", Font.BOLD, 16));
                        labelGetTeilenummer.setText("Ausgabe Teilenummer:");                                        
                        setRezeptTeilenummerEingabe(RezeptTeilenummerEingabe);
                        System.out.println(RezeptTeilenummerEingabe);
                        RezeptTeilenummerAusgabeGetLabel.setText("" + getRezeptTeilenummerEingabe());                        
                    }        
            }
        });

        RezeptTeilenummerAusgabeGetLabel.setText(RezeptTeilenummerEingabe);
        RezeptTeilenummerAusgabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RezeptTeilenummerAusgabeGetLabel.setPreferredSize(new Dimension(230, 30));
//------------------------------------------------------------------------------        
 
        JLabel labelZeichnungsnummerEingabe = new JLabel("Zeichnungsnummer:");
        labelZeichnungsnummerEingabe.setFont(new Font("Calibri", Font.BOLD, 16));
        labelZeichnungsnummerEingabe.setPreferredSize(new Dimension(230, 30));

        final JTextField textFieldZeichnungsnummer = new JTextField(RezeptZeichnungsnummerEingabe);
        textFieldZeichnungsnummer.setFont(new Font("Calibri", Font.BOLD, 16));
        textFieldZeichnungsnummer.setPreferredSize(new Dimension(230, 30));

        final JButton RezeptZeichnungsnummerEingabeButton = new JButton("Zeichnungsnummer bestätigen");
        RezeptZeichnungsnummerEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        RezeptZeichnungsnummerEingabeButton.setPreferredSize(new Dimension(230, 30));
        
        textFieldZeichnungsnummer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                RezeptZeichnungsnummerEingabeButton.doClick();
            }
        });             

        RezeptZeichnungsnummerEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RezeptZeichnungsnummerEingabeButton.doClick();
            }
        });
                                            
        JLabel labelBeispielZeichnungsnummerEingabe = new JLabel("z.B: MTT0501DC013");
        labelBeispielZeichnungsnummerEingabe.setFont(new Font("Calibri", Font.ITALIC, 16));
        labelBeispielZeichnungsnummerEingabe.setPreferredSize(new Dimension(230, 30)); 

        final JLabel labelGetZeichnungsnummer = new JLabel("Ausgabe Zeichnungsnummer:");
        labelGetZeichnungsnummer.setFont(new Font("Calibri", Font.BOLD, 16));
        labelGetZeichnungsnummer.setPreferredSize(new Dimension(230, 30));    
        
        final JLabel RezeptZeichnungsnummerAusgabeGetLabel = new JLabel("");

        RezeptZeichnungsnummerEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                RezeptZeichnungsnummerEingabe = textFieldZeichnungsnummer.getText();
                falscheZeichnungsnummer = false;
                    if (RezeptZeichnungsnummerEingabe.length()==0) {
                        falscheZeichnungsnummer = true;
                        labelGetZeichnungsnummer.setForeground(Color.red);
                        labelGetZeichnungsnummer.setFont(new Font("Calibri", Font.ITALIC, 16));
                        labelGetZeichnungsnummer.setText("Erst Zeichnungsnummer eingeben!!!");
                    } 

                    if((RezeptZeichnungsnummerEingabe.length()>0) && (falscheZeichnungsnummer != true)) {
                        falscheZeichnungsnummer = false;
                        labelGetZeichnungsnummer.setForeground(Color.black);             
                        RezeptZeichnungsnummerEingabe = textFieldZeichnungsnummer.getText();                    
                        RezeptZeichnungsnummerEingabe = textFieldZeichnungsnummer.getText();
                        labelGetZeichnungsnummer.setFont(new Font("Calibri", Font.BOLD, 16));
                        labelGetZeichnungsnummer.setText("Ausgabe Teilenummer:");                                        
                        setRezeptZeichnungsnummerEingabe(RezeptZeichnungsnummerEingabe);
                        System.out.println(RezeptZeichnungsnummerEingabe);
                        RezeptZeichnungsnummerAusgabeGetLabel.setText("" + getRezeptZeichnungsnummerEingabe());                        
                    } 
            }
        });

        RezeptZeichnungsnummerAusgabeGetLabel.setText(RezeptZeichnungsnummerEingabe);
        RezeptZeichnungsnummerAusgabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RezeptZeichnungsnummerAusgabeGetLabel.setPreferredSize(new Dimension(230, 30));
//------------------------------------------------------------------------------        
        
        JLabel labelErstellungEingabe = new JLabel("Erstellung:");
        labelErstellungEingabe.setFont(new Font("Calibri", Font.BOLD, 16));
        labelErstellungEingabe.setPreferredSize(new Dimension(230, 30));

        final JTextField textFieldErstellung = new JTextField(RezeptErstellungEingabe);
        textFieldErstellung.setFont(new Font("Calibri", Font.BOLD, 16));
        textFieldErstellung.setPreferredSize(new Dimension(230, 30));

        final JButton RezeptErstellungEingabeButton = new JButton("Erstellung bestätigen");
        RezeptErstellungEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        RezeptErstellungEingabeButton.setPreferredSize(new Dimension(230, 30));  
        
        textFieldErstellung.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                RezeptErstellungEingabeButton.doClick();
            }
        });             

        RezeptErstellungEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RezeptErstellungEingabeButton.doClick();
            }
        });
                                
        JLabel labelBeispielErstellungEingabe = new JLabel("z.B: Erstellt von JOS 01.01.2017");
        labelBeispielErstellungEingabe.setFont(new Font("Calibri", Font.ITALIC, 16));
        labelBeispielErstellungEingabe.setPreferredSize(new Dimension(230, 30)); 

        final JLabel labelGetErstellung = new JLabel("Ausgabe Erstellung:");
        labelGetErstellung.setFont(new Font("Calibri", Font.BOLD, 16));
        labelGetErstellung.setPreferredSize(new Dimension(230, 30));          
        
        final JLabel RezeptErstellungAusgabeGetLabel = new JLabel("");

        
        
        RezeptErstellungEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                RezeptErstellungEingabe = textFieldErstellung.getText();
                falscheErstellung = false;
                //ohneAe = false;
                
                //pruefenRezeptErstellungEingabe(ohneAe);
                
                if (RezeptErstellungEingabe.length()==0) {
                    falscheErstellung = true;
                    labelGetErstellung.setForeground(Color.red);
                    labelGetErstellung.setFont(new Font("Calibri", Font.ITALIC, 16));
                    labelGetErstellung.setText("Erst Erstellung eingeben!!!");
                } 

                ohneAe = false;
                if((RezeptErstellungEingabe.length()>0)){// && (falscheErstellung != true)){
                 int d = 0;   
                    for (int i = 0; i<=RezeptErstellungEingabe.length()-1; i++){

                        if (RezeptErstellungEingabe.substring(d, d + 1).equals("ä")) {
                            //System.out.print("ä");
                            RezeptErstellungAusgabeGetLabel.setForeground(Color.red);
                            RezeptErstellungAusgabeGetLabel.setFont(new Font("Calibri", Font.ITALIC, 16));
                            RezeptErstellungAusgabeGetLabel.setText("hat ä");
                            ohneAe = true;
                        } else if (RezeptErstellungEingabe.substring(d, d + 1).equals("ö")) {
                            System.out.print("ö");
                            RezeptErstellungAusgabeGetLabel.setForeground(Color.red);
                            labelGetErstellung.setFont(new Font("Calibri", Font.ITALIC, 16));                                
                            RezeptErstellungAusgabeGetLabel.setText("hat ö");
                            ohneAe = true;
                        } else if (RezeptErstellungEingabe.substring(d, d + 1).equals("ü")) {
                            //System.out.print("ü");
                            RezeptErstellungAusgabeGetLabel.setForeground(Color.red);
                            labelGetErstellung.setFont(new Font("Calibri", Font.ITALIC, 16));                                  
                            RezeptErstellungAusgabeGetLabel.setText("hat ü");
                            ohneAe = true;
                        }
                        else if(ohneAe != true && !RezeptErstellungEingabe.substring(d, d + 1).equals("ü") && !RezeptErstellungEingabe.substring(d, d + 1).equals("ö") && !RezeptErstellungEingabe.substring(d, d + 1).equals("ä")){                            
                        //ohneAe = false;  
                        labelGetErstellung.setForeground(Color.black);     
                        RezeptErstellungEingabe = textFieldErstellung.getText();                    
                        labelGetErstellung.setFont(new Font("Calibri", Font.BOLD, 16));
                        labelGetErstellung.setForeground(Color.black);
                        labelGetErstellung.setText("Ausgabe Erstellung:");                                        
                        setRezeptErstellungEingabe(RezeptErstellungEingabe);
                        System.out.println(RezeptErstellungEingabe);
                        RezeptErstellungAusgabeGetLabel.setForeground(Color.black);
                        RezeptErstellungAusgabeGetLabel.setFont(new Font("Calibri", Font.ITALIC, 16));
                        RezeptErstellungAusgabeGetLabel.setText("" + getRezeptErstellungEingabe());                        
                        }                          
                        d++;    
                        }
                    } 
            }
        }); 
        

//------------------------------------------------------------------------------        
               
        JLabel labelAnzahlWanddickenUnterschiedEingabe = new JLabel("Anzahl WD- Übergänge:");
        labelAnzahlWanddickenUnterschiedEingabe.setFont(new Font("Calibri", Font.BOLD, 16));
        labelAnzahlWanddickenUnterschiedEingabe.setPreferredSize(new Dimension(230, 30));

        final JTextField textFieldAnzahlWanddickenUnterschied = new JTextField(RezeptAnzahlWanddickenUnterschiedEingabe);
        textFieldAnzahlWanddickenUnterschied.setFont(new Font("Calibri", Font.BOLD, 16));
        textFieldAnzahlWanddickenUnterschied.setPreferredSize(new Dimension(230, 30));
        
        JLabel labelBeispielAnzahlWanddickenUnterschiedEingabe = new JLabel("z.B: 4");
        labelBeispielAnzahlWanddickenUnterschiedEingabe.setFont(new Font("Calibri", Font.ITALIC, 16));
        labelBeispielAnzahlWanddickenUnterschiedEingabe.setPreferredSize(new Dimension(230, 30)); 

        final JButton RezeptAnzahlWanddickenUnterschiedEingabeButton = new JButton("Anzahl WanddickenUnterschiede bestätigen");
        RezeptAnzahlWanddickenUnterschiedEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        RezeptAnzahlWanddickenUnterschiedEingabeButton.setPreferredSize(new Dimension(230, 30));

        textFieldAnzahlWanddickenUnterschied.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                RezeptAnzahlWanddickenUnterschiedEingabeButton.doClick();
            }
        });                

        RezeptAnzahlWanddickenUnterschiedEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RezeptAnzahlWanddickenUnterschiedEingabeButton.doClick();
            }
        });
                      
        final JLabel labelGetAnzahlWanddickenUnterschied = new JLabel("Ausgabe Anzahl Wanddicken- Unterschiede:");
        labelGetAnzahlWanddickenUnterschied.setFont(new Font("Calibri", Font.BOLD, 16));
        labelGetAnzahlWanddickenUnterschied.setPreferredSize(new Dimension(230, 30));    
        
        final JLabel RezeptAnzahlWanddickenUnterschiedAusgabeGetLabel = new JLabel("");

        RezeptAnzahlWanddickenUnterschiedEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                RezeptAnzahlWanddickenUnterschiedEingabe = textFieldAnzahlWanddickenUnterschied.getText();
                falscheAnzahlWanddickenUnterschied = false;
                    if (RezeptAnzahlWanddickenUnterschiedEingabe.length()==0) {
                        falscheAnzahlWanddickenUnterschied = true;
                        labelGetAnzahlWanddickenUnterschied.setForeground(Color.red);
                        labelGetAnzahlWanddickenUnterschied.setFont(new Font("Calibri", Font.ITALIC, 16));
                        labelGetAnzahlWanddickenUnterschied.setText("Erst AnzahlWanddickenUnterschied eingeben!!!");
                    } 

                    if((RezeptAnzahlWanddickenUnterschiedEingabe.length()>0) && (falscheAnzahlWanddickenUnterschied != true)) {
                        falscheAnzahlWanddickenUnterschied = false;
                        labelGetAnzahlWanddickenUnterschied.setForeground(Color.black);             
                        RezeptAnzahlWanddickenUnterschiedEingabe = textFieldAnzahlWanddickenUnterschied.getText();                    
                        RezeptAnzahlWanddickenUnterschiedEingabe = textFieldAnzahlWanddickenUnterschied.getText();
                        labelGetAnzahlWanddickenUnterschied.setFont(new Font("Calibri", Font.BOLD, 16));
                        labelGetAnzahlWanddickenUnterschied.setText("Ausgabe AnzahlWanddickenUnterschied:");                                        
                        setRezeptAnzahlWanddickenUnterschiedEingabe(RezeptAnzahlWanddickenUnterschiedEingabe);
                        System.out.println(RezeptAnzahlWanddickenUnterschiedEingabe);
                        RezeptAnzahlWanddickenUnterschiedAusgabeGetLabel.setText("" + getRezeptAnzahlWanddickenUnterschiedEingabe());                        
                    } 
            }
        });

        RezeptAnzahlWanddickenUnterschiedAusgabeGetLabel.setText(RezeptAnzahlWanddickenUnterschiedEingabe);
        RezeptAnzahlWanddickenUnterschiedAusgabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        RezeptAnzahlWanddickenUnterschiedAusgabeGetLabel.setPreferredSize(new Dimension(230, 30));
//------------------------------------------------------------------------------
//******************************************************************************        
        
        JLabel labelFixlaengeEingabe = new JLabel("Fixlänge:");
        labelFixlaengeEingabe.setFont(new Font("Calibri", Font.BOLD, 16));
        labelFixlaengeEingabe.setPreferredSize(new Dimension(230, 30));

        final JTextField textFieldFixlaenge = new JTextField(RezeptFixlaengeEingabe);
        textFieldFixlaenge.setFont(new Font("Calibri", Font.BOLD, 16));
        textFieldFixlaenge.setPreferredSize(new Dimension(230, 30));

        final JButton FixlaengeEingabeButton = new JButton("Fixlänge bestätigen");
        FixlaengeEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        FixlaengeEingabeButton.setPreferredSize(new Dimension(230, 30));  
        
        textFieldFixlaenge.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                FixlaengeEingabeButton.doClick();
            }
        });             

        FixlaengeEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                FixlaengeEingabeButton.doClick();
            }
        });
                                
        JLabel labelBeispielFixlaengeEingabe = new JLabel("z.B: Fixlänge 1490mm");
        labelBeispielFixlaengeEingabe.setFont(new Font("Calibri", Font.ITALIC, 16));
        labelBeispielFixlaengeEingabe.setPreferredSize(new Dimension(230, 30)); 

        final JLabel labelGetFixlaenge = new JLabel("Ausgabe Fixlänge:");
        labelGetFixlaenge.setFont(new Font("Calibri", Font.BOLD, 16));
        labelGetFixlaenge.setPreferredSize(new Dimension(230, 30));          
        
        final JLabel FixlaengeAusgabeGetLabel = new JLabel("");

        
        FixlaengeAusgabeGetLabel.setText(RezeptFixlaengeEingabe);
        FixlaengeAusgabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        FixlaengeAusgabeGetLabel.setPreferredSize(new Dimension(230, 30));        
        
        FixlaengeEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                RezeptFixlaengeEingabe = textFieldFixlaenge.getText();
                falscheErstellung = false;
                ohneAe = false;
                
                //pruefenRezeptErstellungEingabe(ohneAe);
                
                    if (RezeptFixlaengeEingabe.length()==0) {
                        falscheErstellung = true;
                        labelGetFixlaenge.setForeground(Color.red);
                        labelGetFixlaenge.setFont(new Font("Calibri", Font.ITALIC, 16));
                        labelGetFixlaenge.setText("Erst Fixlänge eingeben!!!");
                    } 

                    if((RezeptFixlaengeEingabe.length()>0) && (falscheErstellung != true) && (ohneAe != true)) {
                        falscheErstellung = false;
                       
                        
                        labelGetFixlaenge.setForeground(Color.black);             
                        RezeptFixlaengeEingabe = textFieldFixlaenge.getText();                    
                        RezeptFixlaengeEingabe = textFieldFixlaenge.getText();
                        labelGetFixlaenge.setFont(new Font("Calibri", Font.BOLD, 16));
                        labelGetFixlaenge.setText("Ausgabe Erstellung:");                                        
                        setFixlaengeEingabe(RezeptFixlaengeEingabe);
                        System.out.println(RezeptFixlaengeEingabe);
                        FixlaengeAusgabeGetLabel.setText("" + getFixlaengeEingabe());                        
                    } 
            }
        }); 

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++        
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 10);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 2;
        add(labelMaschinenName, c);
//------------------------------------------------------------------------------
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 6;
        add(labelGeschwindigkeitEingabe, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 6;
        add(textFieldGeschwindigkeit, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 6;
        add(labelBeispielGeschwindigkeitEingabe, c);        

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 6;
        add(RezeptGeschwindigkeitEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 6;
        add(labelGetGeschwindigkeit, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 6;
        c.gridy = 6;
        add(RezeptGeschwindigkeitAusgabeGetLabel, c);
//------------------------------------------------------------------------------        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 10;
        c.gridy = 6;
        add(RezeptGeschwindigkeitPasswortEingabeButton, c);
//------------------------------------------------------------------------------        
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 8;
        add(labelArtikelnummerEingabe, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 8;
        add(textFieldArtikelnummer, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 8;
        add(labelBeispielArtikelnummerEingabe, c);        

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 8;
        add(RezeptArtikelnummerEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 8;
        add(labelGetArtikelnummer, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 6;
        c.gridy = 8;
        add(RezeptArtikelnummerAusgabeGetLabel, c);
//------------------------------------------------------------------------------

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 10;
        add(labelArtikelnameEingabe, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 10;
        add(textFieldArtikelname, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 10;
        add(labelBeispielArtikelnameEingabe, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 10;
        add(RezeptArtikelnameEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 10;
        add(labelGetArtikelname, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 6;
        c.gridy = 10;
        add(RezeptArtikelnameAusgabeGetLabel, c);
//------------------------------------------------------------------------------
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 11;
        add(labelTeilenummerEingabe, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 11;
        add(textFieldTeilenummer, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 11;
        add(labelBeispielTeilenummerEingabe, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 11;
        add(RezeptTeilenummerEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 11;
        add(labelGetTeilenummer, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 6;
        c.gridy = 11;
        add(RezeptTeilenummerAusgabeGetLabel, c);
//------------------------------------------------------------------------------        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 12;
        add(labelZeichnungsnummerEingabe, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 12;
        add(textFieldZeichnungsnummer, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 12;
        add(labelBeispielZeichnungsnummerEingabe, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 12;
        add(RezeptZeichnungsnummerEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 12;
        add(labelGetZeichnungsnummer, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 6;
        c.gridy = 12;
        add(RezeptZeichnungsnummerAusgabeGetLabel, c);        
//------------------------------------------------------------------------------        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 13;
        add(labelErstellungEingabe, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 13;
        add(textFieldErstellung, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 13;
        add(labelBeispielErstellungEingabe, c);        

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 13;
        add(RezeptErstellungEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 13;
        add(labelGetErstellung, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 6;
        c.gridy = 13;
        add(RezeptErstellungAusgabeGetLabel, c);  
//------------------------------------------------------------------------------        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 14;
        add(labelAnzahlWanddickenUnterschiedEingabe, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 14;
        add(textFieldAnzahlWanddickenUnterschied, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 14;
        add(labelBeispielAnzahlWanddickenUnterschiedEingabe, c);        

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 14;
        add(RezeptAnzahlWanddickenUnterschiedEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 14;
        add(labelGetAnzahlWanddickenUnterschied, c);        
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 6;
        c.gridy = 14;
        add(RezeptAnzahlWanddickenUnterschiedAusgabeGetLabel, c);            
        
//------------------------------------------------------------------------------        
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 16;
        add(labelFixlaengeEingabe, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 16;
        add(textFieldFixlaenge, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 16;
        add(labelBeispielFixlaengeEingabe, c);        

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 16;
        add(FixlaengeEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 16;
        add(labelGetFixlaenge, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 6;
        c.gridy = 16;
        add(FixlaengeAusgabeGetLabel, c);
//------------------------------------------------------------------------------        
//------------------------------------------------------------------------------
        final JLabel labelGetRezeptErstellenFehler = new JLabel("");
        labelGetAnzahlWanddickenUnterschied.setFont(new Font("Calibri", Font.BOLD, 16));
        labelGetAnzahlWanddickenUnterschied.setPreferredSize(new Dimension(230, 30));  
        
        
        final JButton RezeptErstellenButton = new JButton("Rezept erstellen");
        RezeptErstellenButton.setFont(new Font("Calibri", Font.BOLD, 16));
        RezeptErstellenButton.setPreferredSize(new Dimension(230, 30));        

        RezeptErstellenButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                RezeptErstellenButton.doClick();
            }
        });        

        
        
        RezeptErstellenButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                
                    if (RezeptArtikelnummerEingabe.length()==0) {
                        falscheRezeptErstellenFehler = true;
                        labelGetRezeptErstellenFehler.setForeground(Color.red);
                        labelGetRezeptErstellenFehler.setFont(new Font("Calibri", Font.ITALIC, 12));
                        labelGetRezeptErstellenFehler.setText("Fehlende oder nicht bestätigte" + "Artikelnummer- Eingabe!");
                    }  
                    else{
                        falscheRezeptErstellenFehler = false;
                        labelGetRezeptErstellenFehler.setForeground(Color.green.darker());
                        labelGetRezeptErstellenFehler.setFont(new Font("Calibri", Font.ITALIC, 16));
                        labelGetRezeptErstellenFehler.setText("Rezept wurde abgespeichert");
//                System.out.println("\n"+"RattundeArtikelnummerEingabe: "+RattundeArtikelnummerEingabe+"\n"
//                        +"RattundeArtikelnameEingabe: "+RattundeArtikelnameEingabe+"\n"
//                        +"RattundeTeilenummerEingabe: "+RattundeTeilenummerEingabe+"\n"
//                        +"RattundeZeichnungsnummerEingabe: "+RattundeZeichnungsnummerEingabe+"\n"
//                        +"RattundeErstellungEingabe: "+RattundeErstellungEingabe+"\n"
//                        +"RattundeAnzahlWanddickenUnterschiedEingabe: "+RattundeAnzahlWanddickenUnterschiedEingabe+"\n");
                        //System.out.println("Hello Kitty");
                rezeptErstellen();
                    }
            }
        });        

          
        
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 10;
        c.gridy = 51;
        add(labelGetRezeptErstellenFehler, c);        
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 10;
        c.gridy = 50;
        add(RezeptErstellenButton, c);
        
        
        

        
        
        
    //}
//------------------------------------------------------------------------------
//******************************************************************************        
        
        JLabel labelZwischenstueckEingabe = new JLabel("Zwischenstück:");
        labelZwischenstueckEingabe.setFont(new Font("Calibri", Font.BOLD, 16));
        labelZwischenstueckEingabe.setPreferredSize(new Dimension(230, 30));

        final JTextField textFieldZwischenstueck = new JTextField(RezeptZwischenstueckEingabe);
        textFieldZwischenstueck.setFont(new Font("Calibri", Font.BOLD, 16));
        textFieldZwischenstueck.setPreferredSize(new Dimension(230, 30));

        final JButton ZwischenstueckEingabeButton = new JButton("Zwischenstück bestätigen");
        ZwischenstueckEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        ZwischenstueckEingabeButton.setPreferredSize(new Dimension(230, 30));  
        
        textFieldZwischenstueck.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ZwischenstueckEingabeButton.doClick();
            }
        });             

        ZwischenstueckEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ZwischenstueckEingabeButton.doClick();
            }
        });
                                
        JLabel labelBeispielZwischenstueckEingabe = new JLabel("z.B: Zwischenstück 50mm");
        labelBeispielZwischenstueckEingabe.setFont(new Font("Calibri", Font.ITALIC, 16));
        labelBeispielZwischenstueckEingabe.setPreferredSize(new Dimension(230, 30)); 

        final JLabel labelGetZwischenstueck = new JLabel("Ausgabe Zwischenstück:");
        labelGetZwischenstueck.setFont(new Font("Calibri", Font.BOLD, 16));
        labelGetZwischenstueck.setPreferredSize(new Dimension(230, 30));          
        
        final JLabel ZwischenstueckAusgabeGetLabel = new JLabel("");

        
        ZwischenstueckAusgabeGetLabel.setText(RezeptZwischenstueckEingabe);
        ZwischenstueckAusgabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        ZwischenstueckAusgabeGetLabel.setPreferredSize(new Dimension(230, 30));        
        
        ZwischenstueckEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                RezeptZwischenstueckEingabe = textFieldZwischenstueck.getText();
                falscheErstellung = false;
                ohneAe = false;
                
                //pruefenRezeptErstellungEingabe(ohneAe);
                
//                    if (RezeptFixlaengeEingabe.length()==0) {
//                        falscheErstellung = true;
//                        labelGetZwischenstueck.setForeground(Color.red);
//                        labelGetZwischenstueck.setFont(new Font("Calibri", Font.ITALIC, 16));
//                        labelGetZwischenstueck.setText("Erst Fixlänge eingeben!!!");
//                    } 

//                    if((RezeptFixlaengeEingabe.length()>0) && (falscheErstellung != true) && (ohneAe != true)) {
                        falscheErstellung = false;
                       
                        
                        labelGetZwischenstueck.setForeground(Color.black);             
                        RezeptZwischenstueckEingabe = textFieldZwischenstueck.getText();                    
                        RezeptZwischenstueckEingabe = textFieldZwischenstueck.getText();
                        labelGetZwischenstueck.setFont(new Font("Calibri", Font.BOLD, 16));
                        labelGetZwischenstueck.setText("Ausgabe Erstellung:");                                        
                        //setFixlaengeEingabe(RezeptZwischenstueckEingabe);
                        System.out.println(RezeptZwischenstueckEingabe);
                        //ZwischenstueckAusgabeGetLabel.setText("" + getZwischenstueckEingabe());     
                        ZwischenstueckAusgabeGetLabel.setText("" + RezeptZwischenstueckEingabe);
//                    } 
            }
        }); 
        
//------------------------------------------------------------------------------        
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 18;
        add(labelZwischenstueckEingabe, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 18;
        add(textFieldZwischenstueck, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 18;
        add(labelBeispielZwischenstueckEingabe, c);        

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 18;
        add(ZwischenstueckEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 18;
        add(labelGetZwischenstueck, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 6;
        c.gridy = 18;
        add(ZwischenstueckAusgabeGetLabel, c);        
//------------------------------------------------------------------------------        
//******************************************************************************        
        
        JLabel labelMehrfachlaengeEingabe = new JLabel("Mehrfachlänge:");
        labelMehrfachlaengeEingabe.setFont(new Font("Calibri", Font.BOLD, 16));
        labelMehrfachlaengeEingabe.setPreferredSize(new Dimension(230, 30));

        final JTextField textFieldMehrfachlaenge = new JTextField(RezeptMehrfachlaengeEingabe);
        textFieldMehrfachlaenge.setFont(new Font("Calibri", Font.BOLD, 16));
        textFieldMehrfachlaenge.setPreferredSize(new Dimension(230, 30));

        final JButton MehrfachlaengeEingabeButton = new JButton("Zwischenstück bestätigen");
        MehrfachlaengeEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        MehrfachlaengeEingabeButton.setPreferredSize(new Dimension(230, 30));  
        
        textFieldMehrfachlaenge.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MehrfachlaengeEingabeButton.doClick();
            }
        });             

        MehrfachlaengeEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                MehrfachlaengeEingabeButton.doClick();
            }
        });
                                
        JLabel labelBeispielMehrfachlaengeEingabe = new JLabel("z.B: Mehrfachlänge 9200m");
        labelBeispielMehrfachlaengeEingabe.setFont(new Font("Calibri", Font.ITALIC, 16));
        labelBeispielMehrfachlaengeEingabe.setPreferredSize(new Dimension(230, 30)); 

        final JLabel labelGetMehrfachlaenge = new JLabel("Ausgabe Mehrfachlänge:");
        labelGetMehrfachlaenge.setFont(new Font("Calibri", Font.BOLD, 16));
        labelGetMehrfachlaenge.setPreferredSize(new Dimension(230, 30));          
        
        final JLabel MehrfachlaengeAusgabeGetLabel = new JLabel("");

        
        MehrfachlaengeAusgabeGetLabel.setText(RezeptZwischenstueckEingabe);
        MehrfachlaengeAusgabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        MehrfachlaengeAusgabeGetLabel.setPreferredSize(new Dimension(230, 30));        
        
        MehrfachlaengeEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                RezeptMehrfachlaengeEingabe = textFieldMehrfachlaenge.getText();
                falscheErstellung = false;
                ohneAe = false;
                
                //pruefenRezeptErstellungEingabe(ohneAe);
                
//                    if (RezeptFixlaengeEingabe.length()==0) {
//                        falscheErstellung = true;
//                        labelGetZwischenstueck.setForeground(Color.red);
//                        labelGetZwischenstueck.setFont(new Font("Calibri", Font.ITALIC, 16));
//                        labelGetZwischenstueck.setText("Erst Fixlänge eingeben!!!");
//                    } 

//                    if((RezeptFixlaengeEingabe.length()>0) && (falscheErstellung != true) && (ohneAe != true)) {
                        falscheErstellung = false;
                       
                        
                        labelGetMehrfachlaenge.setForeground(Color.black);             
                        RezeptMehrfachlaengeEingabe = textFieldMehrfachlaenge.getText();                    
                        RezeptMehrfachlaengeEingabe = textFieldMehrfachlaenge.getText();
                        labelGetMehrfachlaenge.setFont(new Font("Calibri", Font.BOLD, 16));
                        labelGetMehrfachlaenge.setText("Ausgabe Mehrfachlaenge:");                                        
                        //setFixlaengeEingabe(RezeptZwischenstueckEingabe);
                        System.out.println(RezeptMehrfachlaengeEingabe);
                        //MehrfachlaengeAusgabeGetLabel.setText("" + getMehrfachlaengeEingabe());     
                        MehrfachlaengeAusgabeGetLabel.setText("" + RezeptMehrfachlaengeEingabe);
//                    } 
            }
        }); 
        
//------------------------------------------------------------------------------        
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 20;
        add(labelMehrfachlaengeEingabe, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 20;
        add(textFieldMehrfachlaenge, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 20;
        add(labelBeispielMehrfachlaengeEingabe, c);        

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 20;
        add(MehrfachlaengeEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 20;
        add(labelGetMehrfachlaenge, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 6;
        c.gridy = 20;
        add(MehrfachlaengeAusgabeGetLabel, c);                
//******************************************************************************        
        
        JLabel labelAnzahlFixlaengeEingabe = new JLabel("Anzahl Fixlänge:");
        labelAnzahlFixlaengeEingabe.setFont(new Font("Calibri", Font.BOLD, 16));
        labelAnzahlFixlaengeEingabe.setPreferredSize(new Dimension(230, 30));

        final JTextField textFieldAnzahlFixlaenge = new JTextField(RezeptAnzahlFixlaengeEingabe);
        textFieldAnzahlFixlaenge.setFont(new Font("Calibri", Font.BOLD, 16));
        textFieldAnzahlFixlaenge.setPreferredSize(new Dimension(230, 30));

        final JButton AnzahlFixlaengeEingabeButton = new JButton("Anzahl bestätigen");
        AnzahlFixlaengeEingabeButton.setFont(new Font("Calibri", Font.BOLD, 16));
        AnzahlFixlaengeEingabeButton.setPreferredSize(new Dimension(230, 30));  
        
        textFieldAnzahlFixlaenge.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AnzahlFixlaengeEingabeButton.doClick();
            }
        });             

        AnzahlFixlaengeEingabeButton.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                AnzahlFixlaengeEingabeButton.doClick();
            }
        });
                                
        JLabel labelBeispielAnzahlFixlaengeEingabe = new JLabel("z.B: 4");
        labelBeispielAnzahlFixlaengeEingabe.setFont(new Font("Calibri", Font.ITALIC, 16));
        labelBeispielAnzahlFixlaengeEingabe.setPreferredSize(new Dimension(230, 30)); 

        final JLabel labelGetAnzahlFixlaenge = new JLabel("Ausgabe Anzahl:");
        labelGetAnzahlFixlaenge.setFont(new Font("Calibri", Font.BOLD, 16));
        labelGetAnzahlFixlaenge.setPreferredSize(new Dimension(230, 30));          
        
        final JLabel AnzahlFixlaengeAusgabeGetLabel = new JLabel("");

        
        AnzahlFixlaengeAusgabeGetLabel.setText(RezeptAnzahlFixlaengeEingabe);
        AnzahlFixlaengeAusgabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        AnzahlFixlaengeAusgabeGetLabel.setPreferredSize(new Dimension(230, 30));        
        
        AnzahlFixlaengeEingabeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                RezeptMehrfachlaengeEingabe = textFieldAnzahlFixlaenge.getText();
                falscheErstellung = false;
                ohneAe = false;
                
                //pruefenRezeptErstellungEingabe(ohneAe);
                
//                    if (RezeptFixlaengeEingabe.length()==0) {
//                        falscheErstellung = true;
//                        labelGetZwischenstueck.setForeground(Color.red);
//                        labelGetZwischenstueck.setFont(new Font("Calibri", Font.ITALIC, 16));
//                        labelGetZwischenstueck.setText("Erst Fixlänge eingeben!!!");
//                    } 

//                    if((RezeptFixlaengeEingabe.length()>0) && (falscheErstellung != true) && (ohneAe != true)) {
                        falscheErstellung = false;
                       
                        
                        labelGetAnzahlFixlaenge.setForeground(Color.black);             
                        RezeptMehrfachlaengeEingabe = textFieldAnzahlFixlaenge.getText();                    
                        RezeptMehrfachlaengeEingabe = textFieldAnzahlFixlaenge.getText();
                        labelGetAnzahlFixlaenge.setFont(new Font("Calibri", Font.BOLD, 16));
                        labelGetAnzahlFixlaenge.setText("Ausgabe Mehrfachlaenge:");                                        
                        //setFixlaengeEingabe(RezeptZwischenstueckEingabe);
                        System.out.println(RezeptMehrfachlaengeEingabe);
                        //MehrfachlaengeAusgabeGetLabel.setText("" + getMehrfachlaengeEingabe());     
                        AnzahlFixlaengeAusgabeGetLabel.setText("" + RezeptMehrfachlaengeEingabe);
//                    } 
            }
        }); 

//------------------------------------------------------------------------------              
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 23;
        add(labelAnzahlFixlaengeEingabe, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 23;
        add(textFieldAnzahlFixlaenge, c);
        
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 23;
        add(labelBeispielAnzahlFixlaengeEingabe, c);        

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 23;
        add(AnzahlFixlaengeEingabeButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 5;
        c.gridy = 23;
        add(labelGetAnzahlFixlaenge, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 6;
        c.gridy = 23;
        add(AnzahlFixlaengeAusgabeGetLabel, c);                        
        
    }
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++     
    
////////////////
//////////////        public boolean pruefenRezeptErstellungEingabe(boolean ohneAe){
//////////////            
//////////////        ohneAe = false;
//////////////        
//////////////        int d = 0;
//////////////        while (d < RezeptErstellungEingabe.length()) {
//////////////            if (RezeptErstellungEingabe.substring(d, d + 1).equals("ä")) {
//////////////                System.out.print("hat ä");
//////////////                RezeptErstellungAusgabeGetLabel.setText("hat ä");
//////////////                ohneAe = true;
//////////////            } else if (RezeptErstellungEingabe.substring(d, d + 1).equals("ö")) {
//////////////                System.out.print("hat ö");
//////////////                ohneAe = true;
//////////////            } else if (RezeptErstellungEingabe.substring(d, d + 1).equals("ü")) {
//////////////                System.out.print("hat ü");
//////////////                ohneAe = true;
//////////////            }
//////////////        }    
//////////////        d++;
//////////////        
//////////////        return ohneAe;
//////////////        }    
    
    
    
public static void rezeptErstellen(){
    DatumUhrzeit datumUhrzeit;
        
    DatumUhrzeit.initDatumUhrzeit();    
        
    BufferedReader reader;    

    FileWriter writer;

        File quellDatei;
        File zielDatei;

        try {
            //Lesen aus der quelldatei
            //WICHTIG in Java müssen Pfad angeben immer mit / gemacht werden, statt mit \
            //Also statt C:\Temp einfach C:/Temp schreiben            
            quellDatei = new File("D:/Testkopiedatensätze/Rezepte/RezeptVorlage.txt");
            reader = new BufferedReader(new FileReader(quellDatei));

            String zeileAusQuellDatei;

            //Solange zeile für zeile die Datei auslesen bis die Datei zu ende ist
            zielDatei = new File("D:/Testkopiedatensätze/"  + Rezept.getRezeptArtikelnummerEingabe() + " - " + DatumUhrzeit.getDatum() + " Datum - " + DatumUhrzeit.getUhrzeit() + " Uhrzeit" + ".txt");
            //System.out.print(quellText);
            writer = new FileWriter(zielDatei);

//            while((zeileAusQuellDatei = reader.readLine())!= null){
//                //System.out.println(zeileAusQuellDatei);
//                System.out.println(zeileAusQuellDatei);
//                writer.write(zeileAusQuellDatei);
//                writer.write(System.getProperty("line.separator"));
//
//                
//            }
            
            
            //writer.write("Danke mir gehts gut und Hello Kitty!");
            writer.write(System.getProperty("line.separator"));
            writer.write("<rezept>");
            writer.write(System.getProperty("line.separator"));
            writer.write(System.getProperty("line.separator"));
            writer.write("    <artikelnummer>" + Rezept.getRezeptArtikelnummerEingabe() + "</artikelnummer>");
            writer.write(System.getProperty("line.separator"));
            writer.write("    <artikelname>" + Rezept.getRezeptArtikelnameEingabe() + "</artikelname>");
            writer.write(System.getProperty("line.separator"));
            writer.write("    <teilenummer>" + Rezept.getRezeptTeilenummerEingabe() + "</teilenummer>");
            writer.write(System.getProperty("line.separator"));
            writer.write("    <zeichnungsnummer>" + Rezept.getRezeptZeichnungsnummerEingabe() + "</zeichnungsnummer>");
            writer.write(System.getProperty("line.separator"));
            writer.write("    <aenderungsstand-zeichnung>" + " " + "</aenderungsstand-zeichnung>");
            writer.write(System.getProperty("line.separator"));
            writer.write("    <aenderungsstand-rezept>" + " " + "</aenderungsstand-rezept>");
            writer.write(System.getProperty("line.separator"));
            writer.write("    <beschreibung>" + " " + "</beschreibung>");
            
            writer.write(System.getProperty("line.separator"));
            writer.write(System.getProperty("line.separator"));            
            writer.write("    <kommentar>");
            writer.write(System.getProperty("line.separator"));
           // writer.write(System.getProperty("line.separator"));            
           
            writer.write("\\t\\t"  + RezeptErstellungEingabe); //Rezept.getRezeptErstellungEingabe() + 
            writer.write("                                        Hier könnte Ihre Werbung stehen");
            
            //writer.write(System.getProperty("line.separator"));
            writer.write(System.getProperty("line.separator"));            
            writer.write("    <kommentar>");            
            writer.write(System.getProperty("line.separator"));
            writer.write(System.getProperty("line.separator")); 
            
          /*      
    <schrottlaenge-anfang>50</schrottlaenge-anfang>
    <schrottlaenge-ende>70</schrottlaenge-ende>    
    <mindest-gutanteil>80</mindest-gutanteil>
            
        <mindest-gutanteil>90</mindest-gutanteil>
            //Schreiben in eine Datei
*/            
            
            writer.write("    <mehrfachlaenge>");
            writer.write(System.getProperty("line.separator"));            
            writer.write("    <fixlaenge>" + " " + "</fixlaenge>");
            writer.write(System.getProperty("line.separator"));              
            writer.write("    <ausgleichsstueck>" + " " + "</ausgleichsstueck>");
            writer.write(System.getProperty("line.separator"));             
            writer.write("    <mehrfachlaenge>" + " " + "</mehrfachlaenge>");
            writer.write(System.getProperty("line.separator"));
            writer.write("    <anzahl-fixlaengen-pro-mehrfachlaenge>" + " " + "</anzahl-fixlaengen-pro-mehrfachlaenge>");
            writer.write(System.getProperty("line.separator"));
            writer.write("    <neg-tol-mehrfachlaenge>" + " " + "</neg-tol-mehrfachlaenge>");
            writer.write(System.getProperty("line.separator"));
            writer.write("    <pos-tol-mehrfachlaenge>" + " " + "</pos-tol-mehrfachlaenge>");            
            writer.write(System.getProperty("line.separator"));
            writer.write("    <mindestanzahl-gutprofile>" + " " + "</mindestanzahl-gutprofile>");  
            writer.write(System.getProperty("line.separator"));
            writer.write("    </mehrfachlaenge>");
            writer.write(System.getProperty("line.separator"));
            writer.write(System.getProperty("line.separator"));
            writer.write(System.getProperty("line.separator"));
            
            writer.write("    <standardwerte>");
            writer.write(System.getProperty("line.separator"));            
            writer.write("    <obere-toleranz>" + " " + "</obere-toleranz>");
            writer.write(System.getProperty("line.separator"));              
            writer.write("    <untere-toleranz>" + " " + "</untere-toleranz>");
            writer.write(System.getProperty("line.separator"));             
            writer.write("    <mindest-gutanteil>" + " " + "</mindest-gutanteil>");
            writer.write(System.getProperty("line.separator"));
            writer.write("    </standardwerte>");
            writer.write(System.getProperty("line.separator"));       
            writer.write(System.getProperty("line.separator"));
            

                
                
                
                
                
            
    // Text wird in den Stream geschrieben

       // Platformunabhängiger Zeilenumbruch wird in den Stream geschrieben
 /////////      writer.write(System.getProperty("line.separator"));

       // Text wird in den Stream geschrieben       
//     writer.write("Danke mir gehts gut und Hello Kitty!");
                   // Schreibt den Stream in die Datei
       // Sollte immer am Ende ausgeführt werden, sodass der Stream 
       // leer ist und alles in der Datei steht.
       writer.flush();
       
       // Schließt den Stream
       writer.close();

        } catch (FileNotFoundException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

    }        
}


//******************************************************************************
class ZiehenMaschine extends JPanel {

    String maschinenName;
    String verfahrenName;

    String inderEingabe = "";

    final private CardLayout cardManager;
    final private JPanel cardPanel;

    public ZiehenMaschine(JPanel cardPanel, CardLayout cardManager, String maschinenName, String verfahrenName) throws IOException {
        this.cardManager = cardManager;
        this.cardPanel = cardPanel;
        this.maschinenName = maschinenName;
        this.verfahrenName = verfahrenName;
        initZiehenMaschine();
    }

    public void initZiehenMaschine() {

        JLabel labelMaschinenName = new JLabel(maschinenName);
        labelMaschinenName.setFont(new Font("Calibri", Font.BOLD, 24));
        labelMaschinenName.setPreferredSize(new Dimension(230, 30));

        JLabel labelRohrlaengeEingabe = new JLabel(verfahrenName);
        labelRohrlaengeEingabe.setFont(new Font("Calibri", Font.BOLD, 16));
        labelRohrlaengeEingabe.setPreferredSize(new Dimension(230, 30));

        final JTextField textFieldRohrlaenge = new JTextField(inderEingabe);
        textFieldRohrlaenge.setFont(new Font("Calibri", Font.BOLD, 16));
        textFieldRohrlaenge.setPreferredSize(new Dimension(230, 30));

        JButton buttonRohrlaenge = new JButton("inderEingabeButton");
        buttonRohrlaenge.setFont(new Font("Calibri", Font.BOLD, 16));
        buttonRohrlaenge.setPreferredSize(new Dimension(230, 30));

        JLabel labelGetRohrlaenge = new JLabel("Ausgabe Zeit:");
        labelGetRohrlaenge.setFont(new Font("Calibri", Font.BOLD, 16));
        labelGetRohrlaenge.setPreferredSize(new Dimension(230, 30));

        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 10);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 7;
        add(labelMaschinenName, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 8;
        add(labelRohrlaengeEingabe, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 8;
        add(textFieldRohrlaenge, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 8;
        add(buttonRohrlaenge, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 9;
        add(labelGetRohrlaenge, c);

        final JLabel inderAusgabeGetLabel = new JLabel("");

        buttonRohrlaenge.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {

                String inderEingabe = textFieldRohrlaenge.getText();
                System.out.println(inderEingabe);
                inderAusgabeGetLabel.setText("" + inderEingabe);
            }
        });

        inderAusgabeGetLabel.setText(inderEingabe);
        inderAusgabeGetLabel.setFont(new Font("Calibri", Font.BOLD, 16));
        inderAusgabeGetLabel.setPreferredSize(new Dimension(230, 30));

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 9;
        add(inderAusgabeGetLabel, c);

    }

}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
class Richten extends JPanel {

    final private CardLayout cardManager;
    final private JPanel cardPanel;

    public Richten(JPanel cardPanel, CardLayout cardManager) throws IOException {
        this.cardManager = cardManager;
        this.cardPanel = cardPanel;
        initRichten();
    }

    public void initRichten() throws IOException {

        final JButton semaButton = new JButton("SEMA");
        semaButton.setFont(new Font("Calibri", Font.BOLD, 16));
        semaButton.setPreferredSize(new Dimension(230, 30));

        JButton kieserlingButton = new JButton("Kieserling");
        kieserlingButton.setFont(new Font("Calibri", Font.BOLD, 16));
        kieserlingButton.setPreferredSize(new Dimension(230, 30));

        final JPanel richtenPanel = new JPanel();
        richtenPanel.add(semaButton);
        richtenPanel.add(kieserlingButton);
        add(richtenPanel);

        semaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                cardManager.show(cardPanel, "SEMA");
            }
        });

        kieserlingButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                cardManager.show(cardPanel, "Kieserling");
            }
        });

    }
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//------------------------------------------------------------------------------
class Gluehen extends JPanel {

    final private CardLayout cardManager;
    final private JPanel cardPanel;

    public Gluehen(JPanel cardPanel, CardLayout cardManager) throws IOException {
        this.cardManager = cardManager;
        this.cardPanel = cardPanel;
        initGluehen();
    }

    public void initGluehen() throws IOException {

        final JButton g1Button = new JButton("Glühofen 1");
        g1Button.setFont(new Font("Calibri", Font.BOLD, 16));
        g1Button.setPreferredSize(new Dimension(230, 30));

        JButton g2Button = new JButton("Glühofen 2");
        g2Button.setFont(new Font("Calibri", Font.BOLD, 16));
        g2Button.setPreferredSize(new Dimension(230, 30));

        final JPanel gluehenPanel = new JPanel();
        gluehenPanel.add(g1Button);
        gluehenPanel.add(g2Button);
        add(gluehenPanel);

        g1Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                cardManager.show(cardPanel, "Glühofen 1");
            }
        });

        g2Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                cardManager.show(cardPanel, "Glühofen 2");
            }
        });

    }
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

class GluehenMaschine extends JPanel {

    String maschinenName;
    String verfahrenName;

    final private CardLayout cardManager;
    final private JPanel cardPanel;

    public GluehenMaschine(JPanel cardPanel, CardLayout cardManager, String maschinenName, String verfahrenName) throws IOException {
        this.cardManager = cardManager;
        this.cardPanel = cardPanel;
        this.maschinenName = maschinenName;
        this.verfahrenName = verfahrenName;
        initGluehenMaschine();
    }

    String stringRohrlaenge;

    public void initGluehenMaschine() {
        JLabel labelMaschinenName = new JLabel(maschinenName);
        labelMaschinenName.setFont(new Font("Calibri", Font.BOLD, 24));
        labelMaschinenName.setPreferredSize(new Dimension(230, 30));

        JLabel labelRohrlaengeEingabe = new JLabel(verfahrenName);
        labelRohrlaengeEingabe.setFont(new Font("Calibri", Font.BOLD, 16));
        labelRohrlaengeEingabe.setPreferredSize(new Dimension(230, 30));

        final JTextField textFieldRohrlaenge = new JTextField(stringRohrlaenge);
        textFieldRohrlaenge.setFont(new Font("Calibri", Font.BOLD, 16));
        textFieldRohrlaenge.setPreferredSize(new Dimension(230, 30));

        JButton buttonRohrlaenge = new JButton("OK");
        buttonRohrlaenge.setFont(new Font("Calibri", Font.BOLD, 16));
        buttonRohrlaenge.setPreferredSize(new Dimension(230, 30));

        JLabel labelGetRohrlaenge = new JLabel(stringRohrlaenge);
        labelGetRohrlaenge.setFont(new Font("Calibri", Font.BOLD, 16));
        labelGetRohrlaenge.setPreferredSize(new Dimension(230, 30));

        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 10);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 2;
        add(labelMaschinenName, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 11;
        add(labelRohrlaengeEingabe, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 11;
        add(textFieldRohrlaenge, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 11;
        add(buttonRohrlaenge, c);

        buttonRohrlaenge.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {

                stringRohrlaenge = textFieldRohrlaenge.getText();
                System.out.println(stringRohrlaenge);
                textFieldRohrlaenge.setText("" + stringRohrlaenge);
            }
        });

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 11;
        add(labelGetRohrlaenge, c);

    }
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


class Anleitung extends JPanel {

    final private CardLayout cardManager;
    final private JPanel cardPanel;

    public Anleitung(JPanel cardPanel, CardLayout cardManager) throws IOException {
        this.cardManager = cardManager;
        this.cardPanel = cardPanel;
        initAnleitung();
    }

    public void initAnleitung() throws IOException {

        
        
        
        
        
        
        final JButton anleitungButton = new JButton("Anleitung in einem neuen Fenster als PDF anzeigen:");
        anleitungButton.setFont(new Font("Calibri", Font.BOLD, 28));
        anleitungButton.setPreferredSize(new Dimension(680, 60));//230,30

        final JLabel labelPDF = new JLabel("PDFLABEL");
        //final JLabel labelPDF = new JLabel(new ImageIcon("D:/bnbnbnb2.PNG"));
//final JLabel labelPDF = new JLabel(new ImageIcon());        
        labelPDF.setPreferredSize(new Dimension(150, 50));        
        
        final JPanel anleitungPanel = new JPanel();
        //final JPanel pdfPanel = new JPanel();
        
        
        anleitungPanel.add(anleitungButton);
        anleitungPanel.add(labelPDF);
        add(anleitungPanel);
        
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 10);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 2;
        add(anleitungButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 11;
        add(labelPDF, c);
        
        
        anleitungButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                try {
                    //cardManager.show(cardPanel, "Anleitung");
//                        if(e.getSource() == jButtonInfo)
//                        {
                    Desktop.getDesktop().open( new File( "X:\\ARB\\TECHNOLOGIE\\04-PROZESSTECHNIK\\MTT-Entwicklung\\CH70220\\Produktion\\Schulung Anarbeitung\\SCAN fertige AAWA\\Allgemein\\WI-ARB-PST-P-187 Allgemein VCI Schichtl..pdf"));
                   labelPDF.setBackground(Color.yellow);// = new ImageIcon("D:/bnbnbnb2.PNG");
                    labelPDF.setForeground(Color.GREEN);
                    //labelPDF.setForeground(Color.
                   //);
//fileBrowser.setBarsVisible(false);
//fileBrowser.setStatusBarVisible(false);
//fileRenderPanel.add(fileBrowser, BorderLayout.CENTER);                    
                    //try {
                    //Desktop.getDesktop().open(new File("Anleitung 100Prozent Rezept.pdf"));
                    //} catch (IOException e1) {
                    
                    //e1.printStackTrace();
                    //}
                    //}
                } catch (IOException ex) {
                    Logger.getLogger(Anleitung.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    
    
    
    
    
    
    
    }
}
    
class DatumUhrzeit {
    public static String datum = "";
    public static String uhrzeit = "";
    
    public DatumUhrzeit(String datum, String uhrzeit) {
        this.datum = datum;
        this.uhrzeit = uhrzeit;
        initDatumUhrzeit();
    }
    
    public static void setDatum(String datum) {
        DatumUhrzeit.datum = datum;
        //return this;
    }
    
    public static String getDatum() {
        return datum;
    }    
    
    public static void ausgebenDatum() {
        System.out.println("Datumausgeben: " + datum);
        System.out.println("Datumausgeben: HEEEEELLLLOOOO KITTY");
    }        

    public static void setUhrzeit(String uhrzeit) {
        DatumUhrzeit.uhrzeit = uhrzeit;
        //return this;
    }
    
    public static String getUhrzeit() {
        return uhrzeit;
    }    
    
    public static void ausgebenUhrzeit() {
        System.out.println("Uhrzeitausgeben: " + uhrzeit);
    }        
    
    public static void initDatumUhrzeit(){
 
        final java.util.Timer clockTimer = new java.util.Timer(true);
        final java.text.SimpleDateFormat zeitFormat = new java.text.SimpleDateFormat("HH.mm.ss");
        final java.text.SimpleDateFormat datumFormat = new java.text.SimpleDateFormat("dd.MM.yyyy");

        uhrzeit = zeitFormat.format(new Date());
        datum = datumFormat.format(new Date());
    }

}    

//******************************************************************************
        

//******************************************************************************


/**
 *
 * @author John Schmidt
 */
public class John22012018 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        Gui gui = new Gui();
    }

}
